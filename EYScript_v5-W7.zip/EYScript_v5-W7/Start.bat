@echo off
powershell.exe -ExecutionPolicy Bypass -File "InventoryMenu.ps1" -SkipPublisherCheck -IgnoreCertificateErrors -TargetType All -MicrosoftOnly AllOSMSApps -ScriptRegime SPLA