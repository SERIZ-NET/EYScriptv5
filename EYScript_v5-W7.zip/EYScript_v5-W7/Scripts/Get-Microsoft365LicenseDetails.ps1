#########################################################
#                                                                     
# Get-Microsoft365LicenseDetails.ps1
#
#########################################################

 <#
.SYNOPSIS
Retrieves Microsoft 365 Licensing information for all the user accounts.

.DESCRIPTION
Retrieves licensing information for all the users accounts and outputs this information to a csv file. 
This information includes Username, User details like - Contact and office address, all Products available with company and details of licenses assigned to every user.

.PARAMETER      UserName
Office365 Account Username.

.PARAMETER      Password
Office365 Account Password.

.PARAMETER        OutputFile
Output CSV file to store the results. You can specify a specific location to output the csv file.

UserPrincipalName                 <User Registered Post Code>
DisplayName                       <Name>
SignInName                        <Signin Name>
Title                             <User Title>
MobilePhone                       <User Mobile Number>
PhoneNumber                       <User Phone Number>
Office                            <User Office Location>
City                              <User Specified City>
State                             <User Specified State>
PostalCode                        <User Specified Post Code>
WhenCreated                       <Date & Time>
LastPasswordChangeTimestamp       <Date & Time>
IsBlackberryUser                  True | False
LicenseReconciliationNeeded       True | False
PreferredLanguage                 en-Ie
UsageLocation                     ie
OverallProvisioningStatus         Success | PendingActivation | PendingInput
AlternateEmailAddresses           <Username>@<Company-Name>.Com
ProxyAddresses                    Smtp:<Username>@<LicenseName>.Onmicrosoft.Com; SMTP:<Username>@<Company-Name>.Com
ProductLicense_1                  Success | PendingActivation | PendingInput
ProductLicense_2                  Success | PendingActivation | PendingInput
...

.COPYRIGHT
Copyright (C) 2024 Ernst & Young Global Limited. All rights reserved. The Irish firm Ernst & Young is a member practice of Ernst & Young Global Limited.

This script is proprietary to Ernst & Young Global Limited (or one of its member firms). Unauthorized copying of this file, via any medium, is strictly prohibited. Redistribution and use in source and binary forms, with or without modification, are not permitted without prior written permission from Ernst & Young Global Limited.

.LICENSE
This script is provided "AS IS" without warranty of any kind. Ernst & Young Global Limited expressly disclaims all warranties, whether express, implied, statutory, or otherwise, with respect to this script including all implied warranties of merchantability, fitness for a particular purpose, and non-infringement. In no event shall Ernst & Young Global Limited be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this script, even if advised of the possibility of such damage.

#>

Param(
    [string] $OutputFolder = ".\",
    [string] $OutputFilePrefix = "",
    [alias("o1")]
    $OutputFile1 = "M365Licenses.csv",
    [alias("o2")]
    $OutputFile2 = "M365LicenseAssignments.csv",
    [alias("log")]
    [string] $LogFile = "M365QueryLog.txt",
    $Username,
    $Password,
    [switch] $ShortenPhoneNumbers,
    [switch] $Verbose)

$ScriptDescription =       "Microsoft 365 Export"
$ScriptVersion =           "5.0.17"
$PendingLogEntries = New-Object 'System.Collections.Generic.List[Object]' # Global List to accumulate pending log entries when the file is locked

#region Logging
$script:OutFileSupportsNoNewLine = $false;
function InitialiseLogFile {

    if (!($script:OutputFolder)) {
        $script:OutputFolder = ".\"
    }

    if (!(Test-Path $script:OutputFolder)) {
        New-Item -ItemType Directory -Path $script:OutputFolder | Out-Null
    }

    $script:OutputFolder = Resolve-Path $script:OutputFolder | Select-Object -ExpandProperty Path

    if (!($script:OutputFolder.EndsWith('\'))) {
        $script:OutputFolder += '\'
    }

    if ($script:OutputFolder -and !($LogFile -like "*\*")) {
        $script:LogFile = Join-Path $script:OutputFolder "$($OutputFilePrefix)$LogFile"
    }

    if ($LogFile -and (Test-Path $LogFile)) {
        Remove-Item $LogFile
    }

    if ((Get-Command "Out-File").parameters["NoNewline"]) {
        $script:OutFileSupportsNoNewLine = $true;
    }

    PrefixOutputFilesWithFolder
    DecryptPassword
}

function PrefixOutputFilesWithFolder {
    
    # Check if $OutputFolder exists and is not empty
    if ($script:OutputFolder) {
        $counter = 1
        while ($true) {
            $outputFileVarName = "OutputFile$counter"
            # Check if the OutputFile variable exists
            if (Get-Variable -Name $outputFileVarName -Scope Script -ErrorAction SilentlyContinue) {
                # Get the value of the OutputFile variable
                $outputFileValue = Get-Variable -Name $outputFileVarName -ValueOnly -Scope Script
                # Check if it does not contain a backslash, and if so, prefix with OutputFolder
                if (-not $outputFileValue.Contains("\"))
                {
                    Set-Variable -Name $outputFileVarName -Value (Join-Path $script:OutputFolder "$($OutputFilePrefix)$outputFileValue") -Scope Script
                }
                $counter++
            } else {
                # Exit loop if the variable does not exist
                break
            }
        }
    }
} 

# Helper function to check if the file is locked
function Test-FileLocked {
    param(
        [string]$FilePath
    )
    # Check if the file exists
    if (-not (Test-Path $FilePath)) {
        return $false
    }

    try {
        $fileStream = [System.IO.File]::Open($FilePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::None)
        $fileStream.Close()
        return $false
    }
    catch {
        # Deliberately hiding this message as it is not useful to the user, only for debugging
        #Write-Host "Error accessing the file '$FilePath': $($_.Exception.Message)" -ForegroundColor Red
        return $true
    }
}

function LogText {
    param(
        [Parameter(Position=0, ValueFromRemainingArguments=$true, ValueFromPipeline=$true)]
        [Object] $Object,
        [System.ConsoleColor]$Color = [System.Console]::ForegroundColor,
        [switch]$NoNewLine = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"
    )

    if ($LogTo -ne "File") {
        # Display text on screen
        Write-Host -Object $Object -ForegroundColor $Color -NoNewline:$NoNewLine
    }
    
    if ($LogTo -ne "Console") {
        # Add the current log entry to the pending log entries list
        if ($script:PendingLogEntries.Count -lt 200) {
            $script:PendingLogEntries.Add($Object)
        }
        if ($LogFile) {
            # Attempt to write all pending log entries if the file is not locked
            if (-not (Test-FileLocked -FilePath $LogFile)) {
                foreach ($entry in $script:PendingLogEntries) {
                    if ($script:OutFileSupportsNoNewLine) {
                        $entry | Out-File $LogFile -Encoding utf8 -Append -NoNewline:$NoNewLine 
                    }
                    else {
                        $entry | Out-File $LogFile -Encoding utf8 -Append 
                    }
                }
                # Clear the pending log entries after writing them
                $script:PendingLogEntries.Clear()
            }
            else {
                # Deliberately hiding this message as it is not useful to the user, only for debugging
                #Write-Host "The file '$LogFile' is locked and will be skipped." -ForegroundColor Yellow
            }
        }
    }    
}

function LogTimeAndText {
    param(
        [string] $Text,
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Blue,
        [switch]$IncludeDate = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    $output = "";
    if ($IncludeDate) {
        $output = Get-Date -Format "yyyy-MM-dd HH:mm:ss.ff"
    } else {
        $output = Get-Date -Format "HH:mm:ss.ff"
    }

    $output += " - "
    $output += $Text
    LogText $output -Color $Color -LogTo $LogTo
}

function LogError([string[]]$errorDescription){
    if ($Verbose){
        LogText ""
    }

    $output = $errorDescription -join "`r`n              "
    LogTimeAndText $output -Color Red

    Start-Sleep -s 3
}

function LogLastException() {
    $currentException = $Error[0].Exception;

    while ($currentException)
    {
        LogText -Color Red $currentException
        LogText -Color Red $currentException.Data
        LogText -Color Red $currentException.HelpLink
        LogText -Color Red $currentException.HResult
        LogText -Color Red $currentException.Message
        LogText -Color Red $currentException.Source
        LogText -Color Red $currentException.StackTrace
        LogText -Color Red $currentException.TargetSite

        $currentException = $currentException.InnerException
    }

    Start-Sleep -s 3
}

$script:MostRecentActivity = ""
function LogProgress([string]$Activity, [string]$Status, [Int32]$PercentComplete, [switch]$Completed ){
    
    if ($Activity) {
        $script:MostRecentActivity = $Activity
    } else {
        if ($script:MostRecentActivity) {
            $Activity = $script:MostRecentActivity
        } else {
            $Activity = "Unspecified"
        }
    }
    Write-Progress -activity $Activity -Status $Status -percentComplete $PercentComplete -Completed:$Completed
    LogTimeAndText $Status
}

function GetScriptPath
{
    if($PSCommandPath){
        return $PSCommandPath; }
        
    if($MyInvocation.ScriptName){
        return $MyInvocation.ScriptName }
        
    if($script:MyInvocation.MyCommand.Path){
        return $script:MyInvocation.MyCommand.Path }

    return $script:MyInvocation.MyCommand.Definition
}

function GetDotNetFrameworkVersion {
    #$release = Get-ItemPropertyValue -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release
    $regKey = Get-Item -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    $release = $regKey.GetValue("Release")
    switch ($release) {
        { $_ -ge 533320 } { $version = "4.8.1 or later ($release)"; break }
        { $_ -ge 528040 } { $version = "4.8 ($release)"; break }
        { $_ -ge 461808 } { $version = "4.7.2 ($release)"; break }
        { $_ -ge 461308 } { $version = "4.7.1 ($release)"; break }
        { $_ -ge 460798 } { $version = "4.7 ($release)"; break }
        { $_ -ge 394802 } { $version = "4.6.2 ($release)"; break }
        { $_ -ge 394254 } { $version = "4.6.1 ($release)"; break }
        { $_ -ge 393295 } { $version = "4.6 ($release)"; break }
        { $_ -ge 379893 } { $version = "4.5.2 ($release)"; break }
        { $_ -ge 378675 } { $version = "4.5.1 ($release)"; break }
        { $_ -ge 378389 } { $version = "4.5 ($release)"; break }
        default { $version = $null; break }
    }

    return $version
}

function LogEnvironmentDetails ([string[]] $OtherDetails){

    $script:ScriptPath = GetScriptPath
    $script:ScriptName = split-path $ScriptPath -leaf

    LogText " "
    LogHeaderText -FrameLine 
    LogHeaderText -LeftText " _______     __" -LeftColor Yellow
    LogHeaderText -LeftText "|  ___\ \   / /" -LeftColor Yellow
    LogHeaderText -LeftText "| |__  \ \_/ / " -LeftColor Yellow
    LogHeaderText -LeftText "|  __|  \   /  " -LeftColor Yellow
    LogHeaderText -LeftText "| |____  | |   " -LeftColor Yellow -RightText "$ScriptDescription  "
    LogHeaderText -LeftText "|______| |_|   " -LeftColor Yellow -RightText "Version $ScriptVersion  "
    LogHeaderText
    LogHeaderText -FrameLine 

    LogText " "
    LogText " $ScriptName" -Color Green 
    LogText " "

    if ($PSVersionTable.PSVersion.Major -ge 3) {
        $oSDetails = Get-CimInstance -ClassName Win32_OperatingSystem
    } else {
        $oSDetails = Get-WmiObject -Class Win32_OperatingSystem
    }
    $elevated = [bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")
    $currentThread = [System.Threading.Thread]::CurrentThread
    $dotNetFrameworkVersion = GetDotNetFrameworkVersion
    LogText -Color Gray "Computer Name:          $($env:COMPUTERNAME)"
    LogText -Color Gray "User Name:              $($env:USERNAME)@$($env:USERDNSDOMAIN)"
    LogText -Color Gray "Windows Version:        $($oSDetails.Caption)($($oSDetails.Version))"
    LogText -Color Gray "Memory kB:              $($oSDetails.TotalVisibleMemorySize.ToString("N0")) ($($oSDetails.FreePhysicalMemory.ToString("N0")) Free)"
    LogText -Color Gray "Locale:                 $($oSDetails.Locale) (Language $($oSDetails.OSLanguage))"
    LogText -Color Gray "PowerShell Host:        $($host.Version.Major)"
    LogText -Color Gray "PowerShell Version:     $($PSVersionTable.PSVersion)"
    LogText -Color Gray "PowerShell Word Size:   $($([IntPtr]::size) * 8) bit"
    LogText -Color Gray "Script Path:            $ScriptPath"
    LogText -Color Gray "Working Directory:      $PWD"
    LogText -Color Gray "CLR Version:            $($PSVersionTable.CLRVersion)"
    LogText -Color Gray ".Net Framework Version: $dotNetFrameworkVersion"
    LogText -Color Gray "Elevated:               $elevated"
    LogText -Color Gray "Current Date Time:      $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
    LogText -Color Gray "Default Date Format:    $($CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern)"
    LogText -Color Gray "Current Culture:        $((Get-Culture).EnglishName) (UI: $((Get-UICulture).EnglishName))"
    
    if (Test-Path "Variable:OutputFolder") {
        LogText -Color Gray "Output Folder:          $OutputFolder" 
    }
    if (Test-Path "Variable:OutputFile1") {
        LogText -Color Gray "Output File 1:          $OutputFile1" 
    }
    if (Test-Path "Variable:LogFile") {
        LogText -Color Gray "Log File:               $LogFile" 
    }
    if (Test-Path "Variable:ComputerName") {
        LogText -Color Gray "Target Computer Name:   $ComputerName" 
    }
    if (Test-Path "Variable:UserName") {
        LogText -Color Gray "Script User Name:       $UserName"
    }
    if (Test-Path "Variable:MicrosoftOnly") {
        LogText -Color Gray "Microsoft Only:         $MicrosoftOnly"
    }
    if (Test-Path "Variable:TargetType") {
        LogText -Color Gray "Target Type:            $TargetType"
    }
    if (Test-Path "Variable:ScriptRegime") {
        LogText -Color Gray "Script Regime:          $ScriptRegime"
    }
    if (Test-Path "Variable:RequiredData") {
        LogText -Color Gray "Required Data:          $RequiredData"
    }

    foreach ($detail in $OtherDetails){
        LogText -Color Gray $detail
    }

    LogText -Color Gray ""

}

function LogHeaderText {
    param(
        [string] $LeftText = " ",
        [System.ConsoleColor]$LeftColor = [System.ConsoleColor]::Blue,
        [string] $RightText,
        [System.ConsoleColor]$RightColor = [System.ConsoleColor]::DarkGray,
        [char] $FrameChar = "#",
        [switch] $FrameLine,
        [switch] $LeftAlignRightText,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    if ($FrameLine) {
        $strFullText = "  " + ($FrameChar.ToString() * 69)
        LogText $strFullText -Color DarkGray -LogTo $LogTo
        return
    }

    $strLeftFrame = "  $FrameChar  "
    $strLeftText = $LeftText
    $strRightText = $RightText
    $strRightFrame = "  $FrameChar"
    if ($LeftAlignRightText) {
        $strRightText = $RightText.PadRight(63 - $LeftText.Length)
    } else {
        $strLeftText = $LeftText.PadRight(63 - $RightText.Length)
    }
    

    if ($LogTo -eq "Console" -or $LogTo -eq "Both") {
        LogText $strLeftFrame -LogTo "Console" -NoNewLine -Color DarkGray
        LogText $strLeftText -LogTo "Console" -NoNewLine -Color $LeftColor
        LogText $strRightText -LogTo "Console" -NoNewLine -Color $RightColor
        LogText $strRightFrame -LogTo "Console" -Color DarkGray
    }

    if ($LogTo -eq "File" -or $LogTo -eq "Both") {
        $strFullText = $strLeftFrame + $strLeftText + $strRightText + $strRightFrame
        LogText $strFullText -LogTo "File" 
    }
}

function DecryptPassword {
    $strOneTimePassword = "%OneTimePassword%" # Replace this with the one-time password
    if ($SecurePassword) {
        $baOneTimePassword = [System.Convert]::FromBase64String($strOneTimePassword)
        $baSecurePassword = [System.Convert]::FromBase64String($SecurePassword)
        for($i=0; $i -lt $baSecurePassword.count ; $i++)
        {
            $baSecurePassword[$i] = $baSecurePassword[$i] -bxor $baOneTimePassword[$i%$baOneTimePassword.Length]
        }
        $script:Password = [System.Text.Encoding]::Unicode.GetString($baSecurePassword);
    }
}
#endregion

#region Setup Output Formats
function SetupOutputFormats {
    # Standardise date/time output to ISO 8601'ish format
    $bOutputFormatsUpdated = $false
    $currentThread = [System.Threading.Thread]::CurrentThread
    $desiredShortPattern = 'yyyy-MM-dd'
    $desiredLongPattern = 'yyyy-MM-dd HH:mm:ss'

    try {
        $cultureInvariant = [CultureInfo]::InvariantCulture.Clone()
        $cultureInvariant.DateTimeFormat.ShortDatePattern = $desiredShortPattern
        $cultureInvariant.DateTimeFormat.LongDatePattern = $desiredLongPattern
        $cultureInvariant.NumberFormat.NumberGroupSeparator = ""  
        $cultureInvariant.NumberFormat.NumberDecimalSeparator = "."
        $currentThread.CurrentCulture = $cultureInvariant
        $bOutputFormatsUpdated = $true
    }
    catch {
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $currentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $currentThread.CurrentCulture.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $currentThread.CurrentCulture.NumberFormat.NumberGroupSeparator = ""  
            $currentThread.CurrentCulture.NumberDecimalSeparator = "."
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $cultureCopy = $currentThread.CurrentCulture.Clone()
            $cultureCopy.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $cultureCopy.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $cultureCopy.NumberFormat.NumberGroupSeparator = ""  
            $cultureCopy.NumberDecimalSeparator = "."
            $currentThread.CurrentCulture = $cultureCopy
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread using clone of current culture"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        LogText "Failed to update output formats"
    }
}
#endregion

#region Query User
function QueryUser([string]$Message, [string]$Prompt, [switch]$AsSecureString = $false, [string]$DefaultValue){
    $strResult = ""
    
    if ($Message) {
        LogText $Message -color Yellow
    }

    if ($DefaultValue) {
        $Prompt += " (Default [$DefaultValue])"
    }

    $Prompt += ": "
    LogText $Prompt -color Yellow -NoNewLine
    
    if ($Headless) {
        LogText " (Headless - Using Default Value)" -color Yellow
    }
    else {
        $strResult = Read-Host -AsSecureString:$AsSecureString
    }

    if(!$strResult -or ($strResult.Length -eq 0)) {
        $strResult = $DefaultValue
        if ($AsSecureString) {
            $strResult = ConvertTo-SecureString $strResult -AsPlainText -Force
        }
    }

    return $strResult
}

function Get-ConsoleCredential([String] $Message, [String] $DefaultUsername, [switch] $AsPSCredential)
{
    $strUsername = QueryUser -Message $Message -Prompt "Username" -DefaultValue $DefaultUsername
    if (!$strUsername){
        return $null
    }

    $strSecurePassword = QueryUser -Prompt "Password" -AsSecureString
    if (!$strSecurePassword){
        return $null
    }

    if ($AsPSCredential) {
        $Creds = New-Object System.Management.Automation.PSCredential ($strUsername, $strSecurePassword)
    } else {
        $Creds = New-Object PSObject

        $bstrSecurePassword = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($strSecurePassword)
        $strUnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstrSecurePassword)

        $Creds | Add-Member -MemberType NoteProperty -Name "UserName" -Value $strUsername
        $Creds | Add-Member -MemberType NoteProperty -Name "Password" -Value $strUnsecurePassword
    }

    return $Creds
}
#endregion

#region Test Connection
$script:ConnectionDetails = [PSCustomObject][ordered]@{
    TargetName = ""
    ComputerName = ""
    ComputerDomain = ""
    IPAddress0 = ""
    NameResolution = [Nullable[bool]]$null
    Ping = [Nullable[bool]]$null
    PortSSH = [Nullable[bool]]$null
    PortHTTP = [Nullable[bool]]$null
    PortWMI = [Nullable[bool]]$null
    PortSMB1 = [Nullable[bool]]$null
    PortHTTPS = [Nullable[bool]]$null
    PortSMB2 = [Nullable[bool]]$null
    PortSQL = [Nullable[bool]]$null
    PortRDP = [Nullable[bool]]$null
    PortWinRM = [Nullable[bool]]$null
    PortWinRMS = [Nullable[bool]]$null 
    OtherPorts = @{}
    Error = ""
    ErrorDetails = ""
    CimConnectionType = $null
    CimSession = $null
    PSSession = $null
    HKLM = $null
    HKU = $null
}

function TestConnectivity {
    param(
        [string] $Target,
        [int[]] $Ports = @(22, 80, 135, 139, 443, 445, 1433, 3389, 5985, 5986)
    )

    $ConnectionDetails.TargetName = $Target
    $ConnectionDetails.ComputerName = $Target

    # Test name resolution
    LogText "Name Resolution: " -NoNewLine -Color Gray
    $ConnectionDetails.NameResolution = $false;
    try {
        $nameResolutionResult = [System.Net.Dns]::GetHostAddresses($Target)
        if ($nameResolutionResult.Count -gt 0) {
            $ConnectionDetails.IPAddress0 = $nameResolutionResult[0].IPAddressToString
            $ConnectionDetails.NameResolution = $true;
        }
    } catch {}
    
    if ($ConnectionDetails.NameResolution) {
        LogText "Succeeded" -Color Green
    } else {
        LogText "Failed" -Color Red
        return;
    }
    
    # Test Ping
    LogText "Ping: " -NoNewLine -Color Gray
    $ConnectionDetails.Ping = $false;
    try {
        $pingResult = Test-Connection -ComputerName $Target -Count 1 -ErrorAction SilentlyContinue
        if ($pingResult.StatusCode -eq 0) {
            $ConnectionDetails.Ping = $true
        } else {
            $ConnectionDetails.Ping = $false
        }
    } catch {}
    
    if ($ConnectionDetails.Ping) {
        LogText "Succeeded" -Color Green
    } else {
        LogText "Failed" -Color Red
    }
    
    # Test Ports
    LogText "Port Scan: " -NoNewLine -Color Gray

    $sockets = @()
    $asyncResults = @()

    # Start connections
    foreach ($port in $Ports) {
        $socket = New-Object System.Net.Sockets.TcpClient
        $sockets += $socket

        $asyncResult = $socket.BeginConnect($Target, $port, $null, $null)
        $asyncResults += $asyncResult
    }

    # Wait for 2 seconds or until all sockets have connected
    $timeout = 2000
    $endTime = (Get-Date).AddMilliseconds($timeout)

    foreach ($asyncResult in $asyncResults) {
        $remainingTime = ($endTime - (Get-Date)).TotalMilliseconds
        if ($remainingTime -le 0) {
            break
        }
        $asyncResult.AsyncWaitHandle.WaitOne($remainingTime) | Out-Null
    }

    # Check the status of each socket
    for ($i = 0; $i -lt $sockets.Count; $i++) {
        $socket = $sockets[$i]
        $port = $ports[$i]

        switch ($port) {
            22 {
                $ConnectionDetails.PortSSH = $socket.Connected
            }
            80 {
                $ConnectionDetails.PortHTTP = $socket.Connected
            }
            135 {
                $ConnectionDetails.PortWMI = $socket.Connected
            }
            139 {
                $ConnectionDetails.PortSMB1 = $socket.Connected
            }
            443 {
                $ConnectionDetails.PortHTTPS = $socket.Connected
            }
            445 {
                $ConnectionDetails.PortSMB2 = $socket.Connected
            }
            1433 {
                $ConnectionDetails.PortSQL = $socket.Connected
            }
            3389 {
                $ConnectionDetails.PortRDP = $socket.Connected
            }
            5985 {
                $ConnectionDetails.PortWinRM = $socket.Connected
            }
            5986 {
                $ConnectionDetails.PortWinRMS = $socket.Connected
            }
            default {
                $ConnectionDetails.OtherPorts.Add($port, $socket.Connected)
            }
        }

        # Close the socket
        $socket.Close()
    }

    LogConnectionResult -PortName "SSH" -Result $ConnectionDetails.PortSSH;
    LogConnectionResult -PortName "HTTP" -Result $ConnectionDetails.PortHTTP;
    LogConnectionResult -PortName "WMI" -Result $ConnectionDetails.PortWMI;
    LogConnectionResult -PortName "SMB" -Result $ConnectionDetails.PortSMB1;
    LogConnectionResult -PortName "HTTPS" -Result $ConnectionDetails.PortHTTPS;
    LogConnectionResult -PortName "SQL" -Result $ConnectionDetails.PortSQL;
    LogConnectionResult -PortName "RDP" -Result $ConnectionDetails.PortRDP;
    LogConnectionResult -PortName "WinRM" -Result $ConnectionDetails.PortWinRM;
    LogConnectionResult -PortName "WinRMS" -Result $ConnectionDetails.PortWinRMS;
    LogText ""

    # OtherPorts
}

function LogConnectionResult {
    param(
        [string] $PortName,
        $Result
    )

    if ($null -eq $Result) {
        return;
    }

    $resultText = "Failed"
    $colour = [System.ConsoleColor]::Yellow;
    if ($Result) {
        $resultText = "Succeeded"
        $colour = [System.ConsoleColor]::Green;
    }

    LogText "$PortName " -NoNewLine -Color $colour -LogTo Console
    LogText "$($PortName): $resultText"  -LogTo File
}
#endregion

#region Custom Export
$ScriptExcludeFields = $null
function Export-MyCsv {
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [PSCustomObject[]] $InputObject,
        [Parameter(Mandatory = $true)]
        [string] $Path,
        [switch] $Append,
        [switch] $IncludeIndex
    )

    begin {
        if ($null -eq $ScriptExcludeFields) {
            LoadExcludeFields
        }

        $fileExcludeFields = $null
        $fileID = GetFileNameFinalPart -FilePath $Path
        if ($ScriptExcludeFields.ContainsKey($fileID)) {
            $fileExcludeFields = $ScriptExcludeFields[$fileID].Split(',') | ForEach-Object { $_.Trim() }
        }

        $index = 1
        $outputData = New-Object 'System.Collections.Generic.List[object]'
    }

    process {
        foreach ($item in $InputObject) {
            
            # Create a duplicate of the item with only the required fields
            $processedItem = New-Object PSObject 
            foreach ($prop in $item.PSObject.Properties) {
                if ($null -eq $fileExcludeFields -or -not ($fileExcludeFields | ForEach-Object { $_.ToLower() } | Where-Object { $_ -eq $prop.Name.ToLower() })) {
                    $processedItem | Add-Member -MemberType NoteProperty -Name $prop.Name -Value $prop.Value -Force
                }
            }

            # Add index if requested
            if ($IncludeIndex) {
                $processedItem | Add-Member -MemberType NoteProperty -Name 'Index' -Value $index -Force
                $index++
            }

            # Add the processed item to the list
            $outputData.Add($processedItem)
        }
    }

    end {
        # Convert the list to an array and export to CSV
        $outputData.ToArray() | Export-Csv -Path $Path -Encoding UTF8 -NoTypeInformation -Append:$Append -Delimiter ","

        # This function logs the field names and sample values of exported data to the log file and a CSV file
        # Uncomment the following line to enable this functionality
        #LogFieldInfo -InputObject $outputData -OutputFileName $fileID
        $outputData = $null
    }
}

function LoadExcludeFields {
    $script:ScriptExcludeFields = @{}

    if (!($ScriptDescription)) {
        return
    }

    # Import the CSV
    try {
        $csvData = Import-Csv -Path ".\ExcludeFields.csv" -ErrorAction SilentlyContinue
    } catch {
    }

    foreach ($row in $csvData | Where-Object { $_.Script -eq $ScriptDescription }) {
        $ScriptExcludeFields[$row.OutputFile] = $row.ExcludeFields
    }
}

function GetFileNameFinalPart {
    param (
        [string]$FilePath
    )

    # Return the last part of the filename i.e. Apps for the following values
    # c:\temp\20240102_101212_Apps.csv
    # c:\temp\Apps.csv

    # Get the filename without the extension
    $fileNameWithoutExtension = [System.IO.Path]::GetFileNameWithoutExtension($FilePath)

    # Split the filename by underscore or backslash, and take the last part
    $lastPart = ($fileNameWithoutExtension -split '[\\_]')[-1]

    return $lastPart
}

# Support function. Not currently called. The function is used for custom testing to aid the local development team where necessary
function LogFieldInfo {
    param(
        [PSCustomObject[]] $InputObject,
        [string] $OutputFileName
    )
    
    # This function logs the field names and sample values of exported data to the log file and a CSV file
    # It is not enabled by default
    if (!($InputObject) -or $InputObject.Count -eq 0) {
        return
    }

    # Creating a new array of fields and sample values
    $lstFields = @()

    $recordIndex = 1
    foreach ($record in $InputObject) {
        $fieldNames = $record.PSObject.Properties.Name
        $fieldIndex = 1

        # Iterate through each property
        foreach ($fieldName in $fieldNames) {
            # Creating a new object for each property
            $field = [PSCustomObject][ordered]@{
                ScriptFileName = $ScriptName
                ScriptDescription = $ScriptDescription
                OutputFileName = $OutputFileName
                FieldName = $fieldName
                SampleValue = $record.$fieldName
                FieldIndex = $fieldIndex++
                RecordIndex = $recordIndex
            }

            # Add new object to the array
            $lstFields += $field
        }
    
        $recordIndex++
        if ($recordIndex -gt 3) {
            break
        }
    }

    # Save the field info to log file and csv file
    $csvLines = $lstFields | ConvertTo-Csv -NoTypeInformation
    $csvString = $csvLines -join "`n"
    LogText $csvString -LogTo File
    $lstFields | export-csv -Path ".\FieldInfo.csv" -NoTypeInformation -Append -Delimiter ","
}
#endregion

#region Ensure Module
function EnsureModuleLoaded {
    param (
        [Parameter(Mandatory=$true)]
        [string] $ModuleName,
        [Version] $MinimumVersion = '1.0.0'
    )

    try {
        # Check if the module is already loaded or available
        $module = Get-Module -Name $ModuleName -ListAvailable | Sort-Object Version -Descending | Select-Object -First 1
        $strDefaultInstallAction = "Y"
        if ($Headless) {
            $strDefaultInstallAction = "N"
        }

        if ($module) {
            if ($module.Version -lt $MinimumVersion) {
                $userResponse = QueryUser -Prompt "$ModuleName version $($module.Version) is older than the required minimum version $MinimumVersion. Do you want to upgrade it now? (Y/N)" -DefaultValue $strDefaultInstallAction
                if ($userResponse -eq 'Y' -or $userResponse -eq 'y') {
                    try {
                        
                        $updateModuleParams = @{
                            Name = $ModuleName
                            Scope = "CurrentUser"
                            Force = $true
                            Confirm = $false 
                            ErrorAction = "Stop"
                        };

                        LogText "Calling 'Update-Module -Name $ModuleName -Force'"
                        LogText "The update can take 5-10 minutes without any visual feedback. Please be patient." -Color Gray
                        Update-Module @updateModuleParams
                        Import-Module -Name $ModuleName
                        LogText "Module $ModuleName upgraded and imported"
                        return $true
                    } catch {
                        LogError "Failed to upgrade $ModuleName. Error: $_"
                        LogText "If this problem persists, you can try calling 'Uninstall-Module -Name $ModuleName' and rerunning this script" -Color Yellow
                        return $false
                    }
                } else {
                    LogText "Module $ModuleName was not upgraded" -Color Red
                    LogText "To upgrade the required module, follow one of these methods:"
                    LogText ""
                    LogText "[Online Devices]"
                    LogText "1. Open a PowerShell console and run:"
                    LogText "   Update-Module -Name $ModuleName -Force"
                    LogText ""
                    LogText "[Offline Devices]"
                    LogText "1. On an internet-connected PC, open a PowerShell console and run:"
                    LogText "   Save-Module -Name $ModuleName -Path C:\Modules"
                    LogText ""
                    LogText "2. Transfer the contents from 'C:\Modules' on the online PC to:"
                    LogText "   C:\Program Files\WindowsPowerShell\Modules on the offline device."
                    LogText ""
                    LogText "[Alternative]"
                    LogText "1. Download and install directly from:"
                    LogText "   https://www.powershellgallery.com/packages/$ModuleName"
                    LogText ""
                    LogText "Note: Upgrading is essential for optimal functionality."
                    return $false
                }
            } elseif (-not (Get-Module -Name $ModuleName)) {
                LogText "Importing Module $ModuleName"
                Import-Module -Name $ModuleName
                LogText "Module $ModuleName imported"
                return $true
            } else {
                LogText "Module $ModuleName already imported"
                return $true
            }
            return
        }

        # If the module is not available, ask the user if they want to install it
        $userResponse = QueryUser -Prompt "A required module ($ModuleName) is not currently installed. Do you want to install it now? (Y/N)" -DefaultValue $strDefaultInstallAction
        if ($userResponse -eq 'Y' -or $userResponse -eq 'y') {
            try {
                $installModuleParams = @{
                    Name = $ModuleName
                    Scope = "CurrentUser"
                    MinimumVersion = $MinimumVersion
                    Force = $true 
                    Confirm = $false 
                    AllowClobber = $true
                    ErrorAction = "Stop"
                };

                if ($SkipPublisherCheck) {
                    $installModuleParams.Add("SkipPublisherCheck", $true)
                }

                LogText "Calling 'Install-Module -Name $ModuleName -Force'"
                LogText "The installation can take 5-10 minutes without any visual feedback. Please be patient." -Color Gray
                Install-Module @installModuleParams
                LogText "Importing Module $ModuleName"
                Import-Module -Name $ModuleName
                LogText "Module $ModuleName has been installed"
                return $true
            } catch {
                LogError "Failed to install $ModuleName. Error: $_"
                return $false
            }
        } else {
            LogText "Module $ModuleName was not installed" -Color Red
            LogText "To install the required module, follow one of these methods:"
            LogText ""
            LogText "[Online Devices]"
            LogText "1. Open a PowerShell console and run:"
            LogText "   Install-Module -Name $ModuleName -Force"
            LogText ""
            LogText "[Offline Devices]"
            LogText "1. On an internet-connected PC, open a PowerShell console and run:"
            LogText "   Save-Module -Name $ModuleName -Path C:\Modules"
            LogText ""
            LogText "2. Transfer the contents from 'C:\Modules' on the online PC to:"
            LogText "   C:\Program Files\WindowsPowerShell\Modules on the offline device."
            LogText ""
            LogText "[Alternative]"
            LogText "1. Download and install directly from:"
            LogText "   https://www.powershellgallery.com/packages/$ModuleName"
            LogText ""
            LogText "Note: Installation is essential for this script to work"
            
            return $false
        }
    } catch {
        LogLastException
    }

    return $false
}
#endregion

#region Utilities
function MaskPhoneNumber {
    param (
        [string]$PhoneNumber
    )

    if (!($PhoneNumber)) {
        return ""
    }

    $digitCount = 0
    $maskedNumber = -join ($PhoneNumber.ToCharArray() | ForEach-Object {
        if ($_ -match '\d') {
            $digitCount++
            if ($digitCount -le 3) { $_ } else { '*' }
        } else {
            $_
        }
    })

    return $maskedNumber
}
#endregion


function ConnectToGraph() {
    LogProgress -Activity "Microsoft 365 Data Export" -Status "Connecting to Microsoft 365 Graph" -percentComplete 30

    # Create the Credentials object if username has been provided
    #if(!($UserName -and $Password)){
    #    $credential = Get-ConsoleCredential -DefaultUsername $UserName -Message "Microsoft 365 Administrator Credentials Required" -AsPSCredential
    #}
    #else {
    #    $securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
    #    $credential = New-Object System.Management.Automation.PSCredential ($UserName, $securePassword)
    #}

    # Interactive OAuth 2.0 flow
    Connect-MgGraph -Scopes "User.Read.All","Directory.Read.All","Organization.Read.All" -ErrorAction SilentlyContinue -ErrorVariable errConn #-Credential $credential
    
    if ($errConn -ne $null) {
        LogError "Authentication - Incorrect login details. Please verify the credentials and try again."     
        return $false
    }

    LogProgress -Activity "Microsoft 365 Data Export" -Status "Connected to Microsoft 365 Graph" -percentComplete 40
    return $true
}

function ExportOffice365Data() {

    # Get a list of all licences that exist within the tenant
    LogProgress -Activity 'Microsoft 365 Data Export' -Status 'Querying Available Licenses' -percentComplete 45
    $orgLicenses = Get-MgSubscribedSku 
    
    try {
        $test = $orgLicenses.GetType()
    }
    catch {
        LogError "An error occurred when retrieving data from Microsoft 365", "Ensure valid credentials were provided"
        return $false
    }
    
    $orgLicensesInfo = $orgLicenses | Select-Object AccountName,
        SkuPartNumber,
        @{Name="SkuName"; Expression={LookupSkuName($_.SkuPartNumber)}},
        SkuId, 
        @{Name="TargetClass"; Expression={$_.AppliesTo}}, 
        @{Name="ActiveUnits"; Expression={$_.PrepaidUnits.Enabled}},
        ConsumedUnits,
        @{Name="LockedOutUnits"; Expression={$_.PrepaidUnits.LockedOut}},
        @{Name="SuspendedUnits"; Expression={$_.PrepaidUnits.Suspended}},
        @{Name="WarningUnits"; Expression={$_.PrepaidUnits.Warning}}

    $orgLicensesInfo | Export-MyCsv -Path  $OutputFile1 -IncludeIndex

    # Get list of all the users
    LogProgress -Activity 'Microsoft 365 Data Export' -Status 'Querying User List' -percentComplete 55
    $users = Get-MgUser -all -Property UserPrincipalName, DisplayName, jobTitle, MobilePhone, BusinessPhones, Id, UserType, Department, OfficeLocation,
    City, State, Country, UsageLocation, CreatedDateTime, LastPasswordChangeDateTime, PasswordPolicies, PasswordProfile, LicenseAssignmentStates, ServiceProvisioningErrors,
    #AssignedLicenses, #replaced with Get-MgUserLicenseDetail
    Identities, # source of SignInName, now many are allowed by 365
    OtherMails #source of AlternateEmailAddresses, but only one is allowed by 365

    # Get license assignments
    LogProgress -Activity 'Microsoft 365 Data Export' -Status 'Querying License Assignments' -percentComplete 75
    $result = @()
    
    foreach ($user in $users) {

        if ($Verbose) {
            LogText "Querying License Assignments for User: $($user.displayname)"
        }
        
        # Get specific user details
        $userDetails = $user | Select-Object -Property UserPrincipalName, DisplayName, SignInName, AlternateEmailAddresses,
        @{Name="Title"; Expression={$_.jobTitle}},
        MobilePhone,
        @{Name="PhoneNumber"; Expression={$_.BusinessPhones -join ';'}},
        @{Name="ObjectId"; Expression={$_.Id}}, 
        UserType, Department,
        @{Name="Office"; Expression={$_.OfficeLocation}},
        City, State, Country, UsageLocation,
        @{Name="WhenCreated"; Expression={$_.CreatedDateTime}},
        @{Name="LastPasswordChangeTimestamp"; Expression={$_.LastPasswordChangeDateTime}},
        @{Name="PasswordNeverExpires"; Expression={($_.PasswordPolicies -match 'DisablePasswordExpiration') -or ($_.PasswordProfile.PasswordNeverExpires) }},
        #@{Name="LicenseReconciliationNeeded"; Expression={ $_.LicenseAssignmentStates -and $_.LicenseAssignmentStates.State -ne 'enabled' }},
        @{Name="OverallProvisioningStatus"; Expression={ if($_.ServiceProvisioningErrors){ 'Errors' } else { 'OK' }}}
        
        if ($ShortenPhoneNumbers) {
            if ($userDetails.MobilePhone) {$userDetails.MobilePhone = MaskPhoneNumber -PhoneNumber $userDetails.MobilePhone}
            if ($userDetails.PhoneNumber) {
                $userDetails.PhoneNumber =  ( 
                    ($user.BusinessPhones) |
                    ForEach-Object { MaskPhoneNumber -PhoneNumber $_ } 
                ) -join ';'
            }
        }

        if ($null -ne $user.Identities) {
            $userDetails.SignInName =   (
                ($user.Identities |
                    Where-Object { $_ -and -not [string]::IsNullOrWhiteSpace($_.IssuerAssignedId) } |
                    ForEach-Object { $_.IssuerAssignedId }
                ) -join '; '            )
        } else {
            $userDetails.SignInName = ""
        }

        $altEmail = $user.OtherMails -join '; '
        $userDetails.AlternateEmailAddresses = $altEmail
    
        ##$ProxyAddrs = $user.ProxyAddresses -join '; '
        ##$userDetails | Add-Member -MemberType NoteProperty -Name "ProxyAddresses" -Value $ProxyAddrs

        # Get detailed license information for the user
        $userLicenseDetails = @()
        $userLicenseDetails = Get-MgUserLicenseDetail -UserId $user.Id -Property skuId, SkuPartNumber, ServicePlans
        
        $userLicensesSkus = @()
        $userLicensesSkuIDs = @()
        $userLicensesSkuNames = @()
        foreach ($license in $userLicenseDetails) {
            $userLicensesSkuIDs += $license.SkuId
            $userLicensesSkus += $license.SkuPartNumber #$SkuTable[[string]$license.SkuId].SkuPartNumber    
            $userLicensesSkuNames += LookupSkuName($userLicensesSkus);
        }

        $userDetails | Add-Member -MemberType NoteProperty -Name "LicenseSkus" -Value ($userLicensesSkus -join ";")
        $userDetails | Add-Member -MemberType NoteProperty -Name "LicenseNames" -Value ($userLicensesSkuNames -join ";")
        
        if ($null -ne $userLicensesSkuIDs) {
            # loop through all licenses subscribed by organisation.
            foreach ($orgLicense in $orgLicenses) {        
                $licenseSku = $orgLicense.SkuPartNumber

                # Check if the current license is present in the users license list
                if ($userLicensesSkus -contains $licenseSku) {
                    # Retrieve specific license from users licenses
                    $userLicense = $userLicenseDetails | Where-Object { $_.SkuPartNumber -eq $licenseSku }

                    # Add license title
                    $licenseDetails += '(' + $orgLicense.AccountName + ');'            
                
                    # Loop through all the services in the license.
                    foreach ($serviceStatus in $userLicense.ServicePlans) {
                        $licenseDetails += $serviceStatus.ServicePlanName + ':' + $serviceStatus.ProvisioningStatus + ';'
                    }
                }

                # Add the license details to the list
                $userDetails | Add-Member -MemberType NoteProperty -Name $licenseSku -Value $licenseDetails
                $licenseDetails = ''
            }
        }
        
        $result += $userDetails
    }

    # Export users details to CSV
    $result | Export-MyCsv -Path $OutputFile2 -IncludeIndex

    return $true
}

function LookupSkuName ([string] $Sku) {
    # Return a friendly name for the Microsoft 365 SKU (if available)
    # source https://learn.microsoft.com/en-us/entra/identity/users/licensing-service-plan-reference
    switch ($Sku) 
    {
        "10_ALR_ADDON" {return "10-Year Audit Log Retention Add On"}
        "ADV_COMMS" {return "Advanced Communications"}
        "CDSAICAPACITY" {return "AI Builder Capacity add-on"}
        "SPZA_IW" {return "App Connect IW"}
        "Microsoft_Cloud_App_Security_App_Governance_Add_On" {return "App governance add-on to Microsoft Defender for Cloud Apps"}
        "MCOMEETADV" {return "Microsoft 365 Audio Conferencing"}
        "MCOMEETADV_FACULTY" {return "Microsoft 365 Audio Conferencing for faculty"}
        "AAD_BASIC" {return "Microsoft Entra Basic"}
        "AAD_PREMIUM" {return "Microsoft Entra ID P1"}
        "AAD_PREMIUM_FACULTY" {return "Microsoft Entra ID P1 for faculty"}
        "AAD_PREMIUM_USGOV_GCCHIGH" {return "Microsoft Entra ID P1_USGOV_GCCHIGH"}
        "AAD_PREMIUM_P2" {return "Microsoft Entra ID P2"}
        "RIGHTSMANAGEMENT" {return "Azure Information Protection Plan 1"}
        "RIGHTSMANAGEMENT_CE" {return "Azure Information Protection Plan 1"}
        "RIGHTSMANAGEMENT_CE_GOV" {return "Azure Information Protection Premium P1 for Government"}
        "RIGHTSMANAGEMENT_CE_USGOV_GCCHIGH" {return "Azure Information Protection Premium P1_USGOV_GCCHIGH"}
        "OFFICEBASIC" {return "Basic Collaboration"}
        "SMB_APPS" {return "Business Apps (free)"}
        "CAREERCOACH_FACULTY" {return "Career Coach for faculty"}
        "CAREERCOACH_STUDENTS" {return "Career Coach for students"}
        "Clipchamp_Premium" {return "Clipchamp Premium"}
        "Clipchamp_Premium_Add_on" {return "Clipchamp Premium Add-on"}
        "Clipchamp_Standard" {return "Clipchamp Standard"}
        "CDS_FILE_CAPACITY" {return "Common Data Service for Apps File Capacity"}
        "CDS_DB_CAPACITY" {return "Common Data Service Database Capacity"}
        "CDS_DB_CAPACITY_GOV" {return "Common Data Service Database Capacity for Government"}
        "CDS_LOG_CAPACITY" {return "Common Data Service Log Capacity"}
        "MCOPSTNC" {return "Communications Credits"}
        "CMPA_addon" {return "Compliance Manager Premium Assessment Add-On"}
        "CMPA_addon_GCC" {return "Compliance Manager Premium Assessment Add-On for GCC"}
        "Microsoft_365_Copilot" {return "Copilot for Microsoft 365"}
        "Defender_Threat_Intelligence" {return "Defender Threat Intelligence"}
        "MESSAGING_GCC_TEST" {return "Digital Messaging for GCC Test SKU"}
        "CRMSTORAGE" {return "Dynamics 365 - Additional Database Storage (Qualified Offer)"}
        "CRMINSTANCE" {return "Dynamics 365 - Additional Production Instance (Qualified Offer)"}
        "CRMTESTINSTANCE" {return "Dynamics 365 - Additional Non-Production Instance (Qualified Offer)"}
        "SOCIAL_ENGAGEMENT_APP_USER" {return "Dynamics 365 AI for Market Insights (Preview)"}
        "DYN365_ASSETMANAGEMENT" {return "Dynamics 365 Asset Management Addl Assets"}
        "DYN365_BUSCENTRAL_ADD_ENV_ADDON" {return "Dynamics 365 Business Central Additional Environment Addon"}
        "DYN365_BUSCENTRAL_DB_CAPACITY" {return "Dynamics 365 Business Central Database Capacity"}
        "DYN365_BUSCENTRAL_ESSENTIAL" {return "Dynamics 365 Business Central Essentials"}
        "Dynamics_365_Business_Central_Essentials_Attach" {return "Dynamics 365 Business Central Essentials Attach"}
        "DYN365_FINANCIALS_ACCOUNTANT_SKU" {return "Dynamics 365 Business Central External Accountant"}
        "PROJECT_MADEIRA_PREVIEW_IW_SKU" {return "Dynamics 365 Business Central for IWs"}
        "DYN365_BUSCENTRAL_PREMIUM" {return "Dynamics 365 Business Central Premium"}
        "DYN365_BUSCENTRAL_TEAM_MEMBER" {return "Dynamics 365 Business Central Team Members"}
        "DYN365_RETAIL" {return "Dynamics 365 Commerce"}
        "DYN365_RETAIL_TRIAL" {return "Dynamics 365 Commerce Trial"}
        "DYNAMICS_365_CONTACT_CENTER" {return "Dynamics 365 Contact Center"}
        "DYNAMICS_365_CONTACT_CENTER_ADD_ON_FOR_CUSTOMER_SERVICE_ENTERPRISE" {return "Dynamics 365 Contact Center Add-on for Customer Service Enterprise"}
        "DYNAMICS_365_CONTACT_CENTER_DIGITAL" {return "Dynamics 365 Contact Center Digital"}
        "DYNAMICS_365_CONTACT_CENTER_DIGITAL_ADD_ON_FOR_CUSTOMER_SERVICE_ENTERPRISE" {return "Dynamics 365 Contact Center Digital Add-on for Customer Service Enterprise"}
        "DYNAMICS_365_CONTACT_CENTER_VOICE" {return "Dynamics 365 Contact Center Voice"}
        "DYNAMICS_365_CONTACT_CENTER_VOICE_ADD_ON_FOR_CUSTOMER_SERVICE_ENTERPRISE" {return "Dynamics 365 Contact Center Voice Add-on for Customer Service Enterprise"}
        "DYN365_ENTERPRISE_PLAN1" {return "Dynamics 365 Plan 1 Enterprise Edition"}
        "DYN365_CUSTOMER_INSIGHTS_ATTACH" {return "Dynamics 365 Customer Insights Attach"}
        "DYN365_CUSTOMER_INSIGHTS_BASE" {return "Dynamics 365 Customer Insights Standalone"}
        "DYN365_CUSTOMER_INSIGHTS_VIRAL" {return "Dynamics 365 Customer Insights vTrial"}
        "DYN365_CS_CHAT_GOV" {return "Dynamics 365 for Customer Service Chat for Government"}
        "DYN365_CS_MESSAGING_GOV" {return "Dynamics 365 for Customer Service Digital Messaging add-on for Government"}
        "DYN365_CS_OC_MESSAGING_VOICE_GOV" {return "Dynamics 365 Customer Service Digital Messaging and Voice Add-in for Government"}
        "DYN365_CS_OC_MESSAGING_VOICE_GOV_TEST" {return "Dynamics 365 Customer Service Digital Messaging and Voice Add-in for Government for Test"}
        "Dynamics_365_Customer_Service_Enterprise_viral_trial" {return "Dynamics 365 Customer Service Enterprise Viral Trial"}
        "D365_CUSTOMER_SERVICE_ENT_ATTACH" {return "Dynamics 365 for Customer Service Enterprise Attach to Qualifying Dynamics 365 Base Offer A"}
        "DYN365_AI_SERVICE_INSIGHTS" {return "Dynamics 365 Customer Service Insights Trial"}
        "FORMS_PRO" {return "Dynamics 365 Customer Voice Trial"}
        "DYN365_CUSTOMER_SERVICE_PRO" {return "Dynamics 365 Customer Service Professional"}
        "DYN365_CUSTOMER_VOICE_BASE" {return "Dynamics 365 Customer Voice"}
        "Forms_Pro_AddOn" {return "Dynamics 365 Customer Voice Additional Responses"}
        "DYN365_CUSTOMER_VOICE_ADDON" {return "Dynamics 365 Customer Voice Additional Responses"}
        "Forms_Pro_USL" {return "Dynamics 365 Customer Voice USL"}
        "CRMSTORAGE_GCC" {return "Dynamics 365 Enterprise Edition - Additional Database Storage for Government"}
        "CRMTESTINSTANCE_NOPREREQ" {return "Dynamics 365 - Additional Non-Production Instance for Government"}
        "CRMTESTINSTANCE_GCC" {return "Dynamics 365 Enterprise Edition - Additional Non-Production Instance for Government"}
        "CRM_ONLINE_PORTAL" {return "Dynamics 365 Enterprise Edition - Additional Portal (Qualified Offer)"}
        "CRM_ONLINE_PORTAL_GCC" {return "Dynamics 365 Enterprise Edition - Additional Portal for Government"}
        "CRM_ONLINE_PORTAL_NOPREREQ" {return "Dynamics 365 Enterprise Edition - Additional Portal for Government"}
        "CRMINSTANCE_GCC" {return "Dynamics 365 Enterprise Edition - Additional Production Instance for Government"}
        "Dynamics_365_Field_Service_Enterprise_viral_trial" {return "Dynamics 365 Field Service Viral Trial"}
        "DYN365_FINANCE" {return "Dynamics 365 Finance"}
        "DYN365_ENTERPRISE_CASE_MANAGEMENT" {return "Dynamics 365 for Case Management Enterprise Edition"}
        "D365_ENTERPRISE_CASE_MANAGEMENT_GOV" {return "Dynamics 365 for Case Management, Enterprise Edition for Government"}
        "DYN365_ENTERPRISE_CASE_MANAGEMENT_GOV" {return "Dynamics 365 for Case Management, Enterprise Edition for Government"}
        "Dynamics_365_Customer_Service_Enterprise_admin_trial" {return "Dynamics 365 Customer Service Enterprise Admin"}
        "Dynamics_365_Customer_Insights_Attach_New" {return "Dynamics 365 Customer Insights Attach"}
        "Dynamics_365_Customer_Insights_Journeys_T3_Interacted_People" {return "Dynamics 365 Customer Insights Journeys T3 Interacted People"}
        "Dynamics_365_Customer_Insights_User_License" {return "Dynamics 365 Customer Insights User License"}
        "DYN365_ENTERPRISE_CUSTOMER_SERVICE" {return "Dynamics 365 for Customer Service Enterprise Edition"}
        "DYN365_ENTERPRISE_CUSTOMER_SERVICE_GOV" {return "Dynamics 365 for Customer Service, Enterprise Edition for Government"}
        "D365_ENTERPRISE_CUSTOMER_SERVICE_GOV" {return "Dynamics 365 for Customer Service Enterprise for Government"}
        "DYN365_CS_CHAT" {return "Dynamics 365 for Customer Service Chat"}
        "D365_CUSTOMER_SERVICE_PRO_ATTACH" {return "Dynamics 365 for Customer Service Professional Attach to Qualifying Dynamics 365 Base Offer"}
        "DYN365_CS_VOICE" {return "Dynamics 365 Customer Service Voice Channel Add-in"}
        "D365_FIELD_SERVICE_ATTACH" {return "Dynamics 365 for Field Service Attach to Qualifying Dynamics 365 Base Offer"}
        "DYN365_ENTERPRISE_FIELD_SERVICE" {return "Dynamics 365 for Field Service Enterprise Edition"}
        "D365_FIELD_SERVICE_CONTRACTOR_GOV" {return "Dynamics 365 Field Service Contractor for Government"}
        "CRM_AUTO_ROUTING_ADDON" {return "Dynamics 365 Field Service, Enterprise Edition - Resource Scheduling Optimization"}
        "D365_ENTERPRISE_FIELD_SERVICE_GOV" {return "Dynamics 365 for Field Service for Government"}
        "DYN365_ENTERPRISE_FIELD_SERVICE_GOV" {return "Dynamics 365 for Field Service Enterprise Edition for Government"}
        "DYN365_FINANCIALS_BUSINESS_SKU" {return "Dynamics 365 for Financials Business Edition"}
        "DYN365_FINANCE_ATTACH" {return "Dynamics 365 for Finance Attach to Qualifying Dynamics 365 Base Offer"}
        "DYN365_FINANCE_ATTACH_ISVEMB_PROJOPS" {return "Dynamics 365 Finance Attach to Qualifying Base Offer Embedded with Project Management & Accounting"}
        "Dynamics_365_Guides_vTrial" {return "Dynamics 365 Guides vTrial"}
        "DYN365_HUMAN_RESOURCES_ATTACH" {return "Dynamics 365 Human Resources Attach to Qualifying Dynamics 365 Base Offer"}
        "CRM_HYBRIDCONNECTOR" {return "Dynamics 365 Hybrid Connector"}
        "DYN365_MARKETING_APPLICATION_ADDON" {return "Dynamics 365 for Marketing Additional Application"}
        "DYN365_MARKETING_CONTACT_ADDON" {return "Dynamics 365 for Marketing Addnl Contacts Tier 1"}
        "DYN365_MARKETING_CONTACT_ADDON_T3" {return "Dynamics 365 for Marketing Additional Contacts Tier 3"}
        "DYN365_MARKETING_SANDBOX_APPLICATION_ADDON" {return "Dynamics 365 for Marketing Additional Non-Prod Application"}
        "DYN365_MARKETING_CONTACT_ADDON_T5" {return "Dynamics 365 for Marketing Addnl Contacts Tier 5"}
        "DYN365_MARKETING_APP_ATTACH" {return "Dynamics 365 for Marketing Attach"}
        "DYN365_BUSINESS_MARKETING" {return "Dynamics 365 for Marketing Business Edition"}
        "D365_MARKETING_USER" {return "Dynamics 365 for Marketing USL"}
        "Dynamics_365_Multi_app_" {return "Dynamics 365 Multi-app"}
        "Dyn365_Operations_Activity" {return "Dynamics 365 Operations - Activity"}
        "DYN365_PROJECT_OPERATIONS_ATTACH" {return "Dynamics 365 Project Operations Attach"}
        "D365_ENTERPRISE_PROJECT_SERVICE_AUTOMATION_GOV" {return "Dynamics 365 for Project Service Automation for Government"}
        "DYN365_ENTERPRISE_PROJECT_SERVICE_AUTOMATION_GOV" {return "Dynamics 365 for Project Service Automation Enterprise Edition for Government"}
        "DYN365_ENTERPRISE_SALES_CUSTOMERSERVICE" {return "Dynamics 365 for Sales and Customer Service Enterprise Edition"}
        "DYN365_ENTERPRISE_SALES" {return "Dynamics 365 for Sales Enterprise Edition"}
        "DYN365_ENTERPRISE_SALES_GOV" {return "Dynamics 365 for Sales, Enterprise Edition for Government"}
        "D365_ENTERPRISE_SALES_GOV" {return "Dynamics 365 for Sales Enterprise for Government"}
        "Dynamics_365_Sales_Field_Service_and_Customer_Service_Partner_Sandbox" {return "Dynamics 365 Sales, Field Service and Customer Service Partner Sandbox"}
        "DYN365_SALES_PREMIUM" {return "Dynamics 365 Sales Premium"}
        "D365_SALES_PRO" {return "Dynamics 365 for Sales Professional"}
        "D365_SALES_PRO_GOV" {return "Dynamics 365 for Sales Professional for Government"}
        "D365_SALES_PRO_IW" {return "Dynamics 365 for Sales Professional Trial"}
        "D365_SALES_PRO_ATTACH" {return "Dynamics 365 for Sales Professional Attach to Qualifying Dynamics 365 Base Offer"}
        "DYN365_SCM" {return "Dynamics 365 for Supply Chain Management"}
        "Dynamics_365_Supply_Chain_Management_Premium" {return "Dynamics 365 Supply Chain Management Premium"}
        "SKU_Dynamics_365_for_HCM_Trial" {return "Dynamics 365 for Talent"}
        "DYN365_ENTERPRISE_TEAM_MEMBERS" {return "Dynamics 365 for Team Members Enterprise Edition"}
        "DYN365_ENTERPRISE_TEAM_MEMBERS_GOV" {return "Dynamics 365 for Team Members Enterprise Edition for Government"}
        "GUIDES_USER" {return "Dynamics 365 Guides"}
        "Dynamics_365_for_Operations_Devices" {return "Dynamics 365 Operations - Device"}
        "Dynamics_365_for_Operations_Sandbox_Tier2_SKU" {return "Dynamics 365 Operations - Sandbox Tier 2:Standard Acceptance Testing"}
        "Dynamics_365_for_Operations_Sandbox_Tier4_SKU" {return "Dynamics 365 Operations - Sandbox Tier 4:Standard Performance Testing"}
        "DYN365_ENTERPRISE_P1_IW" {return "Dynamics 365 P1 Trial for Information Workers"}
        "DYN365_PROJECT_OPERATIONS" {return "Dynamics 365 Project Operations"}
        "DYN365_REGULATORY_SERVICE" {return "Dynamics 365 Regulatory Service - Enterprise Edition Trial"}
        "MICROSOFT_REMOTE_ASSIST" {return "Dynamics 365 Remote Assist"}
        "MICROSOFT_REMOTE_ASSIST_HOLOLENS" {return "Dynamics 365 Remote Assist HoloLens"}
        "D365_SALES_ENT_ATTACH" {return "Dynamics 365 Sales Enterprise Attach to Qualifying Dynamics 365 Base Offer"}
        "Dynamics_365_Sales_Premium_Viral_Trial" {return "Dynamics 365 Sales Premium Viral Trial"}
        "DYN365_SCM_ATTACH" {return "Dynamics 365 for Supply Chain Management Attach to Qualifying Dynamics 365 Base Offer"}
        "Dynamics_365_Hiring_SKU" {return "Dynamics 365 Talent: Attract"}
        "DYNAMICS_365_ONBOARDING_SKU" {return "Dynamics 365 Talent: Onboard"}
        "DYN365_TEAM_MEMBERS" {return "Dynamics 365 Team Members_wDynamicsRetail"}
        "Dynamics_365_for_Operations" {return "Dynamics 365 UNF OPS Plan ENT Edition"}
        "EMS_EDU_FACULTY" {return "Enterprise Mobility + Security A3 for Faculty"}
        "EMS" {return "Enterprise Mobility + Security E3"}
        "EMSPREMIUM" {return "Enterprise Mobility + Security E5"}
        "EMSPREMIUM_USGOV_GCCHIGH" {return "Enterprise Mobility + Security E5_USGOV_GCCHIGH"}
        "EMS_GOV" {return "Enterprise Mobility + Security G3 GCC"}
        "EMSPREMIUM_GOV" {return "Enterprise Mobility + Security G5 GCC"}
        "EOP_ENTERPRISE_PREMIUM" {return "Exchange Enterprise CAL Services (EOP, DLP)"}
        "EXCHANGESTANDARD" {return "Exchange Online (Plan 1)"}
        "EXCHANGESTANDARD_STUDENT" {return "Exchange Online (Plan 1) for Students"}
        "EXCHANGESTANDARD_ALUMNI" {return "Exchange Online (Plan 1) for Alumni with Yammer"}
        "EXCHANGEENTERPRISE" {return "Exchange Online (PLAN 2)"}
        "EXCHANGEENTERPRISE_FACULTY" {return "Exchange Online (Plan 2) for Faculty"}
        "EXCHANGEENTERPRISE_GOV" {return "Exchange Online (Plan 2) for GCC"}
        "EXCHANGEARCHIVE_ADDON" {return "Exchange Online Archiving for Exchange Online"}
        "EXCHANGEARCHIVE" {return "Exchange Online Archiving for Exchange Server"}
        "EXCHANGEESSENTIALS" {return "Exchange Online Essentials (ExO P1 Based)"}
        "EXCHANGE_S_ESSENTIALS" {return "Exchange Online Essentials"}
        "EXCHANGEDESKLESS" {return "Exchange Online Kiosk"}
        "EXCHANGESTANDARD_GOV" {return "Exchange Online (Plan 1) for GCC"}
        "EXCHANGETELCO" {return "Exchange Online POP"}
        "EOP_ENTERPRISE" {return "Exchange Online Protection"}
        "INTUNE_A" {return "Intune"}
        "INTUNE_EDU" {return "Intune for Education"}
        "AX7_USER_TRIAL" {return "Microsoft Dynamics AX7 User Trial"}
        "MFA_STANDALONE" {return "Microsoft Azure Multi-Factor Authentication"}
        "THREAT_INTELLIGENCE" {return "Microsoft Defender for Office 365 (Plan 2)"}
        "M365EDU_A1" {return "Microsoft 365 A1"}
        "M365EDU_A3_FACULTY" {return "Microsoft 365 A3 for faculty"}
        "M365EDU_A3_STUDENT" {return "Microsoft 365 A3 for students"}
        "M365EDU_A3_STUUSEBNFT" {return "Microsoft 365 A3 student use benefits"}
        "Microsoft_365_A3_Suite_features_for_faculty" {return "Microsoft 365 A3 Suite features for faculty"}
        "M365EDU_A3_STUUSEBNFT_RPA1" {return "Microsoft 365 A3 - Unattended License for students use benefit"}
        "M365EDU_A5_FACULTY" {return "Microsoft 365 A5 for faculty"}
        "M365EDU_A5_STUDENT" {return "Microsoft 365 A5 for students"}
        "M365EDU_A5_STUUSEBNFT" {return "Microsoft 365 A5 student use benefits"}
        "M365_A5_SUITE_COMPONENTS_FACULTY" {return "Microsoft 365 A5 Suite features for faculty"}
        "M365EDU_A5_NOPSTNCONF_STUUSEBNFT" {return "Microsoft 365 A5 without Audio Conferencing for students use benefit"}
        "O365_BUSINESS" {return "Microsoft 365 Apps for Business"}
        "SMB_BUSINESS" {return "Microsoft 365 Apps for Business"}
        "OFFICESUBSCRIPTION" {return "Microsoft 365 Apps for enterprise"}
        "OFFICE_PROPLUS_DEVICE1" {return "Microsoft 365 Apps for enterprise (device)"}
        "OFFICESUBSCRIPTION_FACULTY" {return "Microsoft 365 Apps for Faculty"}
        "OFFICESUBSCRIPTION_STUDENT" {return "Microsoft 365 Apps for Students"}
        "MCOMEETADV_GOV" {return "Microsoft 365 Audio Conferencing for GCC"}
        "MCOACBYOT_AR_GCCHIGH_USGOV_GCCHIGH" {return "Microsoft 365 Audio Conferencing - GCCHigh Tenant (AR)_USGOV_GCCHIGH"}
        "MCOMEETADV_USGOV_GCCHIGH" {return "Microsoft 365 Audio Conferencing_USGOV_GCCHIGH"}
        "MCOMEETACPEA" {return "Microsoft 365 Audio Conferencing Pay-Per-Minute - EA"}
        "O365_BUSINESS_ESSENTIALS" {return "Microsoft 365 Business Basic"}
        "SMB_BUSINESS_ESSENTIALS" {return "Microsoft 365 Business Basic"}
        "Microsoft_365_Business_Basic_EEA_(no_Teams)" {return "Microsoft 365 Business Basic EEA (no Teams)"}
        "Microsoft_365_Business_Basic_(no Teams)" {return "Microsoft 365 Business Basic (no Teams)"}
        "O365_BUSINESS_PREMIUM" {return "Microsoft 365 Business Standard"}
        "MICROSOFT_365_BUSINESS_STANDARD_NO_TEAMS" {return "Microsoft 365 Business Standard (no Teams)"}
        "Microsoft_365_Business_Standard_EEA_(no_Teams)" {return "Microsoft 365 Business Standard EEA (no Teams)"}
        "Office_365_w/o_Teams_Bundle_Business_Standard" {return "Microsoft 365 Business Standard EEA (no Teams)"}
        "SMB_BUSINESS_PREMIUM" {return "Microsoft 365 Business Standard - Prepaid Legacy"}
        "SPB" {return "Microsoft 365 Business Premium"}
        "Microsoft_365_ Business_ Premium_(no Teams)" {return "Microsoft 365 Business Premium (no Teams)"}
        "Microsoft_365_Business_Premium_Donation_(Non_Profit_Pricing)" {return "Microsoft 365 Business Premium Donation"}
        "Office_365_w/o_Teams_Bundle_Business_Premium" {return "Microsoft 365 Business Premium EEA (no Teams)"}
        "BUSINESS_VOICE_MED2_TELCO" {return "Microsoft 365 Business Voice (US)"}
        "BUSINESS_VOICE_DIRECTROUTING" {return "Microsoft 365 Business Voice (without Calling Plan)"}
        "BUSINESS_VOICE_DIRECTROUTING_MED" {return "Microsoft 365 Business Voice (without Calling Plan) for US"}
        "BUSINESS_VOICE_MED2" {return "Microsoft 365 Business Voice"}
        "BUSINESS_VOICE" {return "Microsoft 365 Business Voice (UK)"}
        "Microsoft_365_Copilot_EDU" {return "Microsoft 365 Copilot (Education Faculty)"}
        "Microsoft_Copilot_for_Sales" {return "Microsoft 365 Copilot for Sales"}
        "MCOPSTN5_US" {return "Microsoft 365 Domestic Calling Plan (120 minutes) - US"}
        "MCOPSTN_1_GOV" {return "Microsoft 365 Domestic Calling Plan for GCC"}
        "SPE_E3" {return "Microsoft 365 E3"}
        "Microsoft_365_E3_(no_Teams)" {return "Microsoft 365 E3 (no Teams)"}
        "O365_w/o Teams Bundle_M3" {return "Microsoft 365 E3 EEA (no Teams)"}
        "Microsoft_365_E3_EEA_(no_Teams)_Unattended_License" {return "Microsoft 365 E3 EEA (no Teams) - Unattended License"}
        "O365_w/o Teams Bundle_M3_(500_seats_min)_HUB" {return "Microsoft 365 E3 EEA (no Teams) (500 seats min)_HUB"}
        "Microsoft_365_E3_Extra_Features" {return "Microsoft 365 E3 Extra Features"}
        "SPE_E3_RPA1" {return "Microsoft 365 E3 - Unattended License"}
        "Microsoft_365_E3" {return "Microsoft 365 E3 (500 seats min)_HUB"}
        "SPE_E3_USGOV_DOD" {return "Microsoft 365 E3_USGOV_DOD"}
        "SPE_E3_USGOV_GCCHIGH" {return "Microsoft 365 E3_USGOV_GCCHIGH"}
        "SPE_E5" {return "Microsoft 365 E5"}
        "Microsoft_365_E5" {return "Microsoft 365 E5 (500 seats min)_HUB"}
        "DEVELOPERPACK_E5" {return "Microsoft 365 E5 Developer (without Windows and Audio Conferencing)"}
        "INFORMATION_PROTECTION_COMPLIANCE" {return "Microsoft 365 E5 Compliance"}
        "O365_w/o_Teams_Bundle_M5" {return "Microsoft 365 E5 EEA (no Teams)"}
        "O365_w/o_Teams_Bundle_M5_(500_seats_min)_HUB" {return "Microsoft 365 E5 EEA (no Teams) (500 seats min)_HUB"}
        "Microsoft_365_E5_EEA_(no_Teams)_with_Calling_Minutes" {return "Microsoft 365 E5 EEA (no Teams) with Calling Minutes"}
        "Microsoft_365_E5_EEA_(no_Teams)_without_Audio_Conferencing" {return "Microsoft 365 E5 EEA (no Teams) without Audio Conferencing"}
        "Microsoft_365_E5_EEA_(no_Teams)without_Audio_Conferencing(500_seats_min)_HUB" {return "Microsoft 365 E5 EEA (no Teams) without Audio Conferencing (500 seats min)_HUB"}
        "IDENTITY_THREAT_PROTECTION" {return "Microsoft 365 E5 Security"}
        "IDENTITY_THREAT_PROTECTION_FOR_EMS_E5" {return "Microsoft 365 E5 Security for EMS E5"}
        "SPE_E5_CALLINGMINUTES" {return "Microsoft 365 E5 with Calling Minutes"}
        "SPE_E5_NOPSTNCONF" {return "Microsoft 365 E5 without Audio Conferencing"}
        "Microsoft_365_E5_without_Audio_Conferencing" {return "Microsoft 365 E5 without Audio Conferencing (500 seats min)_HUB"}
        "M365_F1" {return "Microsoft 365 F1"}
        "Microsoft_365_F1_EEA_(no_Teams)" {return "Microsoft 365 F1 EEA (no Teams)"}
        "SPE_F1" {return "Microsoft 365 F3"}
        "Microsoft_365_F3_EEA_(no_Teams)" {return "Microsoft 365 F3 EEA (no Teams)"}
        "SPE_F5_COMP" {return "Microsoft 365 F5 Compliance Add-on"}
        "SPE_F5_COMP_AR_D_USGOV_DOD" {return "Microsoft 365 F5 Compliance Add-on AR DOD_USGOV_DOD"}
        "SPE_F5_COMP_AR_USGOV_GCCHIGH" {return "Microsoft 365 F5 Compliance Add-on AR_USGOV_GCCHIGH"}
        "SPE_F5_COMP_GCC" {return "Microsoft 365 F5 Compliance Add-on GCC"}
        "SPE_F5_SEC" {return "Microsoft 365 F5 Security Add-on"}
        "SPE_F5_SECCOMP" {return "Microsoft 365 F5 Security + Compliance Add-on"}
        "FLOW_FREE" {return "Microsoft Power Automate Free"}
        "M365_E5_SUITE_COMPONENTS" {return "Microsoft 365 E5 Extra Features"}
        "M365_F1_COMM" {return "Microsoft 365 F1"}
        "SPE_E5_USGOV_GCCHIGH" {return "Microsoft 365 E5_USGOV_GCCHIGH"}
        "M365_F1_GOV" {return "Microsoft 365 F3 GCC"}
        "M365_G3_GOV" {return "Microsoft 365 G3 GCC"}
        "M365_G3_RPA1_GOV" {return "Microsoft 365 G3 - Unattended License for GCC"}
        "M365_G5_GCC" {return "Microsoft 365 GCC G5"}
        "M365_G5_GOV" {return "Microsoft 365 GCC G5 w/o WDATP/CAS Unified"}
        "Microsoft365_Lighthouse" {return "Microsoft 365 Lighthouse"}
        "M365_SECURITY_COMPLIANCE_FOR_FLW" {return "Microsoft 365 Security and Compliance for Firstline Workers"}
        "MICROSOFT_BUSINESS_CENTER" {return "Microsoft Business Center"}
        "Microsoft_Cloud_for_Sustainability_vTrial" {return "Microsoft Cloud for Sustainability vTrial"}
        "ADALLOM_STANDALONE" {return "Microsoft Cloud App Security"}
        "Power_Virtual_Agents" {return "Microsoft Copilot Studio"}
        "Power_Virtual_Agents_for_GCC_GCC" {return "Microsoft Copilot Studio for GCC"}
        "VIRTUAL_AGENT_USL_GCC" {return "Microsoft Copilot Studio User License for GCC"}
        "VIRTUAL_AGENT_USL_AR_USGOV_GCCHIGH" {return "Microsoft Copilot Studio User License for GCC High_USGOV_GCCHIGH"}
        "Power_Virtual_Agents_USGOV_GCCHIGH" {return "Microsoft Copilot Studio_USGOV_GCCHIGH"}
        "CCIBOTS_PRIVPREV_VIRAL" {return "Microsoft Copilot Studio Viral Trial"}
        "VIRTUAL_AGENT_USL" {return "Microsoft Copilot Studio User License"}
        "MDE_SMB" {return "Microsoft Defender for Business"}
        "WIN_DEF_ATP" {return "Microsoft Defender for Endpoint"}
        "Microsoft_Defender_for_Endpoint_F2" {return "Microsoft Defender for Endpoint F2"}
        "DEFENDER_ENDPOINT_P1" {return "Microsoft Defender for Endpoint P1"}
        "DEFENDER_ENDPOINT_P1_EDU" {return "Microsoft Defender for Endpoint P1 for EDU"}
        "MDATP_XPLAT" {return "Microsoft Defender for Endpoint P2_XPLAT"}
        "MDATP_Server" {return "Microsoft Defender for Endpoint Server"}
        "ATP_ENTERPRISE_FACULTY" {return "Microsoft Defender for Office 365 (Plan 1) Faculty"}
        "CRMPLAN2" {return "Microsoft Dynamics CRM Online Basic"}
        "ATA" {return "Microsoft Defender for Identity"}
        "ATP_ENTERPRISE_GOV" {return "Microsoft Defender for Office 365 (Plan 1) GCC"}
        "ATP_ENTERPRISE_STUDENT" {return "Microsoft Defender for Office 365 (Plan 1) Student"}
        "ATP_ENTERPRISE_STUDENTS_USE_BENEFIT" {return "Microsoft Defender for Office 365 (Plan 1) Student use benefit"}
        "ATP_ENTERPRISE_USGOV_GCCHIGH" {return "Microsoft Defender for Office 365 (Plan 1)_USGOV_GCCHIGH"}
        "THREAT_INTELLIGENCE_GOV" {return "Microsoft Defender for Office 365 (Plan 2) GCC"}
        "TVM_Premium_Standalone" {return "Microsoft Defender Vulnerability Management"}
        "TVM_Premium_Add_on" {return "Microsoft Defender Vulnerability Management Add-on"}
        "CRMSTANDARD" {return "Microsoft Dynamics CRM Online"}
        "CRMPLAN2_GCC" {return "Microsoft Dynamics CRM Online Basic for Government"}
        "CRMSTANDARD_GCC" {return "Microsoft Dynamics CRM Online for Government"}
        "Microsoft_Entra_ID_Governance" {return "Microsoft Entra ID Governance"}
        "Microsoft_Entra_Suite_Step_Up_for_Microsoft_Entra_ID_P2" {return "Microsoft Entra Suite Add-on for Microsoft Entra ID P2"}
        "POWER_BI_STANDARD" {return "Microsoft Fabric (Free)"}
        "POWER_BI_STANDARD_FACULTY" {return "Microsoft Fabric (Free) for faculty"}
        "POWER_BI_STANDARD_STUDENT" {return "Microsoft Fabric (Free) for student"}
        "IT_ACADEMY_AD" {return "Microsoft Imagine Academy"}
        "Microsoft_Intune_Advanced_Analytics" {return "Microsoft Intune Advanced Analytics"}
        "INTUNE_A_D" {return "Microsoft Intune Device"}
        "INTUNE_A_D_GOV" {return "Microsoft Intune Device for Government"}
        "INTUNE_A_GOV" {return "Microsoft Intune Government"}
        "INTUNE_A_VL" {return "Microsoft Intune Plan 1 A VL"}
        "INTUNE_A_VL_USGOV_GCCHIGH" {return "Microsoft Intune Plan 1 A VL_USGOV_GCCHIGH"}
        "Microsoft_Intune_Suite" {return "Microsoft Intune Suite"}
        "POWERAPPS_VIRAL" {return "Microsoft Power Apps Plan 2 Trial"}
        "FLOW_P2" {return "Microsoft Power Automate Plan 2"}
        "INTUNE_SMB" {return "Microsoft Intune SMB"}
        "POWERAPPS_DEV" {return "Microsoft PowerApps for Developer"}
        "POWERFLOW_P2" {return "Microsoft Power Apps Plan 2 (Qualified Offer)"}
        "DYN365_ENTERPRISE_RELATIONSHIP_SALES" {return "Microsoft Relationship Sales solution"}
        "STREAM" {return "Microsoft Stream"}
        "STREAM_P2" {return "Microsoft Stream Plan 2"}
        "STREAM_STORAGE" {return "Microsoft Stream Storage Add-On (500 GB)"}
        "Microsoft_Sustainability_Manager_Premium" {return "Microsoft Sustainability Manager Premium"}
        "MICROSOFT_SUSTAINABILITY_MANAGER_PREMIUM_USL_ADDON" {return "Microsoft Sustainability Manager Premium USL Plus"}
        "Microsoft_Cloud_for_Sustainability_USL" {return "Microsoft Sustainability Manager USL Essentials"}
        "Microsoft_Teams_Audio_Conferencing_select_dial_out" {return "Microsoft Teams Audio Conferencing with dial-out to USA/CAN"}
        "TEAMS_FREE" {return "Microsoft Teams (Free)"}
        "Microsoft_Teams_Calling_Plan_pay_as_you_go_(country_zone_1_US)" {return "Microsoft Teams Calling Plan pay-as-you-go (country zone 1 - US)"}
        "MCOPSTN_6" {return "Microsoft Teams Domestic Calling Plan (240 min)"}
        "Microsoft_Teams_EEA_New" {return "Microsoft Teams EEA"}
        "Teams_Ess" {return "Microsoft Teams Essentials"}
        "TEAMS_ESSENTIALS_AAD" {return "Microsoft Teams Essentials (Microsoft Entra identity)"}
        "TEAMS_EXPLORATORY" {return "Microsoft Teams Exploratory"}
        "Microsoft_Teams_Exploratory_Dept" {return "Microsoft Teams Exploratory Dept"}
        "MCOEV" {return "Microsoft Teams Phone Standard"}
        "MCOEV_DOD" {return "Microsoft Teams Phone Standard for DOD"}
        "MCOEV_FACULTY" {return "Microsoft Teams Phone Standard for Faculty"}
        "MCOEV_GOV" {return "Microsoft Teams Phone Standard for GCC"}
        "MCOEV_GCCHIGH" {return "Microsoft Teams Phone Standard for GCCHIGH"}
        "MCOEVSMB_1" {return "Microsoft Teams Phone Standard for Small and Medium Business"}
        "MCOEV_STUDENT" {return "Microsoft Teams Phone Standard for Student"}
        "MCOEV_TELSTRA" {return "Microsoft Teams Phone Standard for TELSTRA"}
        "MCOEV_USGOV_DOD" {return "Microsoft Teams Phone Standard_System_USGOV_DOD"}
        "MCOEV_USGOV_GCCHIGH" {return "Microsoft Teams Phone Standard_USGOV_GCCHIGH"}
        "PHONESYSTEM_VIRTUALUSER" {return "Microsoft Teams Phone Resource Account"}
        "PHONESYSTEM_VIRTUALUSER_FACULTY" {return "Microsoft Teams Phone Resource Account for Faculty"}
        "PHONESYSTEM_VIRTUALUSER_GOV" {return "Microsoft Teams Phone Resource Account for GCC"}
        "PHONESYSTEM_VIRTUALUSER_USGOV_GCCHIGH" {return "Microsoft Teams Phone Resource Account_USGOV_GCCHIGH"}
        "Microsoft_Teams_Premium" {return "Microsoft Teams Premium Introductory Pricing"}
        "Microsoft_Teams_Rooms_Basic" {return "Microsoft Teams Rooms Basic"}
        "Microsoft_Teams_Rooms_Basic_FAC" {return "Microsoft Teams Rooms Basic for EDU"}
        "Microsoft_Teams_Rooms_Basic_without_Audio_Conferencing" {return "Microsoft Teams Rooms Basic without Audio Conferencing"}
        "MTR_PREM" {return "Teams Rooms Premium"}
        "Microsoft_Teams_Rooms_Pro" {return "Microsoft Teams Rooms Pro"}
        "Microsoft_Teams_Rooms_Pro_FAC" {return "Microsoft Teams Rooms Pro for EDU"}
        "Microsoft_Teams_Rooms_Pro_GCC" {return "Microsoft Teams Rooms Pro for GCC"}
        "Microsoft_Teams_Rooms_Pro_without_Audio_Conferencing" {return "Microsoft Teams Rooms Pro without Audio Conferencing"}
        "MEETING_ROOM" {return "Microsoft Teams Rooms Standard"}
        "MEETING_ROOM_GOV" {return "Microsoft Teams Rooms Standard for GCC"}
        "MEETING_ROOM_GOV_NOAUDIOCONF" {return "Microsoft Teams Rooms Standard for GCC without Audio Conferencing"}
        "MEETING_ROOM_NOAUDIOCONF" {return "Microsoft Teams Rooms Standard without Audio Conferencing"}
        "MCOCAP" {return "Microsoft Teams Shared Devices"}
        "MCOCAP_FACULTY" {return "Microsoft Teams Shared Devices for Faculty"}
        "MCOCAP_GOV" {return "Microsoft Teams Shared Devices for GCC"}
        "MS_TEAMS_IW" {return "Microsoft Teams Trial"}
        "EXPERTS_ON_DEMAND" {return "Microsoft Threat Experts - Experts on Demand"}
        "WORKPLACE_ANALYTICS" {return "Microsoft Workplace Analytics"}
        "Microsoft_Viva_Goals" {return "Microsoft Viva Goals"}
        "Viva_Glint_Standalone" {return "Microsoft Viva Glint"}
        "VIVA" {return "Microsoft Viva Suite"}
        "MEE_FACULTY" {return "Minecraft Education Faculty"}
        "MEE_STUDENT" {return "Minecraft Education Student"}
        "OFFICE365_MULTIGEO" {return "Office 365 Multi-Geo Capabilities"}
        "NONPROFIT_PORTAL" {return "Nonprofit Portal"}
        "STANDARDWOFFPACK_FACULTY" {return "Office 365 A1 for faculty"}
        "STANDARDWOFFPACK_IW_FACULTY" {return "Office 365 A1 Plus for Faculty"}
        "STANDARDWOFFPACK_STUDENT" {return "Office 365 A1 for students"}
        "STANDARDWOFFPACK_IW_STUDENT" {return "Office 365 A1 Plus for Students"}
        "ENTERPRISEPACKPLUS_FACULTY" {return "Office 365 A3 for Faculty"}
        "ENTERPRISEPACKPLUS_STUDENT" {return "Office 365 A3 for Students"}
        "ENTERPRISEPREMIUM_FACULTY" {return "Office 365 A5 for faculty"}
        "ENTERPRISEPREMIUM_STUDENT" {return "Office 365 A5 for students"}
        "EQUIVIO_ANALYTICS" {return "Office 365 Advanced Compliance"}
        "M365_Copilot" {return "Microsoft Copilot for Microsoft 365"}
        "ATP_ENTERPRISE" {return "Microsoft Defender for Office 365 (Plan 1)"}
        "SHAREPOINTSTORAGE_GOV" {return "Office 365 Extra File Storage for GCC"}
        "TEAMS_COMMERCIAL_TRIAL" {return "Microsoft Teams Commercial Cloud"}
        "Microsoft_Viva_Sales" {return "Microsoft Sales Copilot"}
        "ADALLOM_O365" {return "Office 365 Cloud App Security"}
        "SHAREPOINTSTORAGE" {return "Office 365 Extra File Storage"}
        "STANDARDPACK" {return "Office 365 E1"}
        "Office_365_w/o_Teams_Bundle_E1" {return "Office 365 E1 EEA (no Teams)"}
        "STANDARDPACK_USGOV_GCCHIGH" {return "Office 365 E1_USGOV_GCCHIGH"}
        "STANDARDWOFFPACK" {return "Office 365 E2"}
        "ENTERPRISEPACK" {return "Office 365 E3"}
        "Office_365_E3_(no_Teams)" {return "Office 365 E3 (no Teams)"}
        "O365_w/o_Teams_Bundle_E3" {return "Office 365 E3 EEA (no Teams)"}
        "DEVELOPERPACK" {return "Office 365 E3 Developer"}
        "ENTERPRISEPACK_USGOV_DOD" {return "Office 365 E3_USGOV_DOD"}
        "ENTERPRISEPACK_USGOV_GCCHIGH" {return "Office 365 E3_USGOV_GCCHIGH"}
        "ENTERPRISEWITHSCAL" {return "Office 365 E4"}
        "ENTERPRISEPREMIUM" {return "Office 365 E5"}
        "Office_365_w/o_Teams_Bundle_E5" {return "Office 365 E5 EEA (no Teams)"}
        "Office_365_E5_EEA_(no_Teams)_without_Audio_Conferencing" {return "Office 365 E5 EEA (no Teams) without Audio Conferencing"}
        "ENTERPRISEPREMIUM_NOPSTNCONF" {return "Office 365 E5 without Audio Conferencing"}
        "DESKLESSPACK" {return "Office 365 F3"}
        "Office_365_F3_EEA_(no_Teams)" {return "Office 365 F3 EEA (no Teams)"}
        "DESKLESSPACK_USGOV_GCCHIGH" {return "Office 365 F3_USGOV_GCCHIGH"}
        "STANDARDPACK_GOV" {return "Office 365 G1 GCC"}
        "ENTERPRISEPACK_GOV" {return "Office 365 G3 GCC"}
        "ENTERPRISEPACKWITHOUTPROPLUS_GOV" {return "Office 365 G3 without Microsoft 365 Apps GCC"}
        "ENTERPRISEPREMIUM_GOV" {return "Office 365 G5 GCC"}
        "ENTERPRISEPREMIUM_NOPBIPBX_GOV" {return "Office 365 GCC G5 without Power BI and Phone System"}
        "ENTERPRISEPREMIUM_NOPSTNCONF_NOPBI_GOV" {return "Office 365 GCC G5 without Audio Conferencing"}
        "EQUIVIO_ANALYTICS_GOV" {return "Office 365 Advanced Compliance for GCC"}
        "MIDSIZEPACK" {return "Office 365 Midsize Business"}
        "LITEPACK" {return "Office 365 Small Business"}
        "LITEPACK_P2" {return "Office 365 Small Business Premium"}
        "OFFICEMOBILE_SUBSCRIPTION_GOV_TEST" {return "Office Mobile Apps for Office 365 for GCC"}
        "WACONEDRIVESTANDARD" {return "OneDrive for Business (Plan 1)"}
        "WACONEDRIVEENTERPRISE" {return "OneDrive for Business (Plan 2)"}
        "POWERFLOWGCC_TEST" {return "PowerApps & Flow GCC Test - O365 & Dyn365 Plans"}
        "POWERAPPS_INDIVIDUAL_USER" {return "Power Apps and Logic Flows"}
        "POWERAPPS_PER_APP_IW" {return "Power Apps per app baseline access"}
        "POWERAPPS_PER_APP" {return "Power Apps per app Plan"}
        "POWERAPPS_PER_APP_NEW" {return "Power Apps per app Plan (1 app or portal)"}
        "POWERAPPS_PER_APP_BD_ONLY_GCC" {return "Power Apps Per App BD Only for GCC"}
        "Power_Apps_per_app_plan_(1_app_or_portal)_BD_Only_GCC" {return "Power Apps per app plan (1 app or website) BD Only - GCC"}
        "POWERAPPS_PER_APP_GCC_NEW" {return "Power Apps per app plan (1 app or website) for Government"}
        "POWERAPPS_PER_APP_GCC" {return "Power Apps per app plan for Government"}
        "POWERAPPS_PER_USER_BD_ONLY" {return "Power Apps Per User BD Only"}
        "POWERAPPS_PER_USER" {return "Power Apps Premium"}
        "POWERAPPS_PER_USER_GCC" {return "Power Apps Premium for Government"}
        "POWERAPPS_P1_GOV" {return "Power Apps Plan 1 for Government"}
        "POWERAPPS_PORTALS_PAGEVIEW" {return "Power Apps Portals page view capacity add-on"}
        "POWERAPPS_PORTALS_PAGEVIEW_GCC" {return "Power Apps Portals page view capacity add-on for Government"}
        "FLOW_BUSINESS_PROCESS" {return "Power Automate per flow plan"}
        "FLOW_BUSINESS_PROCESS_GCC" {return "Power Automate per flow plan for Government"}
        "FLOW_PER_USER" {return "Power Automate per user plan"}
        "FLOW_PER_USER_DEPT" {return "Power Automate per user plan dept"}
        "FLOW_PER_USER_GCC" {return "Power Automate per user plan for Government"}
        "POWERAUTOMATE_ATTENDED_RPA" {return "Power Automate Premium"}
        "FLOW_P1_GOV" {return "Power Automate Plan 1 for Government (Qualified Offer)"}
        "POWERAUTOMATE_ATTENDED_RPA_GCC" {return "Power Automate Premium for Government"}
        "Power_Automate_per_process" {return "Power Automate Process"}
        "POWERAUTOMATE_UNATTENDED_RPA" {return "Power Automate unattended RPA add-on"}
        "POWERAUTOMATE_UNATTENDED_RPA_GCC" {return "Power Automate unattended RPA add-on for Government"}
        "POWER_BI_INDIVIDUAL_USER" {return "Power BI"}
        "POWER_BI_ADDON" {return "Power BI for Office 365 Add-On"}
        "PBI_PREMIUM_P1_ADDON" {return "Power BI Premium P1"}
        "PBI_PREMIUM_P1_ADDON_GCC" {return "Power BI Premium P1 GCC"}
        "PBI_PREMIUM_PER_USER" {return "Power BI Premium Per User"}
        "PBI_PREMIUM_PER_USER_ADDON" {return "Power BI Premium Per User Add-On"}
        "PBI_PREMIUM_PER_USER_ADDON_FACULTY" {return "Power BI Premium Per User Add-On for Faculty"}
        "PBI_PREMIUM_PER_USER_ADDON_GCC" {return "Power BI Premium Per User Add-On for GCC"}
        "PBI_PREMIUM_PER_USER_ADDON_CE_GCC" {return "Power BI Premium Per User Add-On for GCC"}
        "PBI_PREMIUM_PER_USER_FACULTY" {return "Power BI Premium Per User for Faculty"}
        "PBI_PREMIUM_PER_USER_DEPT" {return "Power BI Premium Per User Dept"}
        "PBI_PREMIUM_PER_USER_GCC" {return "Power BI Premium Per User for Government"}
        "POWER_BI_PRO" {return "Power BI Pro"}
        "POWER_BI_PRO_CE" {return "Power BI Pro CE"}
        "POWER_BI_PRO_DEPT" {return "Power BI Pro Dept"}
        "POWER_BI_PRO_FACULTY" {return "Power BI Pro for Faculty"}
        "POWERBI_PRO_GOV" {return "Power BI Pro for GCC"}
        "Power_Pages_vTrial_for_Makers" {return "Power Pages vTrial for Makers"}
        "PBI_PREMIUM_EM1_ADDON" {return "Power BI Premium EM1"}
        "PBI_PREMIUM_EM2_ADDON" {return "Power BI Premium EM2"}
        "VIRTUAL_AGENT_BASE" {return "Power Virtual Agent"}
        "VIRTUAL_AGENT_BASE_GCC" {return "Power Virtual Agent for GCC"}
        "PRIVACY_MANAGEMENT_RISK" {return "Privacy Management - risk"}
        "PRIVACY_MANAGEMENT_RISK_EDU" {return "Privacy Management - risk for EDU"}
        "PRIVACY_MANAGEMENT_RISK_GCC" {return "Privacy Management - risk GCC"}
        "PRIVACY_MANAGEMENT_RISK_USGOV_DOD" {return "Privacy Management - risk_USGOV_DOD"}
        "PRIVACY_MANAGEMENT_RISK_USGOV_GCCHIGH" {return "Privacy Management - risk_USGOV_GCCHIGH"}
        "PROJECTCLIENT" {return "Project for Office 365"}
        "PROJECTESSENTIALS" {return "Project Online Essentials"}
        "PROJECTESSENTIALS_FACULTY" {return "Project Online Essentials for Faculty"}
        "PROJECTESSENTIALS_GOV" {return "Project Online Essentials for GCC"}
        "PROJECTPREMIUM" {return "Project Online Premium"}
        "PROJECTONLINE_PLAN_1" {return "Project Online Premium without Project Client"}
        "PROJECTONLINE_PLAN_2" {return "Project Online with Project for Office 365"}
        "PROJECT_P1" {return "Planner Plan 1"}
        "PROJECT_PLAN1_DEPT" {return "Project Plan 1 (for Department)"}
        "PROJECTPROFESSIONAL" {return "Planner and Project Plan 3"}
        "PROJECT_PLAN3_DEPT" {return "Project Plan 3 (for Department)"}
        "PROJECTPROFESSIONAL_FACULTY" {return "Project Plan 3 for Faculty"}
        "PROJECTPROFESSIONAL_GOV" {return "Project Plan 3 for GCC"}
        "Project_Professional_TEST_GCC" {return "Project Plan 3 for GCC TEST"}
        "PROJECTPROFESSIONAL_USGOV_GCCHIGH" {return "Project Plan 3_USGOV_GCCHIGH"}
        "PROJECTPREMIUM_FACULTY" {return "Project Plan 5 for faculty"}
        "PROJECTPREMIUM_GOV" {return "Project Plan 5 for GCC"}
        "PROJECTONLINE_PLAN_1_FACULTY" {return "Project Plan 5 without Project Client for Faculty"}
        "RIGHTSMANAGEMENT_ADHOC" {return "Rights Management Adhoc"}
        "RMSBASIC" {return "Rights Management Service Basic Content Protection"}
        "DYN365_IOT_INTELLIGENCE_ADDL_MACHINES" {return "Sensor Data Intelligence Additional Machines Add-in for Dynamics 365 Supply Chain Management"}
        "DYN365_IOT_INTELLIGENCE_SCENARIO" {return "Sensor Data Intelligence Scenario Add-in for Dynamics 365 Supply Chain Management"}
        "SHAREPOINTSTANDARD" {return "SharePoint Online (Plan 1)"}
        "SHAREPOINTENTERPRISE" {return "SharePoint Online (Plan 2)"}
        "Intelligent_Content_Services" {return "SharePoint Syntex"}
        "MCOIMP" {return "Skype for Business Online (Plan 1)"}
        "MCOSTANDARD" {return "Skype for Business Online (Plan 2)"}
        "MCOPSTN2" {return "Skype for Business PSTN Domestic and International Calling"}
        "MCOPSTN1" {return "Skype for Business PSTN Domestic Calling"}
        "MCOPSTN5" {return "Skype for Business PSTN Domestic Calling (120 Minutes)"}
        "MCOPSTN5" {return "Skype for Business PSTN Calling Domestic Small"}
        "MCOPSTNPP" {return "Skype for Business PSTN Usage Calling Plan"}
        "Operator_Connect_Mobile" {return "Teams Phone Mobile"}
        "MCOTEAMS_ESSENTIALS" {return "Teams Phone with Calling Plan"}
        "Teams_Premium_for_Faculty" {return "Teams Premium for Faculty"}
        "Teams_Premium_(for_Departments)" {return "Teams Premium (for Departments)"}
        "MCOPSTNEAU2" {return "TELSTRA Calling for O365"}
        "UNIVERSAL_PRINT" {return "Universal Print"}
        "VISIO_PLAN1_DEPT" {return "Visio Plan 1"}
        "VISIO_PLAN2_DEPT" {return "Visio Plan 2"}
        "VISIOONLINE_PLAN1" {return "Visio Plan 1"}
        "VISIOCLIENT_FACULTY" {return "Visio Plan 2 for Faculty"}
        "VISIOCLIENT" {return "Visio Plan 2"}
        "VISIOCLIENT_GOV" {return "Visio Plan 2 for GCC"}
        "VISIOCLIENT_USGOV_GCCHIGH" {return "Visio Plan 2_USGOV_GCCHIGH"}
        "Viva_Goals_User_led" {return "Viva Goals User-led"}
        "TOPIC_EXPERIENCES" {return "Viva Topics"}
        "VIVA_LEARNING" {return "Viva Learning"}
        "WIN_ENT_E5" {return "Windows 10/11 Enterprise E5 (Original)"}
        "WIN10_ENT_A3_FAC" {return "Windows 10/11 Enterprise A3 for faculty"}
        "WIN10_ENT_A3_STU" {return "Windows 10/11 Enterprise A3 for students"}
        "WIN10_ENT_A5_FAC" {return "Windows 10/11 Enterprise A5 for faculty"}
        "WIN10_PRO_ENT_SUB" {return "WINDOWS 10/11 ENTERPRISE E3"}
        "WIN10_VDA_E3" {return "WINDOWS 10/11 ENTERPRISE E3"}
        "WIN10_VDA_E5" {return "Windows 10/11 Enterprise E5"}
        "WINE5_GCC_COMPAT" {return "Windows 10/11 Enterprise E5 Commercial (GCC Compatible)"}
        "E3_VDA_only" {return "Windows 10/11 Enterprise VDA"}
        "WINDOWS_STORE" {return "Windows Store for Business"}
        "WSFB_EDU_FACULTY" {return "Windows Store for Business EDU Faculty"}
        "Workload_Identities_Premium_CN" {return "Workload Identities Premium"}

    }

    return $Sku
}

function Get-Office365LicenseDetails() {
    
    try {
        InitialiseLogFile
        SetupOutputFormats
        LogEnvironmentDetails

        if (!(EnsureModuleLoaded -ModuleName "Microsoft.Graph.Users" -MinimumVersion "2.28.0")) {
            return
        }

        if (!(EnsureModuleLoaded -ModuleName "Microsoft.Graph.Identity.DirectoryManagement" -MinimumVersion "2.28.0")) {
            return
        }

        if (!(EnsureModuleLoaded -ModuleName "Microsoft.Graph.Users.Actions" -MinimumVersion "2.28.0")) {
            return
        }

        if (-not (ConnectToGraph)) {
            return;
        }

        if (-not (ExportOffice365Data)) {
            return;
        }

        LogProgress -Activity "Microsoft 365 Data Export" -Status "Export Complete" -percentComplete 100 -Completed $true
        Start-Sleep -s 3
    }
    catch {        
        LogLastException
    }
} 

Get-Office365LicenseDetails