#########################################################
#                                                                     
# Start-InventoryMenu.ps1
#
#########################################################

 <#
.SYNOPSIS
This PowerShell script is developed by Ernst & Young Global Limited (or one of its member firms).

.DESCRIPTION
This script is a part of specialized tool developed to enhance the facilitation of Microsoft software license compliance assessments. Referred to as "EY Script", this tool is intended to automate the process of collecting data regarding software installations on individual or multiple computer systems.

.COPYRIGHT
Copyright (C) 2024 Ernst & Young Global Limited. All rights reserved. The Irish firm Ernst & Young is a member practice of Ernst & Young Global Limited.

This script is proprietary to Ernst & Young Global Limited (or one of its member firms). Unauthorized copying of this file, via any medium, is strictly prohibited. Redistribution and use in source and binary forms, with or without modification, are not permitted without prior written permission from Ernst & Young Global Limited.

.LICENSE
This script is provided "AS IS" without warranty of any kind. Ernst & Young Global Limited expressly disclaims all warranties, whether express, implied, statutory, or otherwise, with respect to this script including all implied warranties of merchantability, fitness for a particular purpose, and non-infringement. In no event shall Ernst & Young Global Limited be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this script, even if advised of the possibility of such damage.

.NOTES
This script is for internal use in Ernst & Young operations and is not designed for public distribution. Use of this script by individuals or entities not authorized by Ernst & Young Global Limited may result in direct legal action.

.VERSION
5.0.6 – 30 April 2024 - Initial release.

#>

Param(
    [string] $LogFile = "InventoryMenuLog.txt",
    [string] $UserName = "",                        # User name for user with Administrator rights on devices to be scanned E.g. administrator or administrator@domain or administrator@domain.local
    [string] $Password = "",                        # User password
    [ValidateSet("BC","SPLA","SAM","SQL","General")]
    [string] $ScriptRegime = "General",             # Change to one of the options: BC, SPLA, SAM, SQL, General
    [ValidateSet("All","Servers","Clients")] 
    [string] $TargetType   = "All",                 # Change to one of the options: All, Servers, Clients
    [ValidateSet("AllOSAllApps", "AllOSMSApps", "MSOSMSApps")] 
    [string] $MicrosoftOnly = "AllOSAllApps",       # Only collect inventory and configuration information for Microsoft products
    [switch] $SaveInventoryFilesInSingleFolder,     # Save inventory files in a single folder. The default is to save in a folder for each computer
    [string] $OutputFolder = ".\Output",            # Do not change
    [string] $ScanSchedule = "[1-7]09:30,14:30;",   # Monday to Sunday at 09:30 and 14:30
    [int]    $ScanDays = 3,                         # Number of days to keep scanning until all devices have been scanned
    [int]    $MaxThreads = 10,                      # Maximum number of simultaneous scans
    [int]    $MaxCPUUsage = 50,                     # Maximum CPU usage permitted. Scans are puased if CPU usage exceeds this value
    [switch] $SkipPublisherCheck,
    [switch] $IgnoreCertificateErrors
)

$ScriptDescription =       "Inventory Menu"
$ScriptVersion =           "5.0.10"

#region Logging
$script:OutFileSupportsNoNewLine = $false;
function InitialiseLogFile {

    if (!($script:OutputFolder)) {
        $script:OutputFolder = ".\"
    }

    if (!(Test-Path $script:OutputFolder)) {
        New-Item -ItemType Directory -Path $script:OutputFolder | Out-Null
    }

    $script:OutputFolder = Resolve-Path $script:OutputFolder | Select-Object -ExpandProperty Path

    if (!($script:OutputFolder.EndsWith('\'))) {
        $script:OutputFolder += '\'
    }

    if ($script:OutputFolder -and !($LogFile -like "*\*")) {
        $script:LogFile = Join-Path $script:OutputFolder "$($OutputFilePrefix)$LogFile"
    }

    if ($LogFile -and (Test-Path $LogFile)) {
        Remove-Item $LogFile
    }

    if ((Get-Command "Out-File").parameters["NoNewline"]) {
        $script:OutFileSupportsNoNewLine = $true;
    }

    PrefixOutputFilesWithFolder
    DecryptPassword
}

function PrefixOutputFilesWithFolder {
    
    # Check if $OutputFolder exists and is not empty
    if ($script:OutputFolder) {
        $counter = 1
        while ($true) {
            $outputFileVarName = "OutputFile$counter"
            # Check if the OutputFile variable exists
            if (Get-Variable -Name $outputFileVarName -Scope Script -ErrorAction SilentlyContinue) {
                # Get the value of the OutputFile variable
                $outputFileValue = Get-Variable -Name $outputFileVarName -ValueOnly -Scope Script
                # Check if it does not contain a backslash, and if so, prefix with OutputFolder
                if (-not $outputFileValue.Contains("\"))
                {
                    Set-Variable -Name $outputFileVarName -Value (Join-Path $script:OutputFolder "$($OutputFilePrefix)$outputFileValue") -Scope Script
                }
                $counter++
            } else {
                # Exit loop if the variable does not exist
                break
            }
        }
    }
} 

function LogText {
    param(
        [Parameter(Position=0, ValueFromRemainingArguments=$true, ValueFromPipeline=$true)]
        [Object] $Object,
        [System.ConsoleColor]$Color = [System.Console]::ForegroundColor,
        [switch]$NoNewLine = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"
    )

    if ($LogTo -ne "File") {
        # Display text on screen
        Write-Host -Object $Object -ForegroundColor $Color -NoNewline:$NoNewLine
    }
    
    if ($LogTo -ne "Console") {
        if ($LogFile) {
            if ($script:OutFileSupportsNoNewLine) {
                $Object | Out-File $LogFile -Encoding utf8 -Append -NoNewline:$NoNewLine 
            }
            else {
                $Object | Out-File $LogFile -Encoding utf8 -Append 
            }
        }
    }
}

function LogTimeAndText {
    param(
        [string] $Text,
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Blue,
        [switch]$IncludeDate = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    $output = "";
    if ($IncludeDate) {
        $output = Get-Date -Format "yyyy-MM-dd HH:mm:ss.ff"
    } else {
        $output = Get-Date -Format "HH:mm:ss.ff"
    }

    $output += " - "
    $output += $Text
    LogText $output -Color $Color -LogTo $LogTo
}

function LogError([string[]]$errorDescription){
    if ($Verbose){
        LogText ""
    }

    $output = $errorDescription -join "`r`n              "
    LogTimeAndText $output -Color Red

    Start-Sleep -s 3
}

function LogLastException() {
    $currentException = $Error[0].Exception;

    while ($currentException)
    {
        LogText -Color Red $currentException
        LogText -Color Red $currentException.Data
        LogText -Color Red $currentException.HelpLink
        LogText -Color Red $currentException.HResult
        LogText -Color Red $currentException.Message
        LogText -Color Red $currentException.Source
        LogText -Color Red $currentException.StackTrace
        LogText -Color Red $currentException.TargetSite

        $currentException = $currentException.InnerException
    }

    Start-Sleep -s 3
}

$script:MostRecentActivity = ""
function LogProgress([string]$Activity, [string]$Status, [Int32]$PercentComplete, [switch]$Completed ){
    
    if ($Activity) {
        $script:MostRecentActivity = $Activity
    } else {
        if ($script:MostRecentActivity) {
            $Activity = $script:MostRecentActivity
        } else {
            $Activity = "Unspecified"
        }
    }
    Write-Progress -activity $Activity -Status $Status -percentComplete $PercentComplete -Completed:$Completed
    LogTimeAndText $Status
}

function GetScriptPath
{
    if($PSCommandPath){
        return $PSCommandPath; }
        
    if($MyInvocation.ScriptName){
        return $MyInvocation.ScriptName }
        
    if($script:MyInvocation.MyCommand.Path){
        return $script:MyInvocation.MyCommand.Path }

    return $script:MyInvocation.MyCommand.Definition
}

function GetDotNetFrameworkVersion {
    #$release = Get-ItemPropertyValue -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release
    $regKey = Get-Item -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    $release = $regKey.GetValue("Release")
    switch ($release) {
        { $_ -ge 533320 } { $version = "4.8.1 or later ($release)"; break }
        { $_ -ge 528040 } { $version = "4.8 ($release)"; break }
        { $_ -ge 461808 } { $version = "4.7.2 ($release)"; break }
        { $_ -ge 461308 } { $version = "4.7.1 ($release)"; break }
        { $_ -ge 460798 } { $version = "4.7 ($release)"; break }
        { $_ -ge 394802 } { $version = "4.6.2 ($release)"; break }
        { $_ -ge 394254 } { $version = "4.6.1 ($release)"; break }
        { $_ -ge 393295 } { $version = "4.6 ($release)"; break }
        { $_ -ge 379893 } { $version = "4.5.2 ($release)"; break }
        { $_ -ge 378675 } { $version = "4.5.1 ($release)"; break }
        { $_ -ge 378389 } { $version = "4.5 ($release)"; break }
        default { $version = $null; break }
    }

    return $version
}

function LogEnvironmentDetails ([string[]] $OtherDetails){

    $script:ScriptPath = GetScriptPath
    $script:ScriptName = split-path $ScriptPath -leaf

    LogText " "
    LogHeaderText -FrameLine 
    LogHeaderText -LeftText " _______     __" -LeftColor Yellow
    LogHeaderText -LeftText "|  ___\ \   / /" -LeftColor Yellow
    LogHeaderText -LeftText "| |__  \ \_/ / " -LeftColor Yellow
    LogHeaderText -LeftText "|  __|  \   /  " -LeftColor Yellow
    LogHeaderText -LeftText "| |____  | |   " -LeftColor Yellow -RightText "$ScriptDescription  "
    LogHeaderText -LeftText "|______| |_|   " -LeftColor Yellow -RightText "Version $ScriptVersion  "
    LogHeaderText
    LogHeaderText -FrameLine 

    LogText " "
    LogText " $ScriptName" -Color Green 
    LogText " "

    if ($PSVersionTable.PSVersion.Major -ge 3) {
        $oSDetails = Get-CimInstance -ClassName Win32_OperatingSystem
    } else {
        $oSDetails = Get-WmiObject -Class Win32_OperatingSystem
    }
    $elevated = [bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")
    $currentThread = [System.Threading.Thread]::CurrentThread
    $dotNetFrameworkVersion = GetDotNetFrameworkVersion
    LogText -Color Gray "Computer Name:          $($env:COMPUTERNAME)"
    LogText -Color Gray "User Name:              $($env:USERNAME)@$($env:USERDNSDOMAIN)"
    LogText -Color Gray "Windows Version:        $($oSDetails.Caption)($($oSDetails.Version))"
    LogText -Color Gray "Memory kB:              $($oSDetails.TotalVisibleMemorySize.ToString("N0")) ($($oSDetails.FreePhysicalMemory.ToString("N0")) Free)"
    LogText -Color Gray "Locale:                 $($oSDetails.Locale) (Language $($oSDetails.OSLanguage))"
    LogText -Color Gray "PowerShell Host:        $($host.Version.Major)"
    LogText -Color Gray "PowerShell Version:     $($PSVersionTable.PSVersion)"
    LogText -Color Gray "PowerShell Word Size:   $($([IntPtr]::size) * 8) bit"
    LogText -Color Gray "Script Path:            $ScriptPath"
    LogText -Color Gray "Working Directory:      $PWD"
    LogText -Color Gray "CLR Version:            $($PSVersionTable.CLRVersion)"
    LogText -Color Gray ".Net Framework Version: $dotNetFrameworkVersion"
    LogText -Color Gray "Elevated:               $elevated"
    LogText -Color Gray "Current Date Time:      $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
    LogText -Color Gray "Default Date Format:    $($CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern)"
    LogText -Color Gray "Current Culture:        $((Get-Culture).EnglishName) (UI: $((Get-UICulture).EnglishName))"
    
    if (Test-Path "Variable:OutputFolder") {
        LogText -Color Gray "Output Folder:          $OutputFolder" 
    }
    if (Test-Path "Variable:OutputFile1") {
        LogText -Color Gray "Output File 1:          $OutputFile1" 
    }
    if (Test-Path "Variable:LogFile") {
        LogText -Color Gray "Log File:               $LogFile" 
    }
    if (Test-Path "Variable:ComputerName") {
        LogText -Color Gray "Target Computer Name:   $ComputerName" 
    }
    if (Test-Path "Variable:UserName") {
        LogText -Color Gray "Script User Name:       $UserName"
    }
    if (Test-Path "Variable:MicrosoftOnly") {
        LogText -Color Gray "Microsoft Only:         $MicrosoftOnly"
    }
    if (Test-Path "Variable:TargetType") {
        LogText -Color Gray "Target Type:            $TargetType"
    }
    if (Test-Path "Variable:ScriptRegime") {
        LogText -Color Gray "Script Regime:          $ScriptRegime"
    }
    if (Test-Path "Variable:RequiredData") {
        LogText -Color Gray "Required Data:          $RequiredData"
    }

    foreach ($detail in $OtherDetails){
        LogText -Color Gray $detail
    }

    LogText -Color Gray ""

}

function LogHeaderText {
    param(
        [string] $LeftText = " ",
        [System.ConsoleColor]$LeftColor = [System.ConsoleColor]::Blue,
        [string] $RightText,
        [System.ConsoleColor]$RightColor = [System.ConsoleColor]::DarkGray,
        [char] $FrameChar = "#",
        [switch] $FrameLine,
        [switch] $LeftAlignRightText,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    if ($FrameLine) {
        $strFullText = "  " + ($FrameChar.ToString() * 69)
        LogText $strFullText -Color DarkGray -LogTo $LogTo
        return
    }

    $strLeftFrame = "  $FrameChar  "
    $strLeftText = $LeftText
    $strRightText = $RightText
    $strRightFrame = "  $FrameChar"
    if ($LeftAlignRightText) {
        $strRightText = $RightText.PadRight(63 - $LeftText.Length)
    } else {
        $strLeftText = $LeftText.PadRight(63 - $RightText.Length)
    }
    

    if ($LogTo -eq "Console" -or $LogTo -eq "Both") {
        LogText $strLeftFrame -LogTo "Console" -NoNewLine -Color DarkGray
        LogText $strLeftText -LogTo "Console" -NoNewLine -Color $LeftColor
        LogText $strRightText -LogTo "Console" -NoNewLine -Color $RightColor
        LogText $strRightFrame -LogTo "Console" -Color DarkGray
    }

    if ($LogTo -eq "File" -or $LogTo -eq "Both") {
        $strFullText = $strLeftFrame + $strLeftText + $strRightText + $strRightFrame
        LogText $strFullText -LogTo "File" 
    }
}

function DecryptPassword {
    $strOneTimePassword = "%OneTimePassword%" # Replace this with the one-time password
    if ($SecurePassword) {
        $baOneTimePassword = [System.Convert]::FromBase64String($strOneTimePassword)
        $baSecurePassword = [System.Convert]::FromBase64String($SecurePassword)
        for($i=0; $i -lt $baSecurePassword.count ; $i++)
        {
            $baSecurePassword[$i] = $baSecurePassword[$i] -bxor $baOneTimePassword[$i%$baOneTimePassword.Length]
        }
        $script:Password = [System.Text.Encoding]::Unicode.GetString($baSecurePassword);
    }
}
#endregion

#region Setup Output Formats
function SetupOutputFormats {
    # Standardise date/time output to ISO 8601'ish format
    $bOutputFormatsUpdated = $false
    $currentThread = [System.Threading.Thread]::CurrentThread
    $desiredShortPattern = 'yyyy-MM-dd'
    $desiredLongPattern = 'yyyy-MM-dd HH:mm:ss'

    try {
        $cultureInvariant = [CultureInfo]::InvariantCulture.Clone()
        $cultureInvariant.DateTimeFormat.ShortDatePattern = $desiredShortPattern
        $cultureInvariant.DateTimeFormat.LongDatePattern = $desiredLongPattern
        $cultureInvariant.NumberFormat.NumberGroupSeparator = ""  
        $cultureInvariant.NumberFormat.NumberDecimalSeparator = "."
        $currentThread.CurrentCulture = $cultureInvariant
        $bOutputFormatsUpdated = $true
    }
    catch {
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $currentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $currentThread.CurrentCulture.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $currentThread.CurrentCulture.NumberFormat.NumberGroupSeparator = ""  
            $currentThread.CurrentCulture.NumberDecimalSeparator = "."
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $cultureCopy = $currentThread.CurrentCulture.Clone()
            $cultureCopy.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $cultureCopy.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $cultureCopy.NumberFormat.NumberGroupSeparator = ""  
            $cultureCopy.NumberDecimalSeparator = "."
            $currentThread.CurrentCulture = $cultureCopy
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread using clone of current culture"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        LogText "Failed to update output formats"
    }
}
#endregion

#region Query User
function QueryUser([string]$Message, [string]$Prompt, [switch]$AsSecureString = $false, [string]$DefaultValue){
    $strResult = ""
    
    if ($Message) {
        LogText $Message -color Yellow
    }

    if ($DefaultValue) {
        $Prompt += " (Default [$DefaultValue])"
    }

    $Prompt += ": "
    LogText $Prompt -color Yellow -NoNewLine
    
    if ($Headless) {
        LogText " (Headless - Using Default Value)" -color Yellow
    }
    else {
        $strResult = Read-Host -AsSecureString:$AsSecureString
    }

    if(!$strResult -or ($strResult.Length -eq 0)) {
        $strResult = $DefaultValue
        if ($AsSecureString) {
            $strResult = ConvertTo-SecureString $strResult -AsPlainText -Force
        }
    }

    return $strResult
}

function Get-ConsoleCredential([String] $Message, [String] $DefaultUsername, [switch] $AsPSCredential)
{
    $strUsername = QueryUser -Message $Message -Prompt "Username" -DefaultValue $DefaultUsername
    if (!$strUsername){
        return $null
    }

    $strSecurePassword = QueryUser -Prompt "Password" -AsSecureString
    if (!$strSecurePassword){
        return $null
    }

    if ($AsPSCredential) {
        $Creds = New-Object System.Management.Automation.PSCredential ($strUsername, $strSecurePassword)
    } else {
        $Creds = New-Object PSObject

        $bstrSecurePassword = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($strSecurePassword)
        $strUnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstrSecurePassword)

        $Creds | Add-Member -MemberType NoteProperty -Name "UserName" -Value $strUsername
        $Creds | Add-Member -MemberType NoteProperty -Name "Password" -Value $strUnsecurePassword
    }

    return $Creds
}
#endregion

#region Custom Export
$ScriptExcludeFields = $null
function Export-MyCsv {
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [PSCustomObject[]] $InputObject,
        [Parameter(Mandatory = $true)]
        [string] $Path,
        [switch] $Append,
        [switch] $IncludeIndex
    )

    begin {
        if ($null -eq $ScriptExcludeFields) {
            LoadExcludeFields
        }

        $fileExcludeFields = $null
        $fileID = GetFileNameFinalPart -FilePath $Path
        if ($ScriptExcludeFields.ContainsKey($fileID)) {
            $fileExcludeFields = $ScriptExcludeFields[$fileID].Split(',') | ForEach-Object { $_.Trim() }
        }

        $index = 1
        $outputData = New-Object 'System.Collections.Generic.List[object]'
    }

    process {
        foreach ($item in $InputObject) {
            
            # Create a duplicate of the item with only the required fields
            $processedItem = New-Object PSObject 
            foreach ($prop in $item.PSObject.Properties) {
                if ($null -eq $fileExcludeFields -or !$fileExcludeFields.Contains($prop.Name)) {
                    $processedItem | Add-Member -MemberType NoteProperty -Name $prop.Name -Value $prop.Value -Force
                }
            }

            # Add index if requested
            if ($IncludeIndex) {
                $processedItem | Add-Member -MemberType NoteProperty -Name 'Index' -Value $index -Force
                $index++
            }

            # Add the processed item to the list
            $outputData.Add($processedItem)
        }
    }

    end {
        # Convert the list to an array and export to CSV
        $outputData.ToArray() | Export-Csv -Path $Path -Encoding UTF8 -NoTypeInformation -Append:$Append -Delimiter ","

        # This function logs the field names and sample values of exported data to the log file and a CSV file
        # Uncomment the following line to enable this functionality
        #LogFieldInfo -InputObject $outputData -OutputFileName $fileID
        $outputData = $null
    }
}

function LoadExcludeFields {
    $script:ScriptExcludeFields = @{}

    if (!($ScriptDescription)) {
        return
    }

    # Import the CSV
    try {
        $csvData = Import-Csv -Path ".\ExcludeFields.csv" -ErrorAction SilentlyContinue
    } catch {
    }

    foreach ($row in $csvData | Where-Object { $_.Script -eq $ScriptDescription }) {
        $ScriptExcludeFields[$row.OutputFile] = $row.ExcludeFields
    }
}

function GetFileNameFinalPart {
    param (
        [string]$FilePath
    )

    # Return the last part of the filename i.e. Apps for the following values
    # c:\temp\20240102_101212_Apps.csv
    # c:\temp\Apps.csv

    # Get the filename without the extension
    $fileNameWithoutExtension = [System.IO.Path]::GetFileNameWithoutExtension($FilePath)

    # Split the filename by underscore or backslash, and take the last part
    $lastPart = ($fileNameWithoutExtension -split '[\\_]')[-1]

    return $lastPart
}

# Support function. Not currently called. The function is used for custom testing to aid the local development team where necessary
function LogFieldInfo {
    param(
        [PSCustomObject[]] $InputObject,
        [string] $OutputFileName
    )
    
    # This function logs the field names and sample values of exported data to the log file and a CSV file
    # It is not enabled by default
    if (!($InputObject) -or $InputObject.Count -eq 0) {
        return
    }

    # Creating a new array of fields and sample values
    $lstFields = @()

    $recordIndex = 1
    foreach ($record in $InputObject) {
        $fieldNames = $record.PSObject.Properties.Name
        $fieldIndex = 1

        # Iterate through each property
        foreach ($fieldName in $fieldNames) {
            # Creating a new object for each property
            $field = [PSCustomObject][ordered]@{
                ScriptFileName = $ScriptName
                ScriptDescription = $ScriptDescription
                OutputFileName = $OutputFileName
                FieldName = $fieldName
                SampleValue = $record.$fieldName
                FieldIndex = $fieldIndex++
                RecordIndex = $recordIndex
            }

            # Add new object to the array
            $lstFields += $field
        }
    
        $recordIndex++
        if ($recordIndex -gt 3) {
            break
        }
    }

    # Save the field info to log file and csv file
    $csvLines = $lstFields | ConvertTo-Csv -NoTypeInformation
    $csvString = $csvLines -join "`n"
    LogText $csvString -LogTo File
    $lstFields | export-csv -Path ".\FieldInfo.csv" -NoTypeInformation -Append -Delimiter ","
}
#endregion

function Start-InventoryMenu {

    LogTimeAndText "EY Script is starting"

    InitialiseLogFile
    SetupOutputFormats

    [System.Console]::TreatControlCAsInput = $true
    $script:MenuMode = ""

    LogTimeAndText "Inventory Menu Started" -IncludeDate -LogTo File

    while (RunMenu) {}

    LogTimeAndText "Inventory Menu Closed" -IncludeDate -LogTo File

}

function ClearHost {
    Clear-Host
}

function ShowLogo {

    if ($script:UserName -eq "") {
        $strRight1 = ""
        $strRight2 = "Windows Inventory Menu  "
        $strRight3 = "Version $ScriptVersion  "
    } else {      
        $strRight1 = "Windows Inventory Menu  "
        $strRight2 = "Version $ScriptVersion  "
        $strRight3 = "$($script:UserName)  "
    }

    LogHeaderText -LogTo Console -FrameLine 
    LogHeaderText -LogTo Console -LeftText " _______     __" -LeftColor Yellow
    LogHeaderText -LogTo Console -LeftText "|  ___\ \   / /" -LeftColor Yellow
    LogHeaderText -LogTo Console -LeftText "| |__  \ \_/ / " -LeftColor Yellow
    LogHeaderText -LogTo Console -LeftText "|  __|  \   /  " -LeftColor Yellow -RightText $strRight1
    LogHeaderText -LogTo Console -LeftText "| |____  | |   " -LeftColor Yellow -RightText $strRight2
    LogHeaderText -LogTo Console -LeftText "|______| |_|   " -LeftColor Yellow -RightText $strRight3
    LogHeaderText -LogTo Console
    LogHeaderText -LogTo Console -FrameLine 
}

function ShowMenu {
    
    # Clear the screen
    ClearHost

    # Display the menu
    ShowLogo
    LogHeaderText -LogTo Console -FrameChar "*"
    
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor Gray -LeftText "(1) Scan device(s) for hardware & software inventory"
    if ($script:MenuMode -eq "InventoryScan") {
        LogHeaderText -LogTo Console -FrameChar "*" -LeftColor Gray -LeftText "  (a) Scan local computer"
    }
    
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor Gray -LeftText "(x) Exit"

    LogHeaderText -LogTo Console -FrameChar "*" 
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "Choose option or 'x' to exit"
    LogHeaderText -LogTo Console -FrameChar "*"
    LogHeaderText -LogTo Console -FrameChar "*" -FrameLine
}

function ShowRadioButtonOptions {
    param (
        [Parameter(Mandatory=$true)]
        [string[]]$HeaderText,
        [string[]]$OptionList,
        [int]$SelectedOption = -1
    )
    
    # Clear the screen
    ClearHost

    # Display the menu
    ShowLogo
    LogHeaderText -LogTo Console -FrameChar "*"

    foreach ($header in $HeaderText) {
        LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText $header
    }

    if ($HeaderText) {
        LogHeaderText -LogTo Console -FrameChar "*"
    }

    $index = 1
    foreach ($option in $OptionList) {
        
        $strRightText = "$($option)"
        $strLeftText = "$index [ ] ";
        if ($index -eq $SelectedOption) {
            $strLeftText = "$index [" + [char]0x25CF + "] ";
        }

        LogHeaderText -LeftText $strLeftText -LeftColor Blue -RightText $strRightText -RightColor White -LogTo Console -FrameChar "*" -LeftAlignRightText

        $index++
    }
    
    LogHeaderText -LogTo Console -FrameChar "*" 
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "Choose option or 'x' to return to main menu"
    LogHeaderText -LogTo Console -FrameChar "*"
    LogHeaderText -LogTo Console -FrameChar "*" -FrameLine

    $keyPress = [System.Console]::ReadKey($true)
    
    return $keyPress.KeyChar.ToString().ToLower()
}

function SetScanTargetType {
    $selectedOption = -1
    switch ($TargetType) {
        "All" {
            $selectedOption = 1
        }
        "Servers" {
            $selectedOption = 2
        }
        "Clients" {
            $selectedOption = 3
        }
    }

    $newSelectedOption = ShowRadioButtonOptions -HeaderText @(
        "When scanning devices in Active Directory and DeviceList.txt,",
        "the following devices should be included") -OptionList @(
        "Windows Servers And Clients", 
        "Windows Servers Only",
        "Windows Clients Only") -SelectedOption $selectedOption 

    switch ($newSelectedOption) {
        "1" {
            $script:TargetType = "All"
        }
        "2" {
            $script:TargetType = "Servers"
        }
        "3" {
            $script:TargetType = "Clients"
        }
        "x" {
            return $false
        }
    }
}

function SetScanSchedule {
    $selectedOption = 9
    switch ($ScanSchedule) {
        "" {$selectedOption = 1}
        "[1-7]09:30;" {$selectedOption = 2}
        "[1-7]09:30,14:30;" {$selectedOption = 3}
        "[1-7]22:30;" {$selectedOption = 4}
        "[1-5]09:30;" {$selectedOption = 5}
        "[1-5]09:30,14:30;" {$selectedOption = 6}
        "[6,7]14:30;" {$selectedOption = 7}
        "[6,7]22:30;" {$selectedOption = 8}
    }

    $newSelectedOption = ShowRadioButtonOptions -HeaderText @(
        "When scanning devices in Active Directory and DeviceList.txt,",
        "failed scans should be reattempted") -SelectedOption $selectedOption -OptionList @(
        "Never",
        "Every Day at 9:30",
        "Every Day at 9:30 & 14:30",
        "Every Day at 22:30",
        "Monday-Friday at 9:30",
        "Monday-Friday at 9:30 & 14:30",
        "Saturday & Sunday at 14:30",
        "Saturday & Sunday at 22:30",
        "Custom")

    $bSetCustom = $false;
    switch ($newSelectedOption) {
        "1" { $script:ScanSchedule = ""}
        "2" { $script:ScanSchedule = "[1-7]09:30;"}
        "3" { $script:ScanSchedule = "[1-7]09:30,14:30;"}
        "4" { $script:ScanSchedule = "[1-7]22:30;"}
        "5" { $script:ScanSchedule = "[1-5]09:30;"}
        "6" { $script:ScanSchedule = "[1-5]09:30,14:30;"}
        "7" { $script:ScanSchedule = "[6,7]14:30;"}
        "8" { $script:ScanSchedule = "[6,7]22:30;"}
        "9" { $bSetCustom = $true }
        "x" { }
        default {
            LogText "That is not a valid option"
            Start-Sleep -s 2
            return $false
        }
    }

    if ($bSetCustom) {
        LogText "Custom Schedule" -Color Yellow
        LogText "Format [Days]Times;[Days]Times"
        LogText "Samples" -Color DarkGray
        LogText "  [1]09:30;           Mondays at 09:30" -Color DarkGray
        LogText "  [1,3]09:30;         Mondays and Wednesdays at 09:30" -Color DarkGray
        LogText "  [1-3]09:30;         Mondays, Tuesdays and Wednesdays at 09:30" -Color DarkGray
        LogText "  [1-7]09:30,14:30;   Every Day at 09:30 and 14:30" -Color DarkGray
        LogText "  [1,4]09:30;[2,5]13:30;[3]16:30;" -Color DarkGray
        LogText "                      Mondays, Thursdays at 09:30, Tuesdays, Fridays at 13:30, Wednesdays at 16:30" -Color DarkGray
        $strCustomSchedule = QueryUser -Prompt "Custom schedule" -DefaultValue $script:ScanSchedule
        if ($strCustomSchedule) {
            $script:ScanSchedule = $strCustomSchedule
        }
    }

    LogText "Scan Period" -Color Yellow
    LogText "Enter the number of days the scan should run for"
    $strDays = QueryUser -Prompt "Days" -DefaultValue $script:ScanDays
    [int]$nDays = 0
    if ([int]::TryParse($strDays, [ref]$nDays) -and $nDays -ge 0) {
        $script:ScanDays = $nDays
    } else {
        LogText "Invalid number of days"
        Start-Sleep -s 2
        return $false
    }

    return $true
}

function RunMenu {
    
    # Display the menu
    ShowMenu
    
    # Wait for the user to choose an option
    $keyPress = [System.Console]::ReadKey($true)
    $selectedOption = $keyPress.KeyChar.ToString().ToLower()

    switch ($selectedOption) {
        "1" {
            $script:MenuMode = "InventoryScan"
            return $true;
        }
        "x" {
			return $false;
		}
        default {
            $arguments = @("-ExecutionPolicy Bypass", "-ScriptRegime $ScriptRegime", "-TargetType $TargetType")
            if ($SkipPublisherCheck) { $arguments += "-SkipPublisherCheck" }

            switch ($script:MenuMode) {
                "InventoryScan" {
                    $selectedOption = "1$selectedOption"
                }
            }

            $outputFilePrefix = Get-Date -Format "yyyyMMdd_HHmmss_"

            switch ($selectedOption) {
                "1a" {

                    ClearHost

                    LogTimeAndText "Local scan started"
                    $arguments = @("-File .\Scripts\Get-ComputerInventory.ps1") + $arguments
                    if ($SaveInventoryFilesInSingleFolder) {
                        $arguments += "-OutputFolder ""$($OutputFolder)Inventory\\"""
                        $arguments += "-OutputFilePrefix $($env:COMPUTERNAME)_"
                    } else {
                        $arguments += "-OutputFolder ""$($OutputFolder)Inventory\$($env:COMPUTERNAME)"""
                    }
                    $arguments += "-SummaryLogFile ""$($OutputFolder)Inventory\ScanLog.csv"""
                    if ($UserName -and $Password) {
                        $arguments += "-Username $UserName"
                        $arguments += "-Password $Password"
                    }
                    if ($MicrosoftOnly -like "*MSApps*") {
                        $arguments += "-MicrosoftOnly"
                    }
                    if ($IgnoreCertificateErrors) {$arguments += "-IgnoreCertificateErrors"}
                    Start-Process powershell -ArgumentList $arguments -Wait -NoNewWindow
                    LogTimeAndText "Local scan ended"

                    return PressAnyKey;
                }
                
                "2a" {

                    ClearHost

                    LogTimeAndText "Active Directory export started"
                    $arguments = @("-File .\Scripts\Get-ADDetails.ps1") + $arguments
                    $arguments += "-OutputFolder ""$($OutputFolder)ActiveDirectory\\"""
                    $arguments += "-OutputFilePrefix $outputFilePrefix"
                    $arguments += "-ShortenPhoneNumbers"

                    $requiredData = ""
                    switch ($ScriptRegime) {
                        "General" { $requiredData = "Domains,DomainTrusts,DomainNETBIOSNames,DomainControllers,Users,Devices,Groups,ExchangeServers,ActiveSyncDevices,DomainPolicies" }
                        "SAM"     { $requiredData = "Domains,DomainTrusts,DomainControllers,Users,Devices,Groups,ExchangeServers,ActiveSyncDevices,DomainPolicies"}
                        "BC"      { $requiredData = "Domains,DomainTrusts,DomainControllers,Users,Devices,Groups,ExchangeServers,ActiveSyncDevices"}
                        "SPLA"    { $requiredData = "Domains,Users,Devices,Groups,ExchangeServers,ActiveSyncDevices"}
                        "SQL"     { $requiredData = "Domains,Users,Devices,Groups,ExchangeServers,ActiveSyncDevices"}
                    }
                    if ($requiredData) {
                        $arguments += "-RequiredData ""$requiredData"""
                    }
                    if ($MicrosoftOnly -like "*MSOS*") {
                        $arguments += "-MicrosoftOnly"
                    }

                    Start-Process powershell -ArgumentList $arguments -Wait -NoNewWindow
                    LogTimeAndText "Active Directory export ended"

                    return PressAnyKey;
                }
                "2b" {

                    ClearHost
                    
                    LogTimeAndText "System Center Configuration Manager export started"
                    $arguments = @("-File .\Scripts\Get-SCCMInventoryData.ps1") + $arguments
                    $arguments += "-OutputFolder ""$($OutputFolder)SCCM\\"""
                    $arguments += "-OutputFilePrefix $outputFilePrefix"
                    if ($MicrosoftOnly -like "*MSApps*") {
                        $arguments += "-MicrosoftOnly"
                    }
                    Start-Process powershell -ArgumentList $arguments -Wait -NoNewWindow
                    LogTimeAndText "System Center Configuration Manager export ended"

                    return PressAnyKey;
                }
                "2c" {

                    ClearHost

                    LogTimeAndText "Exchange export started"
                    LogText "This script should be run once per Exchange Server Site"
                    $arguments = @("-File .\Scripts\Get-ExchangeDetails.ps1") + $arguments
                    $arguments += "-OutputFolder ""$($OutputFolder)Exchange\\"""
                    $arguments += "-OutputFilePrefix $outputFilePrefix"
                    if ($TargetType -eq "Servers") {
                        $arguments += "-RequiredData ServerData"
                    }
                    Start-Process powershell -ArgumentList $arguments -Wait -NoNewWindow
                    LogTimeAndText "Exchange export ended"

                    return PressAnyKey;
                }
                "2d" {

                    ClearHost

                    LogTimeAndText "Skype for Business export started"
                    $arguments = @("-File .\Scripts\Get-LyncUsers.ps1") + $arguments
                    $arguments += "-OutputFolder ""$($OutputFolder)Skype\\"""
                    $arguments += "-OutputFilePrefix $outputFilePrefix"
                    Start-Process powershell -ArgumentList $arguments -Wait -NoNewWindow
                    LogTimeAndText "Skype for Business export ended"

                    return PressAnyKey;
                }
                "2e" {

                    ClearHost

                    LogTimeAndText "Hyper-V export started"
                    LogText "This script should be run for each Hyper-V server"
                    $targetComputer = QueryUser -Prompt "Computer Name" -DefaultValue $($env:COMPUTERNAME)
                    $arguments = @("-File .\Scripts\Get-HyperVDetails.ps1") + $arguments
                    $arguments += "-ComputerName $targetComputer"
                    $arguments += "-OutputFolder ""$($OutputFolder)Hyper-V\\"""
                    $arguments += "-OutputFilePrefix $outputFilePrefix"
                    if ($UserName -and $Password) {
                        $arguments += "-Username $UserName"
                        $arguments += "-Password $Password"
                    }
                    if ($MicrosoftOnly -like "*MSOS*") {
                        $arguments += "-MicrosoftOnly"
                    }
                    Start-Process powershell -ArgumentList $arguments -Wait -NoNewWindow
                    LogTimeAndText "Hyper-V export ended"

                    return PressAnyKey;
                }
                "2f" {

                    ClearHost

                    LogTimeAndText "VMware export started"
                    $arguments = @("-File .\Scripts\Get-VMwareVMList.ps1") + $arguments
                    $arguments += "-OutputFolder ""$($OutputFolder)VMware\\"""
                    $arguments += "-OutputFilePrefix $outputFilePrefix"
                    if ($MicrosoftOnly -like "*MSOS*") {
                        $arguments += "-MicrosoftOnly"
                    }
                    Start-Process powershell -ArgumentList $arguments -Wait -NoNewWindow
                    LogTimeAndText "VMware export ended"

                    return PressAnyKey;
                }
                "3a" {

                    ClearHost

                    LogTimeAndText "Microsoft 365 export started"
                    $arguments = @("-File .\Scripts\Get-Microsoft365LicenseDetails.ps1") + $arguments
                    $arguments += "-OutputFolder ""$($OutputFolder)Microsoft365\\"""
                    $arguments += "-OutputFilePrefix $outputFilePrefix"
                    $arguments += "-ShortenPhoneNumbers"
                    Start-Process powershell -ArgumentList $arguments -Wait -NoNewWindow
                    LogTimeAndText "Microsoft 365 export ended"

                    return PressAnyKey;
                }
                "3b" {

                    ClearHost

                    LogTimeAndText "Azure VM and SQL Server inventory export started"
                    $arguments = @("-File .\Scripts\Get-AzureResources.ps1") + $arguments
                    $arguments += "-OutputFolder ""$($OutputFolder)Azure\\"""
                    $arguments += "-OutputFilePrefix $outputFilePrefix"
                    if ($MicrosoftOnly -like "*MSOS*") {
                        $arguments += "-MicrosoftOnly"
                    }
                    Start-Process powershell -ArgumentList $arguments -Wait -NoNewWindow
                    LogTimeAndText "Azure VM and SQL Server inventory export ended"

                    return PressAnyKey;
                }
                "4a" {

                    LogTimeAndText "Set Scan Target started" -LogTo File
                    SetScanTargetType
                    LogTimeAndText "Set Scan Target ended" -LogTo File

                    return $true;
                }
                "4b" {

                    ClearHost

			        LogTimeAndText "Set scan credentials"
                    $message = "Specify a username and password to be used when scanning remote devices`r`n"
                    $message += "Sample usernames: Administrator, administrator@contoso.local"
                    $creds = Get-ConsoleCredential -Message $message
                    if ($creds) {
                        $script:UserName = $creds.UserName
                        $script:Password = $creds.Password
                    } else {
                        $script:UserName = ""
                        $script:Password = ""
                    }
                    return $true;
		        }
                "4c" {

                    LogTimeAndText "Set Scan Schedule started" -LogTo File
                    while(!(SetScanSchedule)){}
                    LogTimeAndText "Set Scan Schedule ended" -LogTo File

                    return $true;
                }
                "4d" {

                    ShowAboutScreen
                    return PressAnyKey;

                }
                "4e" {

                    LogTimeAndText "Install Required Modules started" -LogTo File
                    ShowModuleInstallerMenu
                    LogTimeAndText "Install Required Modules ended" -LogTo File

                    return $true;
                }
                default {
                    if ($keyPress.Key -eq "c" -and $keyPress.Modifiers -eq "Control") {
                        return $false;
                    } elseif (IsPrintableChar($selectedOption)) {
				        LogText "'$selectedOption' is not a valid menu option."
			        } else {
                        LogText "That is not a valid menu option."
                    }
                }
            }
        }
    }

    # Wait for 2 seconds before returning to the menu
    Start-Sleep 2

    return $true;
}

function IsPrintableChar($char) {
    if ($char.Length -ne 1) { return $false }
    $asciiValue = [int][char]$char
    return $asciiValue -ge 32 -and $asciiValue -le 126
}

function PressAnyKey {
    LogText -LogTo Console
    LogText -LogTo Console -Color White "Press any key to continue"
    
    $keyPress = [System.Console]::ReadKey($true)
    
    return $true;
}

function WaitForNextScan {
    param (
        [DateTime]$NextScanTime
    )

    #ClearHost
    LogText -LogTo Console
    LogText -Color White "The current scan has completed. One or more devices were not scanned successfully."
    LogText -Color White "Outstanding devices will be rescanned at $($NextScanTime.ToLongDateString())"
    LogText -Color White "Press 'x' to cancel the next scan and return to the main menu"

    while ((Get-Date) -lt $NextScanTime) {
        if ([System.Console]::KeyAvailable) {
            $keyPress = [System.Console]::ReadKey($true)
            if ($keyPress.KeyChar.ToString().ToLower() -eq "x") {
                return $false
            }
        }
        Start-Sleep -Milliseconds 100  # Sleep for a short duration before checking again
    }

    return $true
}

function ScanDevicesInDeviceList ([string] $FileName) {

    if (!($FileName)) {
        # Check if CSV Device List file exists
        if (Test-Path ".\DeviceListWithCredentials.csv") {
            $FileName = ".\DeviceListWithCredentials.csv"
        } else {
            # Check if TXT Device List file exists
            if (Test-Path ".\DeviceList.txt") {
                $FileName = ".\DeviceList.txt"
            } else {
                LogText -LogTo Console
                LogText "Device List not found." -color Red
                LogText "Create a file with the names of all devices to be scanned and save it as" -color Yellow
                LogText " 1) DeviceList.txt (One device name per line) OR" -color Yellow
                LogText " 2) DeviceListWithCredentials.csv (CSV format)" -color Yellow
                LogText "Save the file in the current folder: $((Get-Location).Path) " -color Yellow
                return PressAnyKey;
            }
        }

        LogText "Loading Device List: $FileName"
    }

    $currentDateTime = Get-Date
    $endDateTime = $currentDateTime.AddDays($ScanDays)

    while ($true) {

        LogTimeAndText "Device list scan started" -LogTo File

        $bScansSucceeded = ScanDevicesInDeviceListInner $FileName
        if ($bScansSucceeded -eq $true) {
            # All scans succeeded
            LogText -LogTo Console
            LogText "The current scan has completed. All devices were scanned successfully." -color White
            return PressAnyKey;
        }

        $nextScanTime = Get-NextScanStartTime
        if (!($nextScanTime)) {
            LogText -LogTo Console
            LogText "The current scan has completed. One or more devices were not scanned successfully." -color Yellow
            LogText "Suggestion: Set a 'Scan Schedule' to enabled rescanning of outstanding devices." -color Yellow
            return PressAnyKey;
        }

        if ($nextScanTime -gt $endDateTime) {
            # The next scan time is outside the scan window
            LogText -LogTo Console
            LogText "The current scan has completed. One or more devices were not scanned successfully." -color Yellow
            LogText "No rescans are currently scheduled." -color Yellow
            return PressAnyKey;
        }

        if (!(WaitForNextScan -NextScanTime $nextScanTime)) {
            # Rescanning was cancelled by user 
            return
        }
    }
}

function ScanDevicesInDeviceListInner ([string] $FileName) {

    # Check if the file exists
    if (-not (Test-Path $FileName)) {
        LogError "File $FileName was not found in folder $((Get-Location).Path)"
        return $true # No further scan required
    }

    $fullPathToScript = Resolve-Path ".\Scripts\Get-ComputerInventory.ps1"
    $fullPathOutputFolder = Resolve-Path $OutputFolder
    $computerList = Get-ComputerList -FilePath $FileName 
    $computerCount = ($computerList | Measure-Object).Count
    Write-Output "$FileName contains $computerCount devices"

    $sbInventory = {
        param($inventoryArgs)

        try {
            # Throttle CPU - Wait until CPU usage is below 50%
            while ((Get-WmiObject Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average -gt $($inventoryArgs.MaxCPUUsage)) {
                Start-Sleep -Seconds 5  # Wait 5 seconds before checking again
            }

            $scriptArgs = @{
                ComputerName = $inventoryArgs.ComputerName
                ScriptRegime = $inventoryArgs.ScriptRegime
                TargetType = $inventoryArgs.TargetType
                MicrosoftOnly = $inventoryArgs.MicrosoftOnly
                SkipPublisherCheck = $inventoryArgs.SkipPublisherCheck
                IgnoreCertificateErrors = $inventoryArgs.IgnoreCertificateErrors
                OutputFolder = $inventoryArgs.OutputFolder
                SummaryLogFile = $inventoryArgs.SummaryLogFile
            }

            if ($inventoryArgs.OutputFilePrefix) {
                $scriptArgs["OutputFilePrefix"] = $inventoryArgs.OutputFilePrefix
            }

            if ($inventoryArgs.UserName -and $inventoryArgs.Password) {
                $scriptArgs["UserName"] = $inventoryArgs.UserName
                $scriptArgs["Password"] = $inventoryArgs.Password
            }

            if ($inventoryArgs.OperatingSystem) {
                $scriptArgs["OperatingSystem"] = $inventoryArgs.OperatingSystem
            }

            if ($inventoryArgs.MostRecentLogon) {
                $scriptArgs["LastADLogon"] = $inventoryArgs.MostRecentLogon
            }

            $filePathPreviousResult = "$($inventoryArgs.OutputFolder)\Result.txt"
            #write-output "File: $filePathPreviousResult"
            if (Test-Path $filePathPreviousResult) {
                # Load the file contents
                $content = Get-Content -Path $filePathPreviousResult -Raw
                #write-output "Previous result: $filePathPreviousResult $content"
                if ($content.StartsWith("Success")) {
                    # The previous scan was successful, so skip this one
                    return 0
                }
            }

            #$scriptArgs | out-string | Write-Output
            #& "$($inventoryArgs.Script)" -ComputerName $($inventoryArgs.ComputerName) -OutputFolder $($inventoryArgs.OutputFolder) SummaryLogFile $($inventoryArgs.SummaryLogFile) -TargetType $($inventoryArgs.TargetType)
            $result = & "$($inventoryArgs.Script)" @scriptArgs

            return $result
        } catch {
            LogLastError
        } 
    }

    # Create a pool with a min of 1 and max of $MaxThreads concurrent runspaces
    $runspacePool = [runspacefactory]::CreateRunspacePool(1, $MaxThreads)  
    $runspacePool.Open()

    $runspaces = New-Object System.Collections.ArrayList

    foreach ($computer in $computerList) {

        if (!($computer.Name)) {
            continue
        }

        $blockArgs = @{
            Script = $fullPathToScript
            ComputerName = $computer.Name
            OperatingSystem = $computer.OperatingSystem
            MostRecentLogon = $computer.MostRecentLogon
            ScriptRegime = $ScriptRegime
            TargetType = $TargetType
            SkipPublisherCheck = $SkipPublisherCheck
            OutputFolder = ""
            OutputFilePrefix = ""
            SummaryLogFile = "$fullPathOutputFolder\Inventory\ScanLog.csv"
            MaxCPUUsage = $MaxCPUUsage
            UserName = if ($computer.UserName) { $computer.UserName } else { $UserName }
            Password = if ($computer.Password) { $computer.Password } else { $Password }
        }

        if ($MicrosoftOnly -like "*MSApps*") {
            $blockArgs["MicrosoftOnly"] = $true
        }
        if ($SaveInventoryFilesInSingleFolder) {
            $blockArgs["OutputFolder"] = "$fullPathOutputFolder\Inventory\"
            $blockArgs["OutputFilePrefix"] = "$($computer.Name)_"
        } else {
            $blockArgs["OutputFolder"] = "$fullPathOutputFolder\Inventory\$($computer.Name)"
        }
        if ($IgnoreCertificateErrors) {$blockArgs["IgnoreCertificateErrors"] = $IgnoreCertificateErrors}
        #LogText ($blockArgs | Out-String) 

        $powershell = [powershell]::Create().AddScript($sbInventory).AddArgument($blockArgs)
        $powershell.RunspacePool = $runspacePool
        [void]$runspaces.Add([PSCustomObject]@{
            Runspace = $powershell.BeginInvoke()
            PowerShell = $powershell
        })
    }

    $completedCount = 0
    $totalJobs = $runspaces.Count
    $results = @()

    ShowScanResultSummary -RemainingScans $totalJobs

    while ($runspaces.Count -gt 0) {
        
        Start-Sleep -Seconds 5  # Wait for 5 seconds before the next update

        # Check the completed jobs
        $completedRunspaces = $runspaces | Where-Object { $_.Runspace.IsCompleted -eq $true }

        # EndInvoke on the completed runspaces
        foreach ($completed in $completedRunspaces) {
            $results += $completed.PowerShell.EndInvoke($completed.Runspace)
            $completedCount++
            $runspaces.Remove($completed)  # Remove the completed runspace from the list
        }

        $remainingScans = ($totalJobs - $completedCount)
        ShowScanResultSummary -RemainingScans $remainingScans
    } 

    # Output the results
    #"Output"
    #$results | ForEach-Object { write-host $_ }

    $runspacePool.Close()
    $runspacePool.Dispose()

    # Did any of the scans fail?
    return (!($results -contains -1))
}

function Get-ComputerList {
    param (
        [Parameter(Mandatory=$true)]
        [string]$FilePath
    )

    # Read the first line to determine the format
    $firstLine = Get-Content -Path $FilePath -First 1
    if (!($firstLine)) {
        return @()
    }

    if ($firstLine.Contains(",")) {
        # It's in CSV format
        $computers = Import-Csv -Path $FilePath
    } else {
        # Assume it's a plain text file with one computer name per line
        $computers = Get-Content -Path $FilePath | ForEach-Object {
            [PSCustomObject]@{
                name = $_
                username = $null
                password = $null
                lastlogon = $null
                lastlogontimestamp = $null
                operatingsystem = $null
            }
        }
    }

    $result = $computers | ForEach-Object {
        # Convert the dates from string to DateTime objects, if they exist
        $lastLogon = if ($_.lastlogon) { [DateTime]::Parse($_.lastlogon) } else { $null }
        $lastLogonTimestamp = if ($_.lastlogontimestamp) { [DateTime]::Parse($_.lastlogontimestamp) } else { $null }

        # Determine the most recent date
        $mostRecentLogon = if ($lastLogon -and $lastLogonTimestamp) {
            if ($lastLogon -gt $lastLogonTimestamp) { $lastLogon } else { $lastLogonTimestamp }
        } elseif ($lastLogon) {
            $lastLogon
        } else {
            $lastLogonTimestamp
        }

        # Return the desired properties
        [PSCustomObject]@{
            Name            = $_.name
            Username        = $_.username
            Password        = $_.password
            OperatingSystem = $_.operatingsystem
            MostRecentLogon = if ($mostRecentLogon) { $mostRecentLogon.ToString("yyyy-MM-dd") } else { "" }
        }
    }

    return $result
}

function ShowScanResultSummary {
     param(
        [string] $RemainingScans = "",
        [System.ConsoleColor]$LeftColor = [System.ConsoleColor]::Blue,
        [string] $RightText,
        [System.ConsoleColor]$RightColor = [System.ConsoleColor]::DarkGray,
        [char] $FrameChar = "#",
        [switch] $FrameLine,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    $inventoryOutputFolder = "$OutputFolder\Inventory\"
    if (!(Test-Path $inventoryOutputFolder)) {
        New-Item -ItemType Directory -Path $inventoryOutputFolder | Out-Null
    }

    $cpuUsage = (Get-WmiObject Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
    #$cpuUsageFormatted = "{0:N2}" -f $cpuUsage
    $cpuUsageFormatted = "$([math]::Round($cpuUsage))%"

    # Import the CSV
    try {
        $data = Import-Csv "$OutputFolder\Inventory\ScanLog.csv" -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    } catch {
    }
    
    # Group by ComputerName
    $groupedData = $data | Group-Object -Property ComputerName

    # Select the most recent success or the most recent entry for each computer
    $selectedData = $groupedData | ForEach-Object {
        # Sort data for the current group by date in descending order
        $sortedData = $_.Group | Sort-Object { $_.ScanTime } -Descending

        # If there's a success in the sorted data, take it, otherwise take the most recent entry
        if ($sortedData | Where-Object { $_.Result -eq 'Success' }) {
            $sortedData | Where-Object { $_.Result -eq 'Success' } | Select-Object -First 1
        } else {
            $sortedData | Select-Object -First 1
        }
    }

    # Count the occurrences of each result
    $resultCounts = $selectedData | Group-Object -Property Result | Select-Object Name, Count

    # Save the latest result for each computer
    $latestRecords = $groupedData | ForEach-Object {
        $_.Group | Sort-Object ScanTime -Descending | Select-Object -First 1
    }
    $latestRecords | Export-MyCsv -Path "$OutputFolder\Inventory\ScanStatus.csv" 

    ClearHost
    ShowLogo
    LogHeaderText -LogTo Console -FrameChar "*"
    LogHeaderText -LogTo Console -FrameChar "*" -LeftText "Scan Result" -LeftColor DarkGray -RightText "#"
    LogHeaderText -LogTo Console -FrameChar "*" -LeftText "------------------------------" -LeftColor DarkGray -RightText "-----"

    if (!($resultCounts)) {
        LogHeaderText -LogTo Console -FrameChar "*" -LeftText "No scans completed" -LeftColor DarkGray
        LogHeaderText -LogTo Console -FrameChar "*"
    } else {
        $resultCounts | ForEach-Object {
            $numberColor = "Red"
            if ($_.Name -eq "Success") {
				$numberColor = "Green"
			}
            LogHeaderText -LogTo Console -FrameChar "*" -LeftText $_.Name -LeftColor Gray -RightText $_.Count.ToString() -RightColor $numberColor
        }
    }

    LogHeaderText -LogTo Console -FrameChar "*"

    if ($RemainingScans -ne "") {
		LogHeaderText -LogTo Console -FrameChar "*" -LeftText "Remaining Scans" -LeftColor Gray -RightText $RemainingScans -RightColor Gray
	}

    LogHeaderText -LogTo Console -FrameChar "*" -LeftText "Current CPU Usage" -LeftColor Gray -RightText $cpuUsageFormatted -RightColor Gray
    LogHeaderText -LogTo Console -FrameChar "*"
    LogHeaderText -LogTo Console -FrameChar "*" -FrameLine
}

function Get-NextScanStartTime {

    # Build the list of scan times
    $scanDaysAndTimes = @()

    # Split the string by ;
    $segments = $ScanSchedule -split ';' | Where-Object { $_ }

    foreach ($segment in $segments) {
        # Extract the text inside square brackets
        if ($segment -match '\[(.*?)\](.*)') {
            $numbersText = $matches[1]
            $times = $matches[2] -split ','
    
            # Build the list of days
            $days = @()
            $parts = $numbersText -split ','
            foreach ($part in $parts) {
                if ($part -match '(\d+)-(\d+)') {
                    # If it's a range, iterate through the range
                    $start = [int]$matches[1]
                    $end = [int]$matches[2]
                    for ($i = $start; $i -le $end; $i++) {
                        $days += $i
                    }
                } else {
                    # If it's a single number, just output it
                    $days += [int]$part
                }
            }

            foreach ($day in $days) {
                foreach ($time in $times) {
                    $scanDaysAndTimes += "$day-$time"
                }
            }
        }
    }

    if ($scanDaysAndTimes.Count -eq 0) {
        return $null
    }

    # What is the current day and time
    $currentDate = Get-Date
    $currentDayIndex = ([int]$currentDate.DayOfWeek + 6) % 7 + 1 # Monday = 1 ... Sunday = 7
    $currentTime24hr = $currentDate.ToString("HH:mm")
    $currentDayAndTime = "$currentDayIndex-$currentTime24hr"

    # Find the next scan time
    $nextScanTime = Get-NextString -StringList $scanDaysAndTimes -ReferenceString $currentDayAndTime
    if (!($nextScanTime)) {
        return $null
    }
    
    # Parse the next scan time string
    $dayIndex, $time = $nextScanTime -split '-'
    $hour, $minute = $time -split ':'

    # Calculate the difference in days
    $dayDifference = [int]$dayIndex - $currentDayIndex

    # If it's the same day and the time hasn't passed yet, set dayDifference to 0
    if ($dayDifference -eq 0 -and $currentDate.TimeOfDay -lt [TimeSpan]::FromHours($hour).Add([TimeSpan]::FromMinutes($minute))) {
        $dayDifference = 0
    }

    # Adjust for next week if the day index is before today's day index or if the time has already passed
    elseif ($dayDifference -le 0) {
        $dayDifference += 7
    }

    # Create the DateTime object
    $nextRunDate = $currentDate.Date.AddDays($dayDifference).AddHours($hour).AddMinutes($minute)

    return $nextRunDate
}

function Get-NextString {
    param (
        [Parameter(Mandatory=$true)]
        [string[]]$StringList,
        [Parameter(Mandatory=$true)]
        [string]$ReferenceString
    )

    # Sort the list alphabetically
    $sortedList = $StringList | Sort-Object

    # Iterate through the sorted list to find the next string
    foreach ($str in $sortedList) {
        if ($str -gt $ReferenceString) {
            return $str
        }
    }

    # If no string is greater than the reference, return the first string
    return $sortedList[0]
}

function ShowModuleInstallerMenu {

    $lstRequiredModules = @(
        @('VMware.PowerCLI', '13.1.0.21624340'),
        @('Hyper-V', ''),
        @('Microsoft.Graph', ''));

    $lstInstallModules = @();
    $lstOutdatedModules = @();
    $lstMissingModules = @();

    # Check each module
    foreach ($requiredModules in $lstRequiredModules) {
        $moduleName = $_[0];
        $moduleVersion = $_[1];

        $module = Get-Module -Name $moduleName -ListAvailable | Sort-Object Version -Descending | Select-Object -First 1

        if ($module) {
            if ($module.Version -lt $moduleVersion) {
                $lstOutdatedModules += $moduleName
            } else {
                $lstInstallModules += $moduleName
            }
        } else {
            $lstMissingModules += $moduleName
        }
    }
}

function ShowAboutScreen {
    
    ClearHost
    ShowLogo
    LogHeaderText -LogTo Console -FrameChar "*"
    LogHeaderText -LogTo Console -FrameChar "*" -LeftText "About" -LeftColor DarkGray 
    LogHeaderText -LogTo Console -FrameChar "*" -LeftText "-----" -LeftColor DarkGray 
    LogHeaderText -LogTo Console -FrameChar "*"

    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "The EY Script is a specialized tool developed by Ernst & Young" 
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "(EY) to enhance the facilitation of Microsoft software license"
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "compliance assessments. Referred to as 'EY Script', this tool"
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "is comprised of a collection of PowerShell scripts (*.ps1) that"
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "automate the process of collecting data regarding software"
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "installations on individual or multiple computer systems."
    
    LogHeaderText -LogTo Console -FrameChar "*"
    
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "Please note that the EY Script Tool is strictly to be used"
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "within the confines of EY performed license compliance"
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "assessments. EY retains all rights to the tool, including"
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "those related to copying, distribution, and transmission."
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "These actions must not be undertaken without EY's direct"
    LogHeaderText -LogTo Console -FrameChar "*" -LeftColor White -LeftText "and prior written consent"
    
    LogHeaderText -LogTo Console -FrameChar "*"
    LogHeaderText -LogTo Console -FrameChar "*" -FrameLine
}

Start-InventoryMenu
