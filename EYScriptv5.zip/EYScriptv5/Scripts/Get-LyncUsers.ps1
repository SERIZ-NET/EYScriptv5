##########################################################################
# 
# Get-LyncUsers
#
##########################################################################

<#
.SYNOPSIS
 The Get-LyncUsers script queries a single Lync server and produces up 1 CSV files
    1)    LyncUsers.csv - One record per user including enabled features and required CAL

.PARAMETER      UserName
Lync Server Username

.PARAMETER        Password
Lync Server Password

.PARAMETER      LyncServerName
Accepts a Fully Qualified Lync Server Domain Name
e.g. Server01.domain.local

.PARAMETER        OutputFile1
Output CSV file to store the results

.COPYRIGHT
Copyright (C) 2024 Ernst & Young Global Limited. All rights reserved. The Irish firm Ernst & Young is a member practice of Ernst & Young Global Limited.

This script is proprietary to Ernst & Young Global Limited (or one of its member firms). Unauthorized copying of this file, via any medium, is strictly prohibited. Redistribution and use in source and binary forms, with or without modification, are not permitted without prior written permission from Ernst & Young Global Limited.

.LICENSE
This script is provided "AS IS" without warranty of any kind. Ernst & Young Global Limited expressly disclaims all warranties, whether express, implied, statutory, or otherwise, with respect to this script including all implied warranties of merchantability, fitness for a particular purpose, and non-infringement. In no event shall Ernst & Young Global Limited be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this script, even if advised of the possibility of such damage.


#>

param(
    $UserName,
    $Password,
    [alias("server")]
    $LyncServer,
    [ValidateSet("Both", "RemoteSession","SnapIn")] 
    $ConnectionMethod = "Both",
    [ValidateSet("All","Servers","Clients")] 
    [string] $TargetType = "All",
    [string] $OutputFolder = ".\",
    [string] $OutputFilePrefix = "",
    [alias("o1")]
    $OutputFile1 = "SfBUsers.csv",
    [alias("o2")]
    [string] $LogFile = "SfBQueryLog.txt"
)

$ScriptDescription =       "Skype for Business Server Scan"
$ScriptVersion =           "5.0.10"

#region Logging
$script:OutFileSupportsNoNewLine = $false;
function InitialiseLogFile {

    if (!($script:OutputFolder)) {
        $script:OutputFolder = ".\"
    }

    if (!(Test-Path $script:OutputFolder)) {
        New-Item -ItemType Directory -Path $script:OutputFolder | Out-Null
    }

    $script:OutputFolder = Resolve-Path $script:OutputFolder | Select-Object -ExpandProperty Path

    if (!($script:OutputFolder.EndsWith('\'))) {
        $script:OutputFolder += '\'
    }

    if ($script:OutputFolder -and !($LogFile -like "*\*")) {
        $script:LogFile = Join-Path $script:OutputFolder "$($OutputFilePrefix)$LogFile"
    }

    if ($LogFile -and (Test-Path $LogFile)) {
        Remove-Item $LogFile
    }

    if ((Get-Command "Out-File").parameters["NoNewline"]) {
        $script:OutFileSupportsNoNewLine = $true;
    }

    PrefixOutputFilesWithFolder
    DecryptPassword
}

function PrefixOutputFilesWithFolder {
    
    # Check if $OutputFolder exists and is not empty
    if ($script:OutputFolder) {
        $counter = 1
        while ($true) {
            $outputFileVarName = "OutputFile$counter"
            # Check if the OutputFile variable exists
            if (Get-Variable -Name $outputFileVarName -Scope Script -ErrorAction SilentlyContinue) {
                # Get the value of the OutputFile variable
                $outputFileValue = Get-Variable -Name $outputFileVarName -ValueOnly -Scope Script
                # Check if it does not contain a backslash, and if so, prefix with OutputFolder
                if (-not $outputFileValue.Contains("\"))
                {
                    Set-Variable -Name $outputFileVarName -Value (Join-Path $script:OutputFolder "$($OutputFilePrefix)$outputFileValue") -Scope Script
                }
                $counter++
            } else {
                # Exit loop if the variable does not exist
                break
            }
        }
    }
} 

function LogText {
    param(
        [Parameter(Position=0, ValueFromRemainingArguments=$true, ValueFromPipeline=$true)]
        [Object] $Object,
        [System.ConsoleColor]$Color = [System.Console]::ForegroundColor,
        [switch]$NoNewLine = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"
    )

    if ($LogTo -ne "File") {
        # Display text on screen
        Write-Host -Object $Object -ForegroundColor $Color -NoNewline:$NoNewLine
    }
    
    if ($LogTo -ne "Console") {
        if ($LogFile) {
            if ($script:OutFileSupportsNoNewLine) {
                $Object | Out-File $LogFile -Encoding utf8 -Append -NoNewline:$NoNewLine 
            }
            else {
                $Object | Out-File $LogFile -Encoding utf8 -Append 
            }
        }
    }
}

function LogTimeAndText {
    param(
        [string] $Text,
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Blue,
        [switch]$IncludeDate = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    $output = "";
    if ($IncludeDate) {
        $output = Get-Date -Format "yyyy-MM-dd HH:mm:ss.ff"
    } else {
        $output = Get-Date -Format "HH:mm:ss.ff"
    }

    $output += " - "
    $output += $Text
    LogText $output -Color $Color -LogTo $LogTo
}

function LogError([string[]]$errorDescription){
    if ($Verbose){
        LogText ""
    }

    $output = $errorDescription -join "`r`n              "
    LogTimeAndText $output -Color Red

    Start-Sleep -s 3
}

function LogLastException() {
    $currentException = $Error[0].Exception;

    while ($currentException)
    {
        LogText -Color Red $currentException
        LogText -Color Red $currentException.Data
        LogText -Color Red $currentException.HelpLink
        LogText -Color Red $currentException.HResult
        LogText -Color Red $currentException.Message
        LogText -Color Red $currentException.Source
        LogText -Color Red $currentException.StackTrace
        LogText -Color Red $currentException.TargetSite

        $currentException = $currentException.InnerException
    }

    Start-Sleep -s 3
}

$script:MostRecentActivity = ""
function LogProgress([string]$Activity, [string]$Status, [Int32]$PercentComplete, [switch]$Completed ){
    
    if ($Activity) {
        $script:MostRecentActivity = $Activity
    } else {
        if ($script:MostRecentActivity) {
            $Activity = $script:MostRecentActivity
        } else {
            $Activity = "Unspecified"
        }
    }
    Write-Progress -activity $Activity -Status $Status -percentComplete $PercentComplete -Completed:$Completed
    LogTimeAndText $Status
}

function GetScriptPath
{
    if($PSCommandPath){
        return $PSCommandPath; }
        
    if($MyInvocation.ScriptName){
        return $MyInvocation.ScriptName }
        
    if($script:MyInvocation.MyCommand.Path){
        return $script:MyInvocation.MyCommand.Path }

    return $script:MyInvocation.MyCommand.Definition
}

function GetDotNetFrameworkVersion {
    #$release = Get-ItemPropertyValue -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release
    $regKey = Get-Item -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    $release = $regKey.GetValue("Release")
    switch ($release) {
        { $_ -ge 533320 } { $version = "4.8.1 or later ($release)"; break }
        { $_ -ge 528040 } { $version = "4.8 ($release)"; break }
        { $_ -ge 461808 } { $version = "4.7.2 ($release)"; break }
        { $_ -ge 461308 } { $version = "4.7.1 ($release)"; break }
        { $_ -ge 460798 } { $version = "4.7 ($release)"; break }
        { $_ -ge 394802 } { $version = "4.6.2 ($release)"; break }
        { $_ -ge 394254 } { $version = "4.6.1 ($release)"; break }
        { $_ -ge 393295 } { $version = "4.6 ($release)"; break }
        { $_ -ge 379893 } { $version = "4.5.2 ($release)"; break }
        { $_ -ge 378675 } { $version = "4.5.1 ($release)"; break }
        { $_ -ge 378389 } { $version = "4.5 ($release)"; break }
        default { $version = $null; break }
    }

    return $version
}

function LogEnvironmentDetails ([string[]] $OtherDetails){

    $script:ScriptPath = GetScriptPath
    $script:ScriptName = split-path $ScriptPath -leaf

    LogText " "
    LogHeaderText -FrameLine 
    LogHeaderText -LeftText " _______     __" -LeftColor Yellow
    LogHeaderText -LeftText "|  ___\ \   / /" -LeftColor Yellow
    LogHeaderText -LeftText "| |__  \ \_/ / " -LeftColor Yellow
    LogHeaderText -LeftText "|  __|  \   /  " -LeftColor Yellow
    LogHeaderText -LeftText "| |____  | |   " -LeftColor Yellow -RightText "$ScriptDescription  "
    LogHeaderText -LeftText "|______| |_|   " -LeftColor Yellow -RightText "Version $ScriptVersion  "
    LogHeaderText
    LogHeaderText -FrameLine 

    LogText " "
    LogText " $ScriptName" -Color Green 
    LogText " "

    if ($PSVersionTable.PSVersion.Major -ge 3) {
        $oSDetails = Get-CimInstance -ClassName Win32_OperatingSystem
    } else {
        $oSDetails = Get-WmiObject -Class Win32_OperatingSystem
    }
    $elevated = [bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")
    $currentThread = [System.Threading.Thread]::CurrentThread
    $dotNetFrameworkVersion = GetDotNetFrameworkVersion
    LogText -Color Gray "Computer Name:          $($env:COMPUTERNAME)"
    LogText -Color Gray "User Name:              $($env:USERNAME)@$($env:USERDNSDOMAIN)"
    LogText -Color Gray "Windows Version:        $($oSDetails.Caption)($($oSDetails.Version))"
    LogText -Color Gray "Memory kB:              $($oSDetails.TotalVisibleMemorySize.ToString("N0")) ($($oSDetails.FreePhysicalMemory.ToString("N0")) Free)"
    LogText -Color Gray "Locale:                 $($oSDetails.Locale) (Language $($oSDetails.OSLanguage))"
    LogText -Color Gray "PowerShell Host:        $($host.Version.Major)"
    LogText -Color Gray "PowerShell Version:     $($PSVersionTable.PSVersion)"
    LogText -Color Gray "PowerShell Word Size:   $($([IntPtr]::size) * 8) bit"
    LogText -Color Gray "Script Path:            $ScriptPath"
    LogText -Color Gray "Working Directory:      $PWD"
    LogText -Color Gray "CLR Version:            $($PSVersionTable.CLRVersion)"
    LogText -Color Gray ".Net Framework Version: $dotNetFrameworkVersion"
    LogText -Color Gray "Elevated:               $elevated"
    LogText -Color Gray "Current Date Time:      $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
    LogText -Color Gray "Default Date Format:    $($CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern)"
    LogText -Color Gray "Current Culture:        $((Get-Culture).EnglishName) (UI: $((Get-UICulture).EnglishName))"
    
    if (Test-Path "Variable:OutputFolder") {
        LogText -Color Gray "Output Folder:          $OutputFolder" 
    }
    if (Test-Path "Variable:OutputFile1") {
        LogText -Color Gray "Output File 1:          $OutputFile1" 
    }
    if (Test-Path "Variable:LogFile") {
        LogText -Color Gray "Log File:               $LogFile" 
    }
    if (Test-Path "Variable:ComputerName") {
        LogText -Color Gray "Target Computer Name:   $ComputerName" 
    }
    if (Test-Path "Variable:UserName") {
        LogText -Color Gray "Script User Name:       $UserName"
    }
    if (Test-Path "Variable:MicrosoftOnly") {
        LogText -Color Gray "Microsoft Only:         $MicrosoftOnly"
    }
    if (Test-Path "Variable:TargetType") {
        LogText -Color Gray "Target Type:            $TargetType"
    }
    if (Test-Path "Variable:ScriptRegime") {
        LogText -Color Gray "Script Regime:          $ScriptRegime"
    }
    if (Test-Path "Variable:RequiredData") {
        LogText -Color Gray "Required Data:          $RequiredData"
    }

    foreach ($detail in $OtherDetails){
        LogText -Color Gray $detail
    }

    LogText -Color Gray ""

}

function LogHeaderText {
    param(
        [string] $LeftText = " ",
        [System.ConsoleColor]$LeftColor = [System.ConsoleColor]::Blue,
        [string] $RightText,
        [System.ConsoleColor]$RightColor = [System.ConsoleColor]::DarkGray,
        [char] $FrameChar = "#",
        [switch] $FrameLine,
        [switch] $LeftAlignRightText,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    if ($FrameLine) {
        $strFullText = "  " + ($FrameChar.ToString() * 69)
        LogText $strFullText -Color DarkGray -LogTo $LogTo
        return
    }

    $strLeftFrame = "  $FrameChar  "
    $strLeftText = $LeftText
    $strRightText = $RightText
    $strRightFrame = "  $FrameChar"
    if ($LeftAlignRightText) {
        $strRightText = $RightText.PadRight(63 - $LeftText.Length)
    } else {
        $strLeftText = $LeftText.PadRight(63 - $RightText.Length)
    }
    

    if ($LogTo -eq "Console" -or $LogTo -eq "Both") {
        LogText $strLeftFrame -LogTo "Console" -NoNewLine -Color DarkGray
        LogText $strLeftText -LogTo "Console" -NoNewLine -Color $LeftColor
        LogText $strRightText -LogTo "Console" -NoNewLine -Color $RightColor
        LogText $strRightFrame -LogTo "Console" -Color DarkGray
    }

    if ($LogTo -eq "File" -or $LogTo -eq "Both") {
        $strFullText = $strLeftFrame + $strLeftText + $strRightText + $strRightFrame
        LogText $strFullText -LogTo "File" 
    }
}

function DecryptPassword {
    $strOneTimePassword = "%OneTimePassword%" # Replace this with the one-time password
    if ($SecurePassword) {
        $baOneTimePassword = [System.Convert]::FromBase64String($strOneTimePassword)
        $baSecurePassword = [System.Convert]::FromBase64String($SecurePassword)
        for($i=0; $i -lt $baSecurePassword.count ; $i++)
        {
            $baSecurePassword[$i] = $baSecurePassword[$i] -bxor $baOneTimePassword[$i%$baOneTimePassword.Length]
        }
        $script:Password = [System.Text.Encoding]::Unicode.GetString($baSecurePassword);
    }
}
#endregion

#region Setup Output Formats
function SetupOutputFormats {
    # Standardise date/time output to ISO 8601'ish format
    $bOutputFormatsUpdated = $false
    $currentThread = [System.Threading.Thread]::CurrentThread
    $desiredShortPattern = 'yyyy-MM-dd'
    $desiredLongPattern = 'yyyy-MM-dd HH:mm:ss'

    try {
        $cultureInvariant = [CultureInfo]::InvariantCulture.Clone()
        $cultureInvariant.DateTimeFormat.ShortDatePattern = $desiredShortPattern
        $cultureInvariant.DateTimeFormat.LongDatePattern = $desiredLongPattern
        $cultureInvariant.NumberFormat.NumberGroupSeparator = ""  
        $cultureInvariant.NumberFormat.NumberDecimalSeparator = "."
        $currentThread.CurrentCulture = $cultureInvariant
        $bOutputFormatsUpdated = $true
    }
    catch {
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $currentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $currentThread.CurrentCulture.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $currentThread.CurrentCulture.NumberFormat.NumberGroupSeparator = ""  
            $currentThread.CurrentCulture.NumberDecimalSeparator = "."
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $cultureCopy = $currentThread.CurrentCulture.Clone()
            $cultureCopy.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $cultureCopy.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $cultureCopy.NumberFormat.NumberGroupSeparator = ""  
            $cultureCopy.NumberDecimalSeparator = "."
            $currentThread.CurrentCulture = $cultureCopy
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread using clone of current culture"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        LogText "Failed to update output formats"
    }
}
#endregion

#region Query User
function QueryUser([string]$Message, [string]$Prompt, [switch]$AsSecureString = $false, [string]$DefaultValue){
    $strResult = ""
    
    if ($Message) {
        LogText $Message -color Yellow
    }

    if ($DefaultValue) {
        $Prompt += " (Default [$DefaultValue])"
    }

    $Prompt += ": "
    LogText $Prompt -color Yellow -NoNewLine
    
    if ($Headless) {
        LogText " (Headless - Using Default Value)" -color Yellow
    }
    else {
        $strResult = Read-Host -AsSecureString:$AsSecureString
    }

    if(!$strResult -or ($strResult.Length -eq 0)) {
        $strResult = $DefaultValue
        if ($AsSecureString) {
            $strResult = ConvertTo-SecureString $strResult -AsPlainText -Force
        }
    }

    return $strResult
}

function Get-ConsoleCredential([String] $Message, [String] $DefaultUsername, [switch] $AsPSCredential)
{
    $strUsername = QueryUser -Message $Message -Prompt "Username" -DefaultValue $DefaultUsername
    if (!$strUsername){
        return $null
    }

    $strSecurePassword = QueryUser -Prompt "Password" -AsSecureString
    if (!$strSecurePassword){
        return $null
    }

    if ($AsPSCredential) {
        $Creds = New-Object System.Management.Automation.PSCredential ($strUsername, $strSecurePassword)
    } else {
        $Creds = New-Object PSObject

        $bstrSecurePassword = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($strSecurePassword)
        $strUnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstrSecurePassword)

        $Creds | Add-Member -MemberType NoteProperty -Name "UserName" -Value $strUsername
        $Creds | Add-Member -MemberType NoteProperty -Name "Password" -Value $strUnsecurePassword
    }

    return $Creds
}
#endregion


function EnvironmentConfigured {
    if (Get-Command "Get-CsSite" -errorAction SilentlyContinue){
        return $true
    }
    else {
        return $false
    }
}

# Standard CAL([bool]$bStdCAL), Enterprise CAL(bEntCAL), Plus CAL(bPlusCAL)
function CalculateCAL($bUserStatus, $bStdCAL, $bEntCAL, $bPlusCAL) {
    if (! $bUserStatus) {
        return "NO CAL"
    }
    elseif ($bPlusCAL) {
        return "Plus CAL"
    }
    elseif ($bEntCAL) {
        return "Enterprise CAL"
    }
    elseif ($bStdCAL) {
        return "Standard CAL"
    }
    else {
        return "NO CAL"
    }    
}

function Get-LyncUsers {
    
    InitialiseLogFile
    SetupOutputFormats
    LogEnvironmentDetails -OtherDetails @(
        "Server Parameter:       $LyncServer");

    if ($TargetType -eq "Servers") {
        LogText "No Server data to export." -Color Yellow
        return
    }

    Try {
        $bAuthenticate = $false
        $currConnectionMethod = ""

        if ($ConnectionMethod -eq "Both" -or $ConnectionMethod -eq "SnapIn") {
            $getModule = Get-Module -ListAvailable -Name Lync

            if($getModule) {
                # Import the specified Module if it exist
                Import-Module Lync -ErrorAction SilentlyContinue -ErrorVariable $errImport
                if (EnvironmentConfigured) {
                    LogProgress -activity "Lync Server - Module" -Status "Loaded Lync module" -percentComplete 10 
                    $bAuthenticate = $true
                    $currConnectionMethod = "SnapIn"
                }
            }
        }
        
        # If ConnectionMethod = Both
        # Check if importing module was successful from SnapIn method. 
        # If not then try the RemoteSession.
        if (!$bAuthenticate -and ( $ConnectionMethod -eq "Both" -or $ConnectionMethod -eq "RemoteSession" ) ) {

            if (!$LyncServer) {
                $LyncServer = QueryUser -Prompt "Lync Server FQDN" -DefaultValue "$($env:computerName).$($env:USERDNSDOMAIN)"
            }

            # Create the Credentials object if username has been provided
            if(!($UserName -and $Password)){
                $lyncCreds = Get-ConsoleCredential -DefaultUsername $UserName -Message "Lync Server Administrator Credentials Required"
            }
            else 
            {
                $securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
                $lyncCreds = New-Object System.Management.Automation.PSCredential ($UserName, $securePassword)
            }

            # URI for the LYNC Server
            $uri = "https://" + $LyncServer + "/OcsPowershell"
            LogProgress -activity "Lync Data Export" -Status "Connecting To Server $uri" -percentComplete 5        
            $session = New-PSSession -ConnectionURI $uri -Credential $lyncCreds -ErrorAction SilentlyContinue

            if(-not($session)) {
                LogError ("The script was unable to connect to Lync server", 
                            "To maximise the chance of connectivity, please",
                            "   1) Ensure that the Lync PowerShell Module is installed on this device and/or",
                            "   2) Execute this script on the Lync server")
                Exit
            }
            else {
                LogProgress -activity "Lync Data Export" -Status "Importing Lync Session" -percentComplete 10    
                
                # Import authenticated session
                $importSession = Import-PsSession $session -AllowClobber
                
                $bAuthenticate = $true
                $currConnectionMethod = "RemoteSession"
            }
        }
        
        if($bAuthenticate) {
            LogProgress -activity "Lync Data Export" -Status "Loading Lync users" -percentComplete 12
            $users = Get-CsUser
    
            $userCount = $users.count
            $subInterval = [int](70 / $userCount) / 6
            $percent = 20
            
            # Load all the policies
            $ConferencePolicies = Get-CsConferencingPolicy
            $VoicePolicies = Get-CsVoicePolicy          
          
            foreach ($user in $users) {
                LogText "Collecting user data for $($user.UserPrincipalName)"

                $bUserStatus = $false
                $bStdCAL = $false
                $bEntCAL = $false
                $bPlusCAL = $false
                $bVoicePolicy = $false
    
                $percent += [int]$subInterval
                
                # Check for Standard CAL requirement
                if ($user.Enabled) {
                    $bUserStatus = $true
                    $bStdCAL = $true
                }
                
                # Check for Enterprise CAL requirement
                if ($user.ConferencingPolicy -ne $null) {                    
                    $percent += [int]$subInterval
                    
                    # Get details of the Conferencing Policy
                    if($currConnectionMethod -eq "SnapIn") {
                        $userConfPolicy = $ConferencePolicies | Where-Object {$_.Identity -eq ("Tag:" + $user.ConferencingPolicy.FriendlyName)}
                    }
                    else {
                        $userConfPolicy = $ConferencePolicies | Where-Object {$_.Identity -eq ("Tag:" + $user.ConferencingPolicy)}
                        #$userConfPolicy = Get-CsConferencingPolicy $user.ConferencingPolicy
                    }

                    if ( ($userConfPolicy.AllowIPAudio -eq $true) -or `
                         ($userConfPolicy.AllowIPVideo -eq $true) -or `
                         ($userConfPolicy.AllowUserToScheduleMeetingsWithAppSharing -eq $true) -or `
                         ($userConfPolicy.EnableDataCollaboration -eq $true) ) {
                        # User needs Enterprise CAL
                        $bEntCAL = $true
                    }
                }

                if ($bEntCAL) {
                    $user | Add-Member -MemberType NoteProperty -Name AllowIPAudio -Value $userConfPolicy.AllowIPAudio
                    $user | Add-Member -MemberType NoteProperty -Name AllowIPVideo -Value $userConfPolicy.AllowIPVideo
                    $user | Add-Member -MemberType NoteProperty -Name AllowUserToScheduleMeetingsWithAppSharing -Value $userConfPolicy.AllowUserToScheduleMeetingsWithAppSharing
                    $user | Add-Member -MemberType NoteProperty -Name EnableDataCollaboration -Value $userConfPolicy.EnableDataCollaboration            
                }
                else {
                    $user | Add-Member -MemberType NoteProperty -Name AllowIPAudio -Value $false
                    $user | Add-Member -MemberType NoteProperty -Name AllowIPVideo -Value $false
                    $user | Add-Member -MemberType NoteProperty -Name AllowUserToScheduleMeetingsWithAppSharing -Value $false
                    $user | Add-Member -MemberType NoteProperty -Name EnableDataCollaboration -Value $false            
                }
                
                $percent += [int]$subInterval
                                            
                # Check for Plus CAL requirement
                if ($user.EnterpriseVoiceEnabled -eq $true) {
                    # If true then the user requires Plus CAL
                    $bPlusCAL = $true
                }
                
                # Check if any Voice Policy exist for the user in Plus CAL
                if ($user.VoicePolicy -ne $null) {
                    $percent += [int]$subInterval
                                
                    # Get details of the Voice Policy
                    if($currConnectionMethod -eq "SnapIn") {
                        $userVoicePolicy = $VoicePolicies | Where-Object {$_.Identity -eq ("Tag:" + $user.VoicePolicy.FriendlyName)}
                    }
                    else {
                        $userVoicePolicy = $VoicePolicies | Where-Object {$_.Identity -eq ("Tag:" + $user.VoicePolicy)}
                    }
            
                    $user | Add-Member -MemberType NoteProperty -Name AllowSimulRing -Value $userVoicePolicy.AllowSimulRing
                    $user | Add-Member -MemberType NoteProperty -Name AllowCallForwarding -Value $userVoicePolicy.AllowCallForwarding
                    $user | Add-Member -MemberType NoteProperty -Name AllowPSTNReRouting -Value $userVoicePolicy.AllowPSTNReRouting
                    $user | Add-Member -MemberType NoteProperty -Name EnableDelegation -Value $userVoicePolicy.EnableDelegation
                    $user | Add-Member -MemberType NoteProperty -Name EnableTeamCall -Value $userVoicePolicy.EnableTeamCall
                    $user | Add-Member -MemberType NoteProperty -Name EnableCallTransfer -Value $userVoicePolicy.EnableCallTransfer
                    $user | Add-Member -MemberType NoteProperty -Name EnableCallPark -Value $userVoicePolicy.EnableCallPark
                    $user | Add-Member -MemberType NoteProperty -Name EnableMaliciousCallTracing -Value $userVoicePolicy.EnableMaliciousCallTracing
                    $user | Add-Member -MemberType NoteProperty -Name EnableBWPolicyOverride -Value $userVoicePolicy.EnableBWPolicyOverride
                    $user | Add-Member -MemberType NoteProperty -Name PreventPSTNTollBypass -Value $userVoicePolicy.PreventPSTNTollBypass
                }
                else {
                    $user | Add-Member -MemberType NoteProperty -Name AllowSimulRing -Value $false
                    $user | Add-Member -MemberType NoteProperty -Name AllowCallForwarding -Value $false
                    $user | Add-Member -MemberType NoteProperty -Name AllowPSTNReRouting -Value $false
                    $user | Add-Member -MemberType NoteProperty -Name EnableDelegation -Value $false
                    $user | Add-Member -MemberType NoteProperty -Name EnableTeamCall -Value $false
                    $user | Add-Member -MemberType NoteProperty -Name EnableCallTransfer -Value $false
                    $user | Add-Member -MemberType NoteProperty -Name EnableCallPark -Value $false
                    $user | Add-Member -MemberType NoteProperty -Name EnableMaliciousCallTracing -Value $false
                    $user | Add-Member -MemberType NoteProperty -Name EnableBWPolicyOverride -Value $false
                    $user | Add-Member -MemberType NoteProperty -Name PreventPSTNTollBypass -Value $false
                }
                
                $percent += [int]$subInterval
                
                $CAL = CalculateCAL $bUserStatus $bStdCAL $bEntCAL $bPlusCAL

                # Add CAL to CSV    
                $user | Add-Member -MemberType NoteProperty -Name CALRequired -Value $CAL
            }   # End users for loop
    
            LogProgress -activity "Lync Data Export" -Status "Exporting Lync User Data" -percentComplete 95
            $users | Select-Object SamAccountName, UserPrincipalName, FirstName, LastName, `
                WindowsEmailAddress, Sid, AudioVideoDisabled, `
                IPPBXSoftPhoneRoutingEnabled, RemoteCallControlTelephonyEnabled, PrivateLine, `
                HostedVoiceMail, DisplayName, HomeServer, EnabledForFederation, `
                EnabledForInternetAccess, PublicNetworkEnabled, EnterpriseVoiceEnabled, EnabledForRichPresence, `
                SipAddress, Enabled, VoicePolicy, MobilityPolicy, `
                ConferencingPolicy, PresencePolicy, RegistrarPool, DialPlan, LocationPolicy, ClientPolicy, `
                ClientVersionPolicy, ArchivingPolicy, PinPolicy, ExternalAccessPolicy, HostedVoicemailPolicy, `
                Name, DistinguishedName, Identity, Guid, ObjectCategory, `
                WhenChanged, WhenCreated, OriginatingServer, IsValid, ObjectState, AllowIPAudio, AllowIPVideo, `
                AllowUserToScheduleMeetingsWithAppSharing, EnableDataCollaboration, AllowSimulRing, `
                AllowCallForwarding, AllowPSTNReRouting, EnableDelegation, EnableTeamCall, EnableCallTransfer, `
                EnableCallPark, EnableMaliciousCallTracing, EnableBWPolicyOverride, PreventPSTNTollBypass, CALRequired `
                | Export-Csv -NoTypeInformation -Path $OutputFile1 -Encoding UTF8 -Delimiter ","

            # Clear session
            if ($session) { 
                Remove-PsSession $session
            }

            LogProgress -activity "Lync Data Export" -Status "Lync User Data Exported" -percentComplete 100
        }
        else {
            LogError ("The script was unable to connect to Lync server", 
                        "To maximise the chance of connectivity, please",
                        "   1) Ensure that the Lync PowerShell Module is installed on this device and/or",
                        "   2) Execute this script on the Lync server") 
        }
    }
    catch {
        # Clear session
        if ($session) { 
            Remove-PsSession $session
        }
        LogLastException
    }
}

# Call the Get-LyncUsers Function to 
#    - Load Account Details
#    - Calculate an approximation on CAL required 
#    - Export CSV
Get-LyncUsers