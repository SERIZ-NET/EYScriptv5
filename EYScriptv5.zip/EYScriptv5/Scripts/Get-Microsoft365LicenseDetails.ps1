#########################################################
#                                                                     
# Get-Microsoft365LicenseDetails.ps1
#
#########################################################

 <#
.SYNOPSIS
Retrieves Microsoft 365 Licensing information for all the user accounts.

.DESCRIPTION
Retrieves licensing information for all the users accounts and outputs this information to a csv file. 
This information includes Username, User details like - Contact and office address, all Products available with company and details of licenses assigned to every user.

.PARAMETER      UserName
Office365 Account Username.

.PARAMETER      Password
Office365 Account Password.

.PARAMETER        OutputFile
Output CSV file to store the results. You can specify a specific location to output the csv file.

UserPrincipalName                 <User Registered Post Code>
DisplayName                       <Name>
SignInName                        <Signin Name>
Title                             <User Title>
MobilePhone                       <User Mobile Number>
PhoneNumber                       <User Phone Number>
Office                            <User Office Location>
City                              <User Specified City>
State                             <User Specified State>
PostalCode                        <User Specified Post Code>
WhenCreated                       <Date & Time>
LastPasswordChangeTimestamp       <Date & Time>
IsBlackberryUser                  True | False
LicenseReconciliationNeeded       True | False
PreferredLanguage                 en-Ie
UsageLocation                     ie
OverallProvisioningStatus         Success | PendingActivation | PendingInput
AlternateEmailAddresses           <Username>@<Company-Name>.Com
ProxyAddresses                    Smtp:<Username>@<LicenseName>.Onmicrosoft.Com; SMTP:<Username>@<Company-Name>.Com
ProductLicense_1                  Success | PendingActivation | PendingInput
ProductLicense_2                  Success | PendingActivation | PendingInput
...

.COPYRIGHT
Copyright (C) 2024 Ernst & Young Global Limited. All rights reserved. The Irish firm Ernst & Young is a member practice of Ernst & Young Global Limited.

This script is proprietary to Ernst & Young Global Limited (or one of its member firms). Unauthorized copying of this file, via any medium, is strictly prohibited. Redistribution and use in source and binary forms, with or without modification, are not permitted without prior written permission from Ernst & Young Global Limited.

.LICENSE
This script is provided "AS IS" without warranty of any kind. Ernst & Young Global Limited expressly disclaims all warranties, whether express, implied, statutory, or otherwise, with respect to this script including all implied warranties of merchantability, fitness for a particular purpose, and non-infringement. In no event shall Ernst & Young Global Limited be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this script, even if advised of the possibility of such damage.

#>

Param(
    [string] $OutputFolder = ".\",
    [string] $OutputFilePrefix = "",
    [alias("o1")]
    $OutputFile1 = "M365Licenses.csv",
    [alias("o2")]
    $OutputFile2 = "M365LicenseAssignments.csv",
    [alias("log")]
    [string] $LogFile = "M365QueryLog.txt",
    $Username,
    $Password,
    [switch] $ShortenPhoneNumbers,
    [switch] $Verbose)

$ScriptDescription =       "Microsoft 365 Export"
$ScriptVersion =           "5.0.10"

#region Logging
$script:OutFileSupportsNoNewLine = $false;
function InitialiseLogFile {

    if (!($script:OutputFolder)) {
        $script:OutputFolder = ".\"
    }

    if (!(Test-Path $script:OutputFolder)) {
        New-Item -ItemType Directory -Path $script:OutputFolder | Out-Null
    }

    $script:OutputFolder = Resolve-Path $script:OutputFolder | Select-Object -ExpandProperty Path

    if (!($script:OutputFolder.EndsWith('\'))) {
        $script:OutputFolder += '\'
    }

    if ($script:OutputFolder -and !($LogFile -like "*\*")) {
        $script:LogFile = Join-Path $script:OutputFolder "$($OutputFilePrefix)$LogFile"
    }

    if ($LogFile -and (Test-Path $LogFile)) {
        Remove-Item $LogFile
    }

    if ((Get-Command "Out-File").parameters["NoNewline"]) {
        $script:OutFileSupportsNoNewLine = $true;
    }

    PrefixOutputFilesWithFolder
    DecryptPassword
}

function PrefixOutputFilesWithFolder {
    
    # Check if $OutputFolder exists and is not empty
    if ($script:OutputFolder) {
        $counter = 1
        while ($true) {
            $outputFileVarName = "OutputFile$counter"
            # Check if the OutputFile variable exists
            if (Get-Variable -Name $outputFileVarName -Scope Script -ErrorAction SilentlyContinue) {
                # Get the value of the OutputFile variable
                $outputFileValue = Get-Variable -Name $outputFileVarName -ValueOnly -Scope Script
                # Check if it does not contain a backslash, and if so, prefix with OutputFolder
                if (-not $outputFileValue.Contains("\"))
                {
                    Set-Variable -Name $outputFileVarName -Value (Join-Path $script:OutputFolder "$($OutputFilePrefix)$outputFileValue") -Scope Script
                }
                $counter++
            } else {
                # Exit loop if the variable does not exist
                break
            }
        }
    }
} 

function LogText {
    param(
        [Parameter(Position=0, ValueFromRemainingArguments=$true, ValueFromPipeline=$true)]
        [Object] $Object,
        [System.ConsoleColor]$Color = [System.Console]::ForegroundColor,
        [switch]$NoNewLine = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"
    )

    if ($LogTo -ne "File") {
        # Display text on screen
        Write-Host -Object $Object -ForegroundColor $Color -NoNewline:$NoNewLine
    }
    
    if ($LogTo -ne "Console") {
        if ($LogFile) {
            if ($script:OutFileSupportsNoNewLine) {
                $Object | Out-File $LogFile -Encoding utf8 -Append -NoNewline:$NoNewLine 
            }
            else {
                $Object | Out-File $LogFile -Encoding utf8 -Append 
            }
        }
    }
}

function LogTimeAndText {
    param(
        [string] $Text,
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Blue,
        [switch]$IncludeDate = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    $output = "";
    if ($IncludeDate) {
        $output = Get-Date -Format "yyyy-MM-dd HH:mm:ss.ff"
    } else {
        $output = Get-Date -Format "HH:mm:ss.ff"
    }

    $output += " - "
    $output += $Text
    LogText $output -Color $Color -LogTo $LogTo
}

function LogError([string[]]$errorDescription){
    if ($Verbose){
        LogText ""
    }

    $output = $errorDescription -join "`r`n              "
    LogTimeAndText $output -Color Red

    Start-Sleep -s 3
}

function LogLastException() {
    $currentException = $Error[0].Exception;

    while ($currentException)
    {
        LogText -Color Red $currentException
        LogText -Color Red $currentException.Data
        LogText -Color Red $currentException.HelpLink
        LogText -Color Red $currentException.HResult
        LogText -Color Red $currentException.Message
        LogText -Color Red $currentException.Source
        LogText -Color Red $currentException.StackTrace
        LogText -Color Red $currentException.TargetSite

        $currentException = $currentException.InnerException
    }

    Start-Sleep -s 3
}

$script:MostRecentActivity = ""
function LogProgress([string]$Activity, [string]$Status, [Int32]$PercentComplete, [switch]$Completed ){
    
    if ($Activity) {
        $script:MostRecentActivity = $Activity
    } else {
        if ($script:MostRecentActivity) {
            $Activity = $script:MostRecentActivity
        } else {
            $Activity = "Unspecified"
        }
    }
    Write-Progress -activity $Activity -Status $Status -percentComplete $PercentComplete -Completed:$Completed
    LogTimeAndText $Status
}

function GetScriptPath
{
    if($PSCommandPath){
        return $PSCommandPath; }
        
    if($MyInvocation.ScriptName){
        return $MyInvocation.ScriptName }
        
    if($script:MyInvocation.MyCommand.Path){
        return $script:MyInvocation.MyCommand.Path }

    return $script:MyInvocation.MyCommand.Definition
}

function GetDotNetFrameworkVersion {
    #$release = Get-ItemPropertyValue -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release
    $regKey = Get-Item -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    $release = $regKey.GetValue("Release")
    switch ($release) {
        { $_ -ge 533320 } { $version = "4.8.1 or later ($release)"; break }
        { $_ -ge 528040 } { $version = "4.8 ($release)"; break }
        { $_ -ge 461808 } { $version = "4.7.2 ($release)"; break }
        { $_ -ge 461308 } { $version = "4.7.1 ($release)"; break }
        { $_ -ge 460798 } { $version = "4.7 ($release)"; break }
        { $_ -ge 394802 } { $version = "4.6.2 ($release)"; break }
        { $_ -ge 394254 } { $version = "4.6.1 ($release)"; break }
        { $_ -ge 393295 } { $version = "4.6 ($release)"; break }
        { $_ -ge 379893 } { $version = "4.5.2 ($release)"; break }
        { $_ -ge 378675 } { $version = "4.5.1 ($release)"; break }
        { $_ -ge 378389 } { $version = "4.5 ($release)"; break }
        default { $version = $null; break }
    }

    return $version
}

function LogEnvironmentDetails ([string[]] $OtherDetails){

    $script:ScriptPath = GetScriptPath
    $script:ScriptName = split-path $ScriptPath -leaf

    LogText " "
    LogHeaderText -FrameLine 
    LogHeaderText -LeftText " _______     __" -LeftColor Yellow
    LogHeaderText -LeftText "|  ___\ \   / /" -LeftColor Yellow
    LogHeaderText -LeftText "| |__  \ \_/ / " -LeftColor Yellow
    LogHeaderText -LeftText "|  __|  \   /  " -LeftColor Yellow
    LogHeaderText -LeftText "| |____  | |   " -LeftColor Yellow -RightText "$ScriptDescription  "
    LogHeaderText -LeftText "|______| |_|   " -LeftColor Yellow -RightText "Version $ScriptVersion  "
    LogHeaderText
    LogHeaderText -FrameLine 

    LogText " "
    LogText " $ScriptName" -Color Green 
    LogText " "

    if ($PSVersionTable.PSVersion.Major -ge 3) {
        $oSDetails = Get-CimInstance -ClassName Win32_OperatingSystem
    } else {
        $oSDetails = Get-WmiObject -Class Win32_OperatingSystem
    }
    $elevated = [bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")
    $currentThread = [System.Threading.Thread]::CurrentThread
    $dotNetFrameworkVersion = GetDotNetFrameworkVersion
    LogText -Color Gray "Computer Name:          $($env:COMPUTERNAME)"
    LogText -Color Gray "User Name:              $($env:USERNAME)@$($env:USERDNSDOMAIN)"
    LogText -Color Gray "Windows Version:        $($oSDetails.Caption)($($oSDetails.Version))"
    LogText -Color Gray "Memory kB:              $($oSDetails.TotalVisibleMemorySize.ToString("N0")) ($($oSDetails.FreePhysicalMemory.ToString("N0")) Free)"
    LogText -Color Gray "Locale:                 $($oSDetails.Locale) (Language $($oSDetails.OSLanguage))"
    LogText -Color Gray "PowerShell Host:        $($host.Version.Major)"
    LogText -Color Gray "PowerShell Version:     $($PSVersionTable.PSVersion)"
    LogText -Color Gray "PowerShell Word Size:   $($([IntPtr]::size) * 8) bit"
    LogText -Color Gray "Script Path:            $ScriptPath"
    LogText -Color Gray "Working Directory:      $PWD"
    LogText -Color Gray "CLR Version:            $($PSVersionTable.CLRVersion)"
    LogText -Color Gray ".Net Framework Version: $dotNetFrameworkVersion"
    LogText -Color Gray "Elevated:               $elevated"
    LogText -Color Gray "Current Date Time:      $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
    LogText -Color Gray "Default Date Format:    $($CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern)"
    LogText -Color Gray "Current Culture:        $((Get-Culture).EnglishName) (UI: $((Get-UICulture).EnglishName))"
    
    if (Test-Path "Variable:OutputFolder") {
        LogText -Color Gray "Output Folder:          $OutputFolder" 
    }
    if (Test-Path "Variable:OutputFile1") {
        LogText -Color Gray "Output File 1:          $OutputFile1" 
    }
    if (Test-Path "Variable:LogFile") {
        LogText -Color Gray "Log File:               $LogFile" 
    }
    if (Test-Path "Variable:ComputerName") {
        LogText -Color Gray "Target Computer Name:   $ComputerName" 
    }
    if (Test-Path "Variable:UserName") {
        LogText -Color Gray "Script User Name:       $UserName"
    }
    if (Test-Path "Variable:MicrosoftOnly") {
        LogText -Color Gray "Microsoft Only:         $MicrosoftOnly"
    }
    if (Test-Path "Variable:TargetType") {
        LogText -Color Gray "Target Type:            $TargetType"
    }
    if (Test-Path "Variable:ScriptRegime") {
        LogText -Color Gray "Script Regime:          $ScriptRegime"
    }
    if (Test-Path "Variable:RequiredData") {
        LogText -Color Gray "Required Data:          $RequiredData"
    }

    foreach ($detail in $OtherDetails){
        LogText -Color Gray $detail
    }

    LogText -Color Gray ""

}

function LogHeaderText {
    param(
        [string] $LeftText = " ",
        [System.ConsoleColor]$LeftColor = [System.ConsoleColor]::Blue,
        [string] $RightText,
        [System.ConsoleColor]$RightColor = [System.ConsoleColor]::DarkGray,
        [char] $FrameChar = "#",
        [switch] $FrameLine,
        [switch] $LeftAlignRightText,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    if ($FrameLine) {
        $strFullText = "  " + ($FrameChar.ToString() * 69)
        LogText $strFullText -Color DarkGray -LogTo $LogTo
        return
    }

    $strLeftFrame = "  $FrameChar  "
    $strLeftText = $LeftText
    $strRightText = $RightText
    $strRightFrame = "  $FrameChar"
    if ($LeftAlignRightText) {
        $strRightText = $RightText.PadRight(63 - $LeftText.Length)
    } else {
        $strLeftText = $LeftText.PadRight(63 - $RightText.Length)
    }
    

    if ($LogTo -eq "Console" -or $LogTo -eq "Both") {
        LogText $strLeftFrame -LogTo "Console" -NoNewLine -Color DarkGray
        LogText $strLeftText -LogTo "Console" -NoNewLine -Color $LeftColor
        LogText $strRightText -LogTo "Console" -NoNewLine -Color $RightColor
        LogText $strRightFrame -LogTo "Console" -Color DarkGray
    }

    if ($LogTo -eq "File" -or $LogTo -eq "Both") {
        $strFullText = $strLeftFrame + $strLeftText + $strRightText + $strRightFrame
        LogText $strFullText -LogTo "File" 
    }
}

function DecryptPassword {
    $strOneTimePassword = "%OneTimePassword%" # Replace this with the one-time password
    if ($SecurePassword) {
        $baOneTimePassword = [System.Convert]::FromBase64String($strOneTimePassword)
        $baSecurePassword = [System.Convert]::FromBase64String($SecurePassword)
        for($i=0; $i -lt $baSecurePassword.count ; $i++)
        {
            $baSecurePassword[$i] = $baSecurePassword[$i] -bxor $baOneTimePassword[$i%$baOneTimePassword.Length]
        }
        $script:Password = [System.Text.Encoding]::Unicode.GetString($baSecurePassword);
    }
}
#endregion

#region Setup Output Formats
function SetupOutputFormats {
    # Standardise date/time output to ISO 8601'ish format
    $bOutputFormatsUpdated = $false
    $currentThread = [System.Threading.Thread]::CurrentThread
    $desiredShortPattern = 'yyyy-MM-dd'
    $desiredLongPattern = 'yyyy-MM-dd HH:mm:ss'

    try {
        $cultureInvariant = [CultureInfo]::InvariantCulture.Clone()
        $cultureInvariant.DateTimeFormat.ShortDatePattern = $desiredShortPattern
        $cultureInvariant.DateTimeFormat.LongDatePattern = $desiredLongPattern
        $cultureInvariant.NumberFormat.NumberGroupSeparator = ""  
        $cultureInvariant.NumberFormat.NumberDecimalSeparator = "."
        $currentThread.CurrentCulture = $cultureInvariant
        $bOutputFormatsUpdated = $true
    }
    catch {
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $currentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $currentThread.CurrentCulture.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $currentThread.CurrentCulture.NumberFormat.NumberGroupSeparator = ""  
            $currentThread.CurrentCulture.NumberDecimalSeparator = "."
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $cultureCopy = $currentThread.CurrentCulture.Clone()
            $cultureCopy.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $cultureCopy.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $cultureCopy.NumberFormat.NumberGroupSeparator = ""  
            $cultureCopy.NumberDecimalSeparator = "."
            $currentThread.CurrentCulture = $cultureCopy
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread using clone of current culture"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        LogText "Failed to update output formats"
    }
}
#endregion

#region Query User
function QueryUser([string]$Message, [string]$Prompt, [switch]$AsSecureString = $false, [string]$DefaultValue){
    $strResult = ""
    
    if ($Message) {
        LogText $Message -color Yellow
    }

    if ($DefaultValue) {
        $Prompt += " (Default [$DefaultValue])"
    }

    $Prompt += ": "
    LogText $Prompt -color Yellow -NoNewLine
    
    if ($Headless) {
        LogText " (Headless - Using Default Value)" -color Yellow
    }
    else {
        $strResult = Read-Host -AsSecureString:$AsSecureString
    }

    if(!$strResult -or ($strResult.Length -eq 0)) {
        $strResult = $DefaultValue
        if ($AsSecureString) {
            $strResult = ConvertTo-SecureString $strResult -AsPlainText -Force
        }
    }

    return $strResult
}

function Get-ConsoleCredential([String] $Message, [String] $DefaultUsername, [switch] $AsPSCredential)
{
    $strUsername = QueryUser -Message $Message -Prompt "Username" -DefaultValue $DefaultUsername
    if (!$strUsername){
        return $null
    }

    $strSecurePassword = QueryUser -Prompt "Password" -AsSecureString
    if (!$strSecurePassword){
        return $null
    }

    if ($AsPSCredential) {
        $Creds = New-Object System.Management.Automation.PSCredential ($strUsername, $strSecurePassword)
    } else {
        $Creds = New-Object PSObject

        $bstrSecurePassword = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($strSecurePassword)
        $strUnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstrSecurePassword)

        $Creds | Add-Member -MemberType NoteProperty -Name "UserName" -Value $strUsername
        $Creds | Add-Member -MemberType NoteProperty -Name "Password" -Value $strUnsecurePassword
    }

    return $Creds
}
#endregion

#region Test Connection
$script:ConnectionDetails = [PSCustomObject][ordered]@{
    TargetName = ""
    ComputerName = ""
    ComputerDomain = ""
    IPAddress0 = ""
    NameResolution = [Nullable[bool]]$null
    Ping = [Nullable[bool]]$null
    PortSSH = [Nullable[bool]]$null
    PortHTTP = [Nullable[bool]]$null
    PortWMI = [Nullable[bool]]$null
    PortSMB1 = [Nullable[bool]]$null
    PortHTTPS = [Nullable[bool]]$null
    PortSMB2 = [Nullable[bool]]$null
    PortSQL = [Nullable[bool]]$null
    PortRDP = [Nullable[bool]]$null
    PortWinRM = [Nullable[bool]]$null
    PortWinRMS = [Nullable[bool]]$null 
    OtherPorts = @{}
    Error = ""
    ErrorDetails = ""
    CimConnectionType = $null
    CimSession = $null
    PSSession = $null
    HKLM = $null
    HKU = $null
}

function TestConnectivity {
    param(
        [string] $Target,
        [int[]] $Ports = @(22, 80, 135, 139, 443, 445, 1433, 3389, 5985, 5986)
    )

    $ConnectionDetails.TargetName = $Target
    $ConnectionDetails.ComputerName = $Target

    # Test name resolution
    LogText "Name Resolution: " -NoNewLine -Color Gray
    $ConnectionDetails.NameResolution = $false;
    try {
        $nameResolutionResult = [System.Net.Dns]::GetHostAddresses($Target)
        if ($nameResolutionResult.Count -gt 0) {
            $ConnectionDetails.IPAddress0 = $nameResolutionResult[0].IPAddressToString
            $ConnectionDetails.NameResolution = $true;
        }
    } catch {}
    
    if ($ConnectionDetails.NameResolution) {
        LogText "Succeeded" -Color Green
    } else {
        LogText "Failed" -Color Red
        return;
    }
    
    # Test Ping
    LogText "Ping: " -NoNewLine -Color Gray
    $ConnectionDetails.Ping = $false;
    try {
        $pingResult = Test-Connection -ComputerName $Target -Count 1 -ErrorAction SilentlyContinue
        if ($pingResult.StatusCode -eq 0) {
            $ConnectionDetails.Ping = $true
        } else {
            $ConnectionDetails.Ping = $false
        }
    } catch {}
    
    if ($ConnectionDetails.Ping) {
        LogText "Succeeded" -Color Green
    } else {
        LogText "Failed" -Color Red
    }
    
    # Test Ports
    LogText "Port Scan: " -NoNewLine -Color Gray

    $sockets = @()
    $asyncResults = @()

    # Start connections
    foreach ($port in $Ports) {
        $socket = New-Object System.Net.Sockets.TcpClient
        $sockets += $socket

        $asyncResult = $socket.BeginConnect($Target, $port, $null, $null)
        $asyncResults += $asyncResult
    }

    # Wait for 2 seconds or until all sockets have connected
    $timeout = 2000
    $endTime = (Get-Date).AddMilliseconds($timeout)

    foreach ($asyncResult in $asyncResults) {
        $remainingTime = ($endTime - (Get-Date)).TotalMilliseconds
        if ($remainingTime -le 0) {
            break
        }
        $asyncResult.AsyncWaitHandle.WaitOne($remainingTime) | Out-Null
    }

    # Check the status of each socket
    for ($i = 0; $i -lt $sockets.Count; $i++) {
        $socket = $sockets[$i]
        $port = $ports[$i]

        switch ($port) {
            22 {
                $ConnectionDetails.PortSSH = $socket.Connected
            }
            80 {
                $ConnectionDetails.PortHTTP = $socket.Connected
            }
            135 {
                $ConnectionDetails.PortWMI = $socket.Connected
            }
            139 {
                $ConnectionDetails.PortSMB1 = $socket.Connected
            }
            443 {
                $ConnectionDetails.PortHTTPS = $socket.Connected
            }
            445 {
                $ConnectionDetails.PortSMB2 = $socket.Connected
            }
            1433 {
                $ConnectionDetails.PortSQL = $socket.Connected
            }
            3389 {
                $ConnectionDetails.PortRDP = $socket.Connected
            }
            5985 {
                $ConnectionDetails.PortWinRM = $socket.Connected
            }
            5986 {
                $ConnectionDetails.PortWinRMS = $socket.Connected
            }
            default {
                $ConnectionDetails.OtherPorts.Add($port, $socket.Connected)
            }
        }

        # Close the socket
        $socket.Close()
    }

    LogConnectionResult -PortName "SSH" -Result $ConnectionDetails.PortSSH;
    LogConnectionResult -PortName "HTTP" -Result $ConnectionDetails.PortHTTP;
    LogConnectionResult -PortName "WMI" -Result $ConnectionDetails.PortWMI;
    LogConnectionResult -PortName "SMB" -Result $ConnectionDetails.PortSMB1;
    LogConnectionResult -PortName "HTTPS" -Result $ConnectionDetails.PortHTTPS;
    LogConnectionResult -PortName "SQL" -Result $ConnectionDetails.PortSQL;
    LogConnectionResult -PortName "RDP" -Result $ConnectionDetails.PortRDP;
    LogConnectionResult -PortName "WinRM" -Result $ConnectionDetails.PortWinRM;
    LogConnectionResult -PortName "WinRMS" -Result $ConnectionDetails.PortWinRMS;
    LogText ""

    # OtherPorts
}

function LogConnectionResult {
    param(
        [string] $PortName,
        $Result
    )

    if ($null -eq $Result) {
        return;
    }

    $resultText = "Failed"
    $colour = [System.ConsoleColor]::Yellow;
    if ($Result) {
        $resultText = "Succeeded"
        $colour = [System.ConsoleColor]::Green;
    }

    LogText "$PortName " -NoNewLine -Color $colour -LogTo Console
    LogText "$($PortName): $resultText"  -LogTo File
}
#endregion

#region Custom Export
$ScriptExcludeFields = $null
function Export-MyCsv {
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [PSCustomObject[]] $InputObject,
        [Parameter(Mandatory = $true)]
        [string] $Path,
        [switch] $Append,
        [switch] $IncludeIndex
    )

    begin {
        if ($null -eq $ScriptExcludeFields) {
            LoadExcludeFields
        }

        $fileExcludeFields = $null
        $fileID = GetFileNameFinalPart -FilePath $Path
        if ($ScriptExcludeFields.ContainsKey($fileID)) {
            $fileExcludeFields = $ScriptExcludeFields[$fileID].Split(',') | ForEach-Object { $_.Trim() }
        }

        $index = 1
        $outputData = New-Object 'System.Collections.Generic.List[object]'
    }

    process {
        foreach ($item in $InputObject) {
            
            # Create a duplicate of the item with only the required fields
            $processedItem = New-Object PSObject 
            foreach ($prop in $item.PSObject.Properties) {
                if ($null -eq $fileExcludeFields -or !$fileExcludeFields.Contains($prop.Name)) {
                    $processedItem | Add-Member -MemberType NoteProperty -Name $prop.Name -Value $prop.Value -Force
                }
            }

            # Add index if requested
            if ($IncludeIndex) {
                $processedItem | Add-Member -MemberType NoteProperty -Name 'Index' -Value $index -Force
                $index++
            }

            # Add the processed item to the list
            $outputData.Add($processedItem)
        }
    }

    end {
        # Convert the list to an array and export to CSV
        $outputData.ToArray() | Export-Csv -Path $Path -Encoding UTF8 -NoTypeInformation -Append:$Append -Delimiter ","

        # This function logs the field names and sample values of exported data to the log file and a CSV file
        # Uncomment the following line to enable this functionality
        #LogFieldInfo -InputObject $outputData -OutputFileName $fileID
        $outputData = $null
    }
}

function LoadExcludeFields {
    $script:ScriptExcludeFields = @{}

    if (!($ScriptDescription)) {
        return
    }

    # Import the CSV
    try {
        $csvData = Import-Csv -Path ".\ExcludeFields.csv" -ErrorAction SilentlyContinue
    } catch {
    }

    foreach ($row in $csvData | Where-Object { $_.Script -eq $ScriptDescription }) {
        $ScriptExcludeFields[$row.OutputFile] = $row.ExcludeFields
    }
}

function GetFileNameFinalPart {
    param (
        [string]$FilePath
    )

    # Return the last part of the filename i.e. Apps for the following values
    # c:\temp\20240102_101212_Apps.csv
    # c:\temp\Apps.csv

    # Get the filename without the extension
    $fileNameWithoutExtension = [System.IO.Path]::GetFileNameWithoutExtension($FilePath)

    # Split the filename by underscore or backslash, and take the last part
    $lastPart = ($fileNameWithoutExtension -split '[\\_]')[-1]

    return $lastPart
}

# Support function. Not currently called. The function is used for custom testing to aid the local development team where necessary
function LogFieldInfo {
    param(
        [PSCustomObject[]] $InputObject,
        [string] $OutputFileName
    )
    
    # This function logs the field names and sample values of exported data to the log file and a CSV file
    # It is not enabled by default
    if (!($InputObject) -or $InputObject.Count -eq 0) {
        return
    }

    # Creating a new array of fields and sample values
    $lstFields = @()

    $recordIndex = 1
    foreach ($record in $InputObject) {
        $fieldNames = $record.PSObject.Properties.Name
        $fieldIndex = 1

        # Iterate through each property
        foreach ($fieldName in $fieldNames) {
            # Creating a new object for each property
            $field = [PSCustomObject][ordered]@{
                ScriptFileName = $ScriptName
                ScriptDescription = $ScriptDescription
                OutputFileName = $OutputFileName
                FieldName = $fieldName
                SampleValue = $record.$fieldName
                FieldIndex = $fieldIndex++
                RecordIndex = $recordIndex
            }

            # Add new object to the array
            $lstFields += $field
        }
    
        $recordIndex++
        if ($recordIndex -gt 3) {
            break
        }
    }

    # Save the field info to log file and csv file
    $csvLines = $lstFields | ConvertTo-Csv -NoTypeInformation
    $csvString = $csvLines -join "`n"
    LogText $csvString -LogTo File
    $lstFields | export-csv -Path ".\FieldInfo.csv" -NoTypeInformation -Append -Delimiter ","
}
#endregion

#region Ensure Module
function EnsureModuleLoaded {
    param (
        [Parameter(Mandatory=$true)]
        [string] $ModuleName,
        [Version] $MinimumVersion = '1.0.0'
    )

    try {
        # Check if the module is already loaded or available
        $module = Get-Module -Name $ModuleName -ListAvailable | Sort-Object Version -Descending | Select-Object -First 1
        $strDefaultInstallAction = "Y"
        if ($Headless) {
            $strDefaultInstallAction = "N"
        }

        if ($module) {
            if ($module.Version -lt $MinimumVersion) {
                $userResponse = QueryUser -Prompt "$ModuleName version $($module.Version) is older than the required minimum version $MinimumVersion. Do you want to upgrade it now? (Y/N)" -DefaultValue $strDefaultInstallAction
                if ($userResponse -eq 'Y' -or $userResponse -eq 'y') {
                    try {
                        
                        $updateModuleParams = @{
                            Name = $ModuleName
                            Scope = "CurrentUser"
                            Force = $true
                            Confirm = $false 
                            ErrorAction = "Stop"
                        };

                        LogText "Calling 'Update-Module -Name $ModuleName -Force'"
                        LogText "The update can take 5-10 minutes without any visual feedback. Please be patient." -Color Gray
                        Update-Module @updateModuleParams
                        Import-Module -Name $ModuleName
                        LogText "Module $ModuleName upgraded and imported"
                        return $true
                    } catch {
                        LogError "Failed to upgrade $ModuleName. Error: $_"
                        LogText "If this problem persists, you can try calling 'Uninstall-Module -Name $ModuleName' and rerunning this script" -Color Yellow
                        return $false
                    }
                } else {
                    LogText "Module $ModuleName was not upgraded" -Color Red
                    LogText "To upgrade the required module, follow one of these methods:"
                    LogText ""
                    LogText "[Online Devices]"
                    LogText "1. Open a PowerShell console and run:"
                    LogText "   Update-Module -Name $ModuleName -Force"
                    LogText ""
                    LogText "[Offline Devices]"
                    LogText "1. On an internet-connected PC, open a PowerShell console and run:"
                    LogText "   Save-Module -Name $ModuleName -Path C:\Modules"
                    LogText ""
                    LogText "2. Transfer the contents from 'C:\Modules' on the online PC to:"
                    LogText "   C:\Program Files\WindowsPowerShell\Modules on the offline device."
                    LogText ""
                    LogText "[Alternative]"
                    LogText "1. Download and install directly from:"
                    LogText "   https://www.powershellgallery.com/packages/$ModuleName"
                    LogText ""
                    LogText "Note: Upgrading is essential for optimal functionality."
                    return $false
                }
            } elseif (-not (Get-Module -Name $ModuleName)) {
                LogText "Importing Module $ModuleName"
                Import-Module -Name $ModuleName
                LogText "Module $ModuleName imported"
                return $true
            } else {
                LogText "Module $ModuleName already imported"
                return $true
            }
            return
        }

        # If the module is not available, ask the user if they want to install it
        $userResponse = QueryUser -Prompt "A required module ($ModuleName) is not currently installed. Do you want to install it now? (Y/N)" -DefaultValue $strDefaultInstallAction
        if ($userResponse -eq 'Y' -or $userResponse -eq 'y') {
            try {
                $installModuleParams = @{
                    Name = $ModuleName
                    Scope = "CurrentUser"
                    MinimumVersion = $MinimumVersion
                    Force = $true 
                    Confirm = $false 
                    AllowClobber = $true
                    ErrorAction = "Stop"
                };

                if ($SkipPublisherCheck) {
                    $installModuleParams.Add("SkipPublisherCheck", $true)
                }

                LogText "Calling 'Install-Module -Name $ModuleName -Force'"
                LogText "The installation can take 5-10 minutes without any visual feedback. Please be patient." -Color Gray
                Install-Module @installModuleParams
                LogText "Importing Module $ModuleName"
                Import-Module -Name $ModuleName
                LogText "Module $ModuleName has been installed"
                return $true
            } catch {
                LogError "Failed to install $ModuleName. Error: $_"
                return $false
            }
        } else {
            LogText "Module $ModuleName was not installed" -Color Red
            LogText "To install the required module, follow one of these methods:"
            LogText ""
            LogText "[Online Devices]"
            LogText "1. Open a PowerShell console and run:"
            LogText "   Install-Module -Name $ModuleName -Force"
            LogText ""
            LogText "[Offline Devices]"
            LogText "1. On an internet-connected PC, open a PowerShell console and run:"
            LogText "   Save-Module -Name $ModuleName -Path C:\Modules"
            LogText ""
            LogText "2. Transfer the contents from 'C:\Modules' on the online PC to:"
            LogText "   C:\Program Files\WindowsPowerShell\Modules on the offline device."
            LogText ""
            LogText "[Alternative]"
            LogText "1. Download and install directly from:"
            LogText "   https://www.powershellgallery.com/packages/$ModuleName"
            LogText ""
            LogText "Note: Installation is essential for this script to work"
            
            return $false
        }
    } catch {
        LogLastException
    }

    return $false
}
#endregion

#region Utilities
function MaskPhoneNumber {
    param (
        [string]$PhoneNumber
    )

    if (!($PhoneNumber)) {
        return ""
    }

    $digitCount = 0
    $maskedNumber = -join ($PhoneNumber.ToCharArray() | ForEach-Object {
        if ($_ -match '\d') {
            $digitCount++
            if ($digitCount -le 3) { $_ } else { '*' }
        } else {
            $_
        }
    })

    return $maskedNumber
}
#endregion


function ConnectToMsol() {
    LogProgress -Activity "Microsoft 365 Data Export" -Status "Connecting to Microsoft 365 Server" -percentComplete 30

    # Create the Credentials object if username has been provided
    #if(!($UserName -and $Password)){
    #    $credential = Get-ConsoleCredential -DefaultUsername $UserName -Message "Microsoft 365 Administrator Credentials Required" -AsPSCredential
    #}
    #else {
    #    $securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
    #    $credential = New-Object System.Management.Automation.PSCredential ($UserName, $securePassword)
    #}

    ## Add the account user has entered
    Connect-MsolService  -ErrorAction SilentlyContinue -ErrorVariable errConn #-Credential $credential
    
    if ($errConn -ne $null) {
        LogError "Authentication - Incorrect login details. Please verify the credentials and try again."     
        return $false
    }

    LogProgress -Activity "Microsoft 365 Data Export" -Status "Connected to Microsoft 365 Server" -percentComplete 40
    return $true
}

function ExportOffice365Data() {

    # Get a list of all licences that exist within the tenant
    LogProgress -Activity 'Microsoft 365 Data Export' -Status 'Querying Available Licenses' -percentComplete 45
    $orgLicenses = Get-MsolAccountSku 
    
    try {
        $test = $orgLicenses.GetType()
    }
    catch {
        LogError "An error occurred when retrieving data from Microsoft 365", "Ensure valid credentials were provided"
        return $false
    }
    
    $orgLicensesInfo = $orgLicenses | Select-Object AccountName, SkuPartNumber, `
        @{Name="SkuName"; Expression={LookupSkuName($_.SkuPartNumber)}}, SkuId, TargetClass, ActiveUnits, `
        ConsumedUnits, LockedOutUnits, SuspendedUnits, WarningUnits
    $orgLicensesInfo | Export-MyCsv -Path  $OutputFile1 -IncludeIndex

    # Get list of all the users
    LogProgress -Activity 'Microsoft 365 Data Export' -Status 'Querying User List' -percentComplete 55
    $users = Get-MsolUser -all | Where-Object {$_.isLicensed -eq "True"}

    # Get license assignments
    LogProgress -Activity 'Microsoft 365 Data Export' -Status 'Querying License Assignments' -percentComplete 75
    $result = @()
    foreach ($user in $users) {

        if ($Verbose) {
            LogText "Querying License Assignments for User: $($user.displayname)"
        }
        
        # Get specific user details
        ##$userDetails = $user | Select -Property UserPrincipalName, DisplayName, SignInName, Title, MobilePhone, PhoneNumber, ObjectId, UserType, Department, Office, StreetAddress, City, State, PostalCode, Country, UsageLocation, WhenCreated, LastPasswordChangeTimestamp, PasswordNeverExpires, IsBlackberryUser, LicenseReconciliationNeeded, PreferredLanguage, OverallProvisioningStatus
        $userDetails = $user | Select-Object -Property UserPrincipalName, DisplayName, SignInName, Title, MobilePhone, PhoneNumber, ObjectId, UserType, Department, Office, City, State, Country, UsageLocation, WhenCreated, LastPasswordChangeTimestamp, PasswordNeverExpires, LicenseReconciliationNeeded, OverallProvisioningStatus
    
        if ($ShortenPhoneNumbers) {
            if ($userDetails.MobilePhone) {$userDetails.MobilePhone = MaskPhoneNumber -PhoneNumber $userDetails.MobilePhone}
            if ($userDetails.PhoneNumber) {$userDetails.PhoneNumber = MaskPhoneNumber -PhoneNumber $userDetails.PhoneNumber}
        }
        

        $altEmail = $user.AlternateEmailAddresses -join '; '
        $userDetails | Add-Member -MemberType NoteProperty -Name "AlternateEmailAddresses" -Value $altEmail
    
        ##$ProxyAddrs = $user.ProxyAddresses -join '; '
        ##$userDetails | Add-Member -MemberType NoteProperty -Name "ProxyAddresses" -Value $ProxyAddrs

        # Get list of User licenses
        $userLicenses = $user.Licenses
        
        $userLicensesSkus = @()
        $userLicensesSkuIDs = @()
        $userLicensesSkuNames = @()
        foreach ($license in $userLicenses) {
            $userLicensesSkus += $license.AccountSku.SkuPartNumber    
            $userLicensesSkuIDs += $license.AccountSkuId
            $userLicensesSkuNames += LookupSkuName($license.AccountSku.SkuPartNumber);
        }

        $userDetails | Add-Member -MemberType NoteProperty -Name "LicenseSkus" -Value ($userLicensesSkus -join ";")
        $userDetails | Add-Member -MemberType NoteProperty -Name "LicenseNames" -Value ($userLicensesSkuNames -join ";")
        
        if ($null -ne $userLicensesSkuIDs) {
            # loop through all licenses subscribed by organisation.
            foreach ($orgLicense in $orgLicenses) {        
                $license = $orgLicense.SkuPartNumber

                # Check if the current license is present in the users license list
                if ($userLicensesSkuIDs -contains $orgLicense.AccountSkuId) {
                    # Retrieve specific license from users licenses
                    $userLicense = $userLicenses | Where-Object { $_.AccountSku.SkuPartNumber -eq $license }

                    # Add license title
                    $licenseDetails += '(' + $userLicense.AccountSku.AccountName + ')'            
                
                    # Loop through all the services in the license.
                    foreach ($serviceStatus in $userLicense.ServiceStatus) {
                        $licenseDetails += $serviceStatus.ServicePlan.ServiceName + ':' + $serviceStatus.ProvisioningStatus + ';'
                    }
                }

                # Add the license details to the list
                $userDetails | Add-Member -MemberType NoteProperty -Name $license -Value $licenseDetails
                $licenseDetails = ''
            }
        }
        
        $result += $userDetails
    }

    # Export users details to CSV
    $result | Export-MyCsv -Path $OutputFile2 -IncludeIndex

    return $true
}

function LookupSkuName ([string] $Sku) {
    # Return a friendly name for the Microsoft 365 SKU (if available)
    switch ($Sku) 
    {
        "AAD_BASIC" {return "Azure Active Directory Basic"}
        "AAD_PREMIUM" {return "Azure Active Directory Premium"}
        "ATP_ENTERPRISE" {return "Exchange Online Advanced Threat Protection"}
        "BI_AZURE_P1" {return "Power BI Reporting and Analytics"}
        "BI_AZURE_P2" {return "Power BI Pro"}
        "CRMINSTANCE" {return "Dynamics CRM Online Additional Production Instance"}
        "CRMIUR" {return "CRM for Partners"}
        "CRMPLAN1" {return "Dynamics CRM Online Essential"}
        "CRMPLAN2" {return "Dynamics CRM Online Basic"}
        "CRMSTANDARD" {return "CRM Online"}
        "CRMSTORAGE" {return "Dynamics CRM Online Additional Storage"}
        "CRMTESTINSTANCE" {return "CRM Test Instance"}
        "DESKLESSPACK" {return "Office 365 (Plan K1)"}
        "DESKLESSPACK_GOV" {return "Office 365 (Plan K1) for Government"}
        "DESKLESSPACK_YAMME" {return "Office 365 (Plan K1) with Yammer"}
        "DESKLESSWOFFPACK" {return "Office 365 (Plan K2)"}
        "DESKLESSWOFFPACK_GOV" {return "Office 365 (Plan K2) for Government"}
        "EMS" {return "Enterprise Mobility Suite"}
        "ENTERPRISEPACK" {return "Office 365 (Plan E3)"}
        "ENTERPRISEPACK_B_PILOT" {return "Office 365 (Enterprise Preview)"}
        "ENTERPRISEPACK_FACULTY" {return "Office 365 (Plan A3) for Faculty"}
        "ENTERPRISEPACK_GOV" {return "Office 365 (Plan G3) for Government"}
        "ENTERPRISEPACK_STUDENT" {return "Office 365 (Plan A3) for Students"}
        "ENTERPRISEPACKLRG" {return "Office 365 (Plan E3)"}
        "ENTERPRISEPACKWSCAL" {return "Office 365 (Plan E4)"}
        "ENTERPRISEPREMIUM_NOPSTNCONF" {return "Office 365 (Plan E5) Without PSTN"}
        "ENTERPRISEWITHSCAL" {return "Office 365 (Plan E4)"}
        "ENTERPRISEWITHSCAL_FACULTY" {return "Office 365 (Plan A4) for Faculty"}
        "ENTERPRISEWITHSCAL_GOV" {return "Office 365 (Plan G4) for Government"}
        "ENTERPRISEWITHSCAL_STUDENT" {return "Office 365 (Plan A4) for Students"}
        "EOP_ENTERPRISE" {return "Exchange Online Protection"}
        "EOP_ENTERPRISE_FACULTY" {return "Exchange Online Protection for Faculty"}
        "EQUIVIO_ANALYTICS" {return "Office 365 Advanced eDiscovery"}
        "ESKLESSWOFFPACK_GOV" {return "Office 365 (Plan K2) for Government"}
        "EXCHANGE_ANALYTICS" {return "Delve Analytics"}
        "EXCHANGE_L_STANDARD" {return "Exchange Online (Plan 1)"}
        "EXCHANGE_S_ARCHIVE_ADDON_GOV" {return "Exchange Online Archiving for Government"}
        "EXCHANGE_S_DESKLESS" {return "Exchange Online Kiosk"}
        "EXCHANGE_S_DESKLESS_GOV" {return "Exchange Kiosk for Government"}
        "EXCHANGE_S_ENTERPRISE_GOV" {return "Exchange (Plan G2) for Government"}
        "EXCHANGE_S_STANDARD" {return "Exchange Online (Plan 2)"}
        "EXCHANGE_S_STANDARD_MIDMARKET" {return "Exchange Online (Plan 1)"}
        "EXCHANGEARCHIVE" {return "Exchange Online Archiving"}
        "EXCHANGEARCHIVE_ADDON" {return "Exchange Online Archiving for Exchange Online"}
        "EXCHANGEDESKLESS" {return "Exchange Online Kiosk"}
        "EXCHANGEENTERPRISE" {return "Exchange Online (Plan 2)"}
        "EXCHANGEENTERPRISE_GOV" {return "Office 365 Exchange Online (Plan 2) for Government"}
        "EXCHANGESTANDARD" {return "Exchange Online (Plan 1)"}
        "EXCHANGESTANDARD_GOV" {return "Office 365 Exchange Online (Plan 1) for Government"}
        "EXCHANGESTANDARD_STUDENT" {return "Exchange Online (Plan 1) for Students"}
        "EXCHANGETELCO" {return "Exchange Online POP"}
        "INTUNE_A" {return "Intune for Office 365"}
        "INTUNE_STORAGE" {return "Intune Extra Storage"}
        "LITEPACK" {return "Office 365 (Plan P1)"}
        "LITEPACK_P2" {return "Office 365 Small Business Premium"}
        "LOCKBOX" {return "Customer Lockbox"}
        "LOCKBOX_ENTERPRISE" {return "Customer Lockbox"}
        "MCOEV" {return "Skype for Business Cloud PBX"}
        "MCOIMP" {return "Skype for Business Online (Plan 1)"}
        "MCOLITE" {return "Skype for Business Online (Plan 1)"}
        "MCOPLUSCAL" {return "Skype for Business Plus CAL"}
        "MCOSTANDARD" {return "Skype for Business Online (Plan 2)"}
        "MCOSTANDARD_GOV" {return "Skype for Business (Plan G2) for Government"}
        "MCOSTANDARD_MIDMARKET" {return "Skype for Business Online (Plan 1)"}
        "MCOVOICECONF" {return "Lync Online (Plan 3)"}
        "MCVOICECONF" {return "Skype for Business Online (Plan 3)"}
        "MFA_PREMIUM" {return "Azure Multi-Factor Authentication"}
        "MIDSIZEPACK" {return "Office 365 Midsize Business"}
        "MS-AZR-0145P" {return "Azure"}
        "NBPOSTS" {return "Social Engagement Additional 10K Posts"}
        "NBPROFESSIONALFORCRM" {return "Social Listening Professional"}
        "O365_BUSINESS" {return "Office 365 Business"}
        "O365_BUSINESS_ESSENTIALS" {return "Office 365 Business Essentials"}
        "O365_BUSINESS_PREMIUM" {return "Office 365 Business Premium"}
        "OFFICE_PRO_PLUS_SUBSCRIPTION_SMBIZ" {return "Office ProPlus"}
        "OFFICESUBSCRIPTION" {return "Office ProPlus"}
        "OFFICESUBSCRIPTION_GOV" {return "Office ProPlus for Government"}
        "OFFICESUBSCRIPTION_STUDENT" {return "Office ProPlus Student Benefit"}
        "ONEDRIVESTANDARD" {return "OneDrive"}
        "POWER_BI_PRO" {return "Power BI Pro"}
        "POWER_BI_STANDALONE" {return "Power BI for Office 365"}
        "POWER_BI_STANDARD" {return "Power BI Standard"}
        "PROJECT_CLIENT_SUBSCRIPTION" {return "Project Pro for Office 365"}
        "PROJECT_ESSENTIALS" {return "Project Lite"}
        "PROJECTCLIENT" {return "Project Pro for Office 365"}
        "PROJECTESSENTIALS" {return "Project Lite"}
        "PROJECTONLINE_PLAN_1" {return "Project Online (Plan 1)"}
        "PROJECTONLINE_PLAN_2" {return "Project Online (Plan 2)"}
        "PROJECTONLINE_PLAN1_FACULTY" {return "Project Online for Faculty"}
        "PROJECTONLINE_PLAN1_STUDENT" {return "Project Online for Students"}
        "PROJECTWORKMANAGEMENT" {return "Office 365 Planner Preview"}
        "RIGHTSMANAGEMENT" {return "Azure Rights Management"}
        "RMS_S_ENTERPRISE" {return "Azure Active Directory Rights Management"}
        "RMS_S_ENTERPRISE_GOV" {return "Windows Azure Active Directory Rights Management for Government"}
        "SHAREPOINT_PROJECT_EDU" {return "Project Online for Education"}
        "SHAREPOINTDESKLESS" {return "SharePoint Online Kiosk"}
        "SHAREPOINTDESKLESS_GOV" {return "SharePoint Online Kiosk for Government"}
        "SHAREPOINTENTERPRISE" {return "SharePoint Online (Plan 2)"}
        "SHAREPOINTENTERPRISE_EDU" {return "SharePoint (Plan 2) for EDU"}
        "SHAREPOINTENTERPRISE_GOV" {return "SharePoint (Plan G2) for Government"}
        "SHAREPOINTENTERPRISE_MIDMARKET" {return "SharePoint Online (Plan 1)"}
        "SHAREPOINTLITE" {return "SharePoint Online (Plan 1)"}
        "SHAREPOINTPARTNER" {return "SharePoint Online Partner Access"}
        "SHAREPOINTSTANDARD" {return "SharePoint Online (Plan 1)"}
        "SHAREPOINTSTORAGE" {return "SharePoint Online Storage"}
        "SHAREPOINTWAC" {return "Office Online"}
        "SHAREPOINTWAC_EDU" {return "Office Online for Education"}
        "SHAREPOINTWAC_GOV" {return "Office Online for Government"}
        "SQL_IS_SSIM" {return "Power BI Information Services"}
        "STANDARD_B_PILOT" {return "Office 365 (Small Business Preview)"}
        "STANDARDPACK" {return "Office 365 (Plan E1)"}
        "STANDARDPACK_FACULTY" {return "Office 365 (Plan A1) for Faculty"}
        "STANDARDPACK_GOV" {return "Office 365 (Plan G1) for Government"}
        "STANDARDPACK_STUDENT" {return "Office 365 (Plan A1) for Students"}
        "STANDARDWOFFPACK" {return "Office 365 (Plan E2)"}
        "STANDARDWOFFPACK_FACULTY" {return "Office 365 Education E1 for Faculty"}
        "STANDARDWOFFPACK_GOV" {return "Office 365 (Plan G2) for Government"}
        "STANDARDWOFFPACK_IW_FACULTY" {return "Office 365 Education for Faculty"}
        "STANDARDWOFFPACK_IW_STUDENT" {return "Office 365 Education for Students"}
        "STANDARDWOFFPACK_STUDENT" {return "Office 365 (Plan A2) for Students"}
        "STANDARDWOFFPACKPACK_FACULTY" {return "Office 365 (Plan A2) for Faculty"}
        "STANDARDWOFFPACKPACK_STUDENT" {return "Office 365 (Plan A2) for Students"}
        "VISIO_CLIENT_SUBSCRIPTION" {return "Visio Pro for Office 365"}
        "VISIOCLIENT" {return "Visio Pro for Office 365"}
        "WACONEDRIVEENTERPRISE" {return "OneDrive for Business (Plan 2)"}
        "WACONEDRIVESTANDARD" {return "OneDrive Pack"}
        "WACSHAREPOINTENT" {return "Office Web Apps with SharePoint (Plan 2)"}
        "WACSHAREPOINTSTD" {return "Office Web Apps with SharePoint (Plan 1)"}
        "YAMMER_ENTERPRISE" {return "Yammer"}
        "YAMMER_ENTERPRISE_STANDALONE" {return "Yammer Enterprise"}
        "YAMMER_MIDSIZE" {return "Yammer"}
    }

    return $Sku
}

function Get-Office365LicenseDetails() {
    
    try {
        InitialiseLogFile
        SetupOutputFormats
        LogEnvironmentDetails

        if (!(EnsureModuleLoaded -ModuleName "MSOnline" -MinimumVersion "1.1.183.81")) {
            return
        }

        if (-not (ConnectToMsol)) {
            return;
        }

        if (-not (ExportOffice365Data)) {
            return;
        }

        LogProgress -Activity "Microsoft 365 Data Export" -Status "Export Complete" -percentComplete 100 -Completed $true
        LogText "Results available in $OutputFile1"
        Start-Sleep -s 3
    }
    catch {        
        LogLastException
    }
} 

Get-Office365LicenseDetails