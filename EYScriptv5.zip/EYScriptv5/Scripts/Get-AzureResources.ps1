 #########################################################
 #                                                                     
 # Get-AzureResources
 #
 #########################################################

 <#
.SYNOPSIS
Retrieves Azure installation data from a added Microsoft account

.DESCRIPTION
Retrieves Azure VM and database list for multiple accounts and outputs this information to csv files. 
This information includes SubscriptionId, SubscriptionName, Environment supported modes, DefaultAccount and more.
The User needs to pass the credentials to execute the script.

.PARAMETER      USERNAME
Enter only Organisational (work) or Student Azure Account Username

.PARAMETER       PASSWORD
Azure Account Password

.PARAMETER OUTPUTFILE1
Output CSV file to store the results

EXAMPLE DATA FOR VM

SubscriptionId = 3de1d721-xxxx-xxxx-xxxx-xxxxxxxxd3f6
SubscriptionName = Visual Studio Professional Subscription
Resource Group Name = [resource-group--name]
VM Name = [vm-name]
Guest Hostname = [guest-hostname (network name)]
OS = WindowsServer
Status = [Provisioning succeeded/VM running/etc.]
License Type = 
Location = northeurope
Availability Set = [set-name]
Instance Size = Standard_B1s
Admin Username = AdminName
VM Provisioning State = Succeeded
Creation Method = FromImage
Publisher = MicrosoftWindowsServer
VM Image Name = 2019-Datacenter
VM Image Version = latest
VM Private IP Address = xxx.xxx.xxx.xxx
VM Private IP Allocation Method = [Dynamic/Static]

.COPYRIGHT
Copyright (C) 2024 Ernst & Young Global Limited. All rights reserved. The Irish firm Ernst & Young is a member practice of Ernst & Young Global Limited.

This script is proprietary to Ernst & Young Global Limited (or one of its member firms). Unauthorized copying of this file, via any medium, is strictly prohibited. Redistribution and use in source and binary forms, with or without modification, are not permitted without prior written permission from Ernst & Young Global Limited.

.LICENSE
This script is provided "AS IS" without warranty of any kind. Ernst & Young Global Limited expressly disclaims all warranties, whether express, implied, statutory, or otherwise, with respect to this script including all implied warranties of merchantability, fitness for a particular purpose, and non-infringement. In no event shall Ernst & Young Global Limited be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this script, even if advised of the possibility of such damage.

#>

Param(
    [string] $UserName,
    [string] $Password,
    [string] $SecurePassword,
    [string] $OutputFolder = ".\",
    [string] $OutputFilePrefix = "",
    [alias("o1")]
    $OutputFile1 = "AzureVMs.csv",
    [alias("o2")]
    $OutputFile2 = "AzureDBs.csv",
    [alias("o3")]
    [string] $LogFile = "AzureQueryLog.txt",
    [switch] $Verbose
)

$ScriptDescription =       "Azure Export"
$ScriptVersion =           "5.0.10"

#region Logging
$script:OutFileSupportsNoNewLine = $false;
function InitialiseLogFile {

    if (!($script:OutputFolder)) {
        $script:OutputFolder = ".\"
    }

    if (!(Test-Path $script:OutputFolder)) {
        New-Item -ItemType Directory -Path $script:OutputFolder | Out-Null
    }

    $script:OutputFolder = Resolve-Path $script:OutputFolder | Select-Object -ExpandProperty Path

    if (!($script:OutputFolder.EndsWith('\'))) {
        $script:OutputFolder += '\'
    }

    if ($script:OutputFolder -and !($LogFile -like "*\*")) {
        $script:LogFile = Join-Path $script:OutputFolder "$($OutputFilePrefix)$LogFile"
    }

    if ($LogFile -and (Test-Path $LogFile)) {
        Remove-Item $LogFile
    }

    if ((Get-Command "Out-File").parameters["NoNewline"]) {
        $script:OutFileSupportsNoNewLine = $true;
    }

    PrefixOutputFilesWithFolder
    DecryptPassword
}

function PrefixOutputFilesWithFolder {
    
    # Check if $OutputFolder exists and is not empty
    if ($script:OutputFolder) {
        $counter = 1
        while ($true) {
            $outputFileVarName = "OutputFile$counter"
            # Check if the OutputFile variable exists
            if (Get-Variable -Name $outputFileVarName -Scope Script -ErrorAction SilentlyContinue) {
                # Get the value of the OutputFile variable
                $outputFileValue = Get-Variable -Name $outputFileVarName -ValueOnly -Scope Script
                # Check if it does not contain a backslash, and if so, prefix with OutputFolder
                if (-not $outputFileValue.Contains("\"))
                {
                    Set-Variable -Name $outputFileVarName -Value (Join-Path $script:OutputFolder "$($OutputFilePrefix)$outputFileValue") -Scope Script
                }
                $counter++
            } else {
                # Exit loop if the variable does not exist
                break
            }
        }
    }
} 

function LogText {
    param(
        [Parameter(Position=0, ValueFromRemainingArguments=$true, ValueFromPipeline=$true)]
        [Object] $Object,
        [System.ConsoleColor]$Color = [System.Console]::ForegroundColor,
        [switch]$NoNewLine = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"
    )

    if ($LogTo -ne "File") {
        # Display text on screen
        Write-Host -Object $Object -ForegroundColor $Color -NoNewline:$NoNewLine
    }
    
    if ($LogTo -ne "Console") {
        if ($LogFile) {
            if ($script:OutFileSupportsNoNewLine) {
                $Object | Out-File $LogFile -Encoding utf8 -Append -NoNewline:$NoNewLine 
            }
            else {
                $Object | Out-File $LogFile -Encoding utf8 -Append 
            }
        }
    }
}

function LogTimeAndText {
    param(
        [string] $Text,
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Blue,
        [switch]$IncludeDate = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    $output = "";
    if ($IncludeDate) {
        $output = Get-Date -Format "yyyy-MM-dd HH:mm:ss.ff"
    } else {
        $output = Get-Date -Format "HH:mm:ss.ff"
    }

    $output += " - "
    $output += $Text
    LogText $output -Color $Color -LogTo $LogTo
}

function LogError([string[]]$errorDescription){
    if ($Verbose){
        LogText ""
    }

    $output = $errorDescription -join "`r`n              "
    LogTimeAndText $output -Color Red

    Start-Sleep -s 3
}

function LogLastException() {
    $currentException = $Error[0].Exception;

    while ($currentException)
    {
        LogText -Color Red $currentException
        LogText -Color Red $currentException.Data
        LogText -Color Red $currentException.HelpLink
        LogText -Color Red $currentException.HResult
        LogText -Color Red $currentException.Message
        LogText -Color Red $currentException.Source
        LogText -Color Red $currentException.StackTrace
        LogText -Color Red $currentException.TargetSite

        $currentException = $currentException.InnerException
    }

    Start-Sleep -s 3
}

$script:MostRecentActivity = ""
function LogProgress([string]$Activity, [string]$Status, [Int32]$PercentComplete, [switch]$Completed ){
    
    if ($Activity) {
        $script:MostRecentActivity = $Activity
    } else {
        if ($script:MostRecentActivity) {
            $Activity = $script:MostRecentActivity
        } else {
            $Activity = "Unspecified"
        }
    }
    Write-Progress -activity $Activity -Status $Status -percentComplete $PercentComplete -Completed:$Completed
    LogTimeAndText $Status
}

function GetScriptPath
{
    if($PSCommandPath){
        return $PSCommandPath; }
        
    if($MyInvocation.ScriptName){
        return $MyInvocation.ScriptName }
        
    if($script:MyInvocation.MyCommand.Path){
        return $script:MyInvocation.MyCommand.Path }

    return $script:MyInvocation.MyCommand.Definition
}

function GetDotNetFrameworkVersion {
    #$release = Get-ItemPropertyValue -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release
    $regKey = Get-Item -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    $release = $regKey.GetValue("Release")
    switch ($release) {
        { $_ -ge 533320 } { $version = "4.8.1 or later ($release)"; break }
        { $_ -ge 528040 } { $version = "4.8 ($release)"; break }
        { $_ -ge 461808 } { $version = "4.7.2 ($release)"; break }
        { $_ -ge 461308 } { $version = "4.7.1 ($release)"; break }
        { $_ -ge 460798 } { $version = "4.7 ($release)"; break }
        { $_ -ge 394802 } { $version = "4.6.2 ($release)"; break }
        { $_ -ge 394254 } { $version = "4.6.1 ($release)"; break }
        { $_ -ge 393295 } { $version = "4.6 ($release)"; break }
        { $_ -ge 379893 } { $version = "4.5.2 ($release)"; break }
        { $_ -ge 378675 } { $version = "4.5.1 ($release)"; break }
        { $_ -ge 378389 } { $version = "4.5 ($release)"; break }
        default { $version = $null; break }
    }

    return $version
}

function LogEnvironmentDetails ([string[]] $OtherDetails){

    $script:ScriptPath = GetScriptPath
    $script:ScriptName = split-path $ScriptPath -leaf

    LogText " "
    LogHeaderText -FrameLine 
    LogHeaderText -LeftText " _______     __" -LeftColor Yellow
    LogHeaderText -LeftText "|  ___\ \   / /" -LeftColor Yellow
    LogHeaderText -LeftText "| |__  \ \_/ / " -LeftColor Yellow
    LogHeaderText -LeftText "|  __|  \   /  " -LeftColor Yellow
    LogHeaderText -LeftText "| |____  | |   " -LeftColor Yellow -RightText "$ScriptDescription  "
    LogHeaderText -LeftText "|______| |_|   " -LeftColor Yellow -RightText "Version $ScriptVersion  "
    LogHeaderText
    LogHeaderText -FrameLine 

    LogText " "
    LogText " $ScriptName" -Color Green 
    LogText " "

    if ($PSVersionTable.PSVersion.Major -ge 3) {
        $oSDetails = Get-CimInstance -ClassName Win32_OperatingSystem
    } else {
        $oSDetails = Get-WmiObject -Class Win32_OperatingSystem
    }
    $elevated = [bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")
    $currentThread = [System.Threading.Thread]::CurrentThread
    $dotNetFrameworkVersion = GetDotNetFrameworkVersion
    LogText -Color Gray "Computer Name:          $($env:COMPUTERNAME)"
    LogText -Color Gray "User Name:              $($env:USERNAME)@$($env:USERDNSDOMAIN)"
    LogText -Color Gray "Windows Version:        $($oSDetails.Caption)($($oSDetails.Version))"
    LogText -Color Gray "Memory kB:              $($oSDetails.TotalVisibleMemorySize.ToString("N0")) ($($oSDetails.FreePhysicalMemory.ToString("N0")) Free)"
    LogText -Color Gray "Locale:                 $($oSDetails.Locale) (Language $($oSDetails.OSLanguage))"
    LogText -Color Gray "PowerShell Host:        $($host.Version.Major)"
    LogText -Color Gray "PowerShell Version:     $($PSVersionTable.PSVersion)"
    LogText -Color Gray "PowerShell Word Size:   $($([IntPtr]::size) * 8) bit"
    LogText -Color Gray "Script Path:            $ScriptPath"
    LogText -Color Gray "Working Directory:      $PWD"
    LogText -Color Gray "CLR Version:            $($PSVersionTable.CLRVersion)"
    LogText -Color Gray ".Net Framework Version: $dotNetFrameworkVersion"
    LogText -Color Gray "Elevated:               $elevated"
    LogText -Color Gray "Current Date Time:      $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
    LogText -Color Gray "Default Date Format:    $($CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern)"
    LogText -Color Gray "Current Culture:        $((Get-Culture).EnglishName) (UI: $((Get-UICulture).EnglishName))"
    
    if (Test-Path "Variable:OutputFolder") {
        LogText -Color Gray "Output Folder:          $OutputFolder" 
    }
    if (Test-Path "Variable:OutputFile1") {
        LogText -Color Gray "Output File 1:          $OutputFile1" 
    }
    if (Test-Path "Variable:LogFile") {
        LogText -Color Gray "Log File:               $LogFile" 
    }
    if (Test-Path "Variable:ComputerName") {
        LogText -Color Gray "Target Computer Name:   $ComputerName" 
    }
    if (Test-Path "Variable:UserName") {
        LogText -Color Gray "Script User Name:       $UserName"
    }
    if (Test-Path "Variable:MicrosoftOnly") {
        LogText -Color Gray "Microsoft Only:         $MicrosoftOnly"
    }
    if (Test-Path "Variable:TargetType") {
        LogText -Color Gray "Target Type:            $TargetType"
    }
    if (Test-Path "Variable:ScriptRegime") {
        LogText -Color Gray "Script Regime:          $ScriptRegime"
    }
    if (Test-Path "Variable:RequiredData") {
        LogText -Color Gray "Required Data:          $RequiredData"
    }

    foreach ($detail in $OtherDetails){
        LogText -Color Gray $detail
    }

    LogText -Color Gray ""

}

function LogHeaderText {
    param(
        [string] $LeftText = " ",
        [System.ConsoleColor]$LeftColor = [System.ConsoleColor]::Blue,
        [string] $RightText,
        [System.ConsoleColor]$RightColor = [System.ConsoleColor]::DarkGray,
        [char] $FrameChar = "#",
        [switch] $FrameLine,
        [switch] $LeftAlignRightText,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    if ($FrameLine) {
        $strFullText = "  " + ($FrameChar.ToString() * 69)
        LogText $strFullText -Color DarkGray -LogTo $LogTo
        return
    }

    $strLeftFrame = "  $FrameChar  "
    $strLeftText = $LeftText
    $strRightText = $RightText
    $strRightFrame = "  $FrameChar"
    if ($LeftAlignRightText) {
        $strRightText = $RightText.PadRight(63 - $LeftText.Length)
    } else {
        $strLeftText = $LeftText.PadRight(63 - $RightText.Length)
    }
    

    if ($LogTo -eq "Console" -or $LogTo -eq "Both") {
        LogText $strLeftFrame -LogTo "Console" -NoNewLine -Color DarkGray
        LogText $strLeftText -LogTo "Console" -NoNewLine -Color $LeftColor
        LogText $strRightText -LogTo "Console" -NoNewLine -Color $RightColor
        LogText $strRightFrame -LogTo "Console" -Color DarkGray
    }

    if ($LogTo -eq "File" -or $LogTo -eq "Both") {
        $strFullText = $strLeftFrame + $strLeftText + $strRightText + $strRightFrame
        LogText $strFullText -LogTo "File" 
    }
}

function DecryptPassword {
    $strOneTimePassword = "%OneTimePassword%" # Replace this with the one-time password
    if ($SecurePassword) {
        $baOneTimePassword = [System.Convert]::FromBase64String($strOneTimePassword)
        $baSecurePassword = [System.Convert]::FromBase64String($SecurePassword)
        for($i=0; $i -lt $baSecurePassword.count ; $i++)
        {
            $baSecurePassword[$i] = $baSecurePassword[$i] -bxor $baOneTimePassword[$i%$baOneTimePassword.Length]
        }
        $script:Password = [System.Text.Encoding]::Unicode.GetString($baSecurePassword);
    }
}
#endregion

#region Utilities
function MaskName {
    param (
        [string]$Name
    )

    if (!($Name)) {
        return ""
    }

    $nondigitCount = 0
    $maskedName = -join ($Name.ToCharArray() | ForEach-Object {
        if ($_ -notmatch '\d') {
            $nondigitCount++
            if ($nondigitCount -le 3) { $_ } else { '*' }
        } else {
            $_
        }
    })

    return $maskedName
}
#endregion

#region Setup Output Formats
function SetupOutputFormats {
    # Standardise date/time output to ISO 8601'ish format
    $bOutputFormatsUpdated = $false
    $currentThread = [System.Threading.Thread]::CurrentThread
    $desiredShortPattern = 'yyyy-MM-dd'
    $desiredLongPattern = 'yyyy-MM-dd HH:mm:ss'

    try {
        $cultureInvariant = [CultureInfo]::InvariantCulture.Clone()
        $cultureInvariant.DateTimeFormat.ShortDatePattern = $desiredShortPattern
        $cultureInvariant.DateTimeFormat.LongDatePattern = $desiredLongPattern
        $cultureInvariant.NumberFormat.NumberGroupSeparator = ""  
        $cultureInvariant.NumberFormat.NumberDecimalSeparator = "."
        $currentThread.CurrentCulture = $cultureInvariant
        $bOutputFormatsUpdated = $true
    }
    catch {
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $currentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $currentThread.CurrentCulture.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $currentThread.CurrentCulture.NumberFormat.NumberGroupSeparator = ""  
            $currentThread.CurrentCulture.NumberDecimalSeparator = "."
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $cultureCopy = $currentThread.CurrentCulture.Clone()
            $cultureCopy.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $cultureCopy.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $cultureCopy.NumberFormat.NumberGroupSeparator = ""  
            $cultureCopy.NumberDecimalSeparator = "."
            $currentThread.CurrentCulture = $cultureCopy
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread using clone of current culture"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        LogText "Failed to update output formats"
    }
}
#endregion

#region Query User
function QueryUser([string]$Message, [string]$Prompt, [switch]$AsSecureString = $false, [string]$DefaultValue){
    $strResult = ""
    
    if ($Message) {
        LogText $Message -color Yellow
    }

    if ($DefaultValue) {
        $Prompt += " (Default [$DefaultValue])"
    }

    $Prompt += ": "
    LogText $Prompt -color Yellow -NoNewLine
    
    if ($Headless) {
        LogText " (Headless - Using Default Value)" -color Yellow
    }
    else {
        $strResult = Read-Host -AsSecureString:$AsSecureString
    }

    if(!$strResult -or ($strResult.Length -eq 0)) {
        $strResult = $DefaultValue
        if ($AsSecureString) {
            $strResult = ConvertTo-SecureString $strResult -AsPlainText -Force
        }
    }

    return $strResult
}

function Get-ConsoleCredential([String] $Message, [String] $DefaultUsername, [switch] $AsPSCredential)
{
    $strUsername = QueryUser -Message $Message -Prompt "Username" -DefaultValue $DefaultUsername
    if (!$strUsername){
        return $null
    }

    $strSecurePassword = QueryUser -Prompt "Password" -AsSecureString
    if (!$strSecurePassword){
        return $null
    }

    if ($AsPSCredential) {
        $Creds = New-Object System.Management.Automation.PSCredential ($strUsername, $strSecurePassword)
    } else {
        $Creds = New-Object PSObject

        $bstrSecurePassword = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($strSecurePassword)
        $strUnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstrSecurePassword)

        $Creds | Add-Member -MemberType NoteProperty -Name "UserName" -Value $strUsername
        $Creds | Add-Member -MemberType NoteProperty -Name "Password" -Value $strUnsecurePassword
    }

    return $Creds
}
#endregion

#region Custom Export
$ScriptExcludeFields = $null
function Export-MyCsv {
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [PSCustomObject[]] $InputObject,
        [Parameter(Mandatory = $true)]
        [string] $Path,
        [switch] $Append,
        [switch] $IncludeIndex
    )

    begin {
        if ($null -eq $ScriptExcludeFields) {
            LoadExcludeFields
        }

        $fileExcludeFields = $null
        $fileID = GetFileNameFinalPart -FilePath $Path
        if ($ScriptExcludeFields.ContainsKey($fileID)) {
            $fileExcludeFields = $ScriptExcludeFields[$fileID].Split(',') | ForEach-Object { $_.Trim() }
        }

        $index = 1
        $outputData = New-Object 'System.Collections.Generic.List[object]'
    }

    process {
        foreach ($item in $InputObject) {
            
            # Create a duplicate of the item with only the required fields
            $processedItem = New-Object PSObject 
            foreach ($prop in $item.PSObject.Properties) {
                if ($null -eq $fileExcludeFields -or !$fileExcludeFields.Contains($prop.Name)) {
                    $processedItem | Add-Member -MemberType NoteProperty -Name $prop.Name -Value $prop.Value -Force
                }
            }

            # Add index if requested
            if ($IncludeIndex) {
                $processedItem | Add-Member -MemberType NoteProperty -Name 'Index' -Value $index -Force
                $index++
            }

            # Add the processed item to the list
            $outputData.Add($processedItem)
        }
    }

    end {
        # Convert the list to an array and export to CSV
        $outputData.ToArray() | Export-Csv -Path $Path -Encoding UTF8 -NoTypeInformation -Append:$Append -Delimiter ","

        # This function logs the field names and sample values of exported data to the log file and a CSV file
        # Uncomment the following line to enable this functionality
        #LogFieldInfo -InputObject $outputData -OutputFileName $fileID
        $outputData = $null
    }
}

function LoadExcludeFields {
    $script:ScriptExcludeFields = @{}

    if (!($ScriptDescription)) {
        return
    }

    # Import the CSV
    try {
        $csvData = Import-Csv -Path ".\ExcludeFields.csv" -ErrorAction SilentlyContinue
    } catch {
    }

    foreach ($row in $csvData | Where-Object { $_.Script -eq $ScriptDescription }) {
        $ScriptExcludeFields[$row.OutputFile] = $row.ExcludeFields
    }
}

function GetFileNameFinalPart {
    param (
        [string]$FilePath
    )

    # Return the last part of the filename i.e. Apps for the following values
    # c:\temp\20240102_101212_Apps.csv
    # c:\temp\Apps.csv

    # Get the filename without the extension
    $fileNameWithoutExtension = [System.IO.Path]::GetFileNameWithoutExtension($FilePath)

    # Split the filename by underscore or backslash, and take the last part
    $lastPart = ($fileNameWithoutExtension -split '[\\_]')[-1]

    return $lastPart
}

# Support function. Not currently called. The function is used for custom testing to aid the local development team where necessary
function LogFieldInfo {
    param(
        [PSCustomObject[]] $InputObject,
        [string] $OutputFileName
    )
    
    # This function logs the field names and sample values of exported data to the log file and a CSV file
    # It is not enabled by default
    if (!($InputObject) -or $InputObject.Count -eq 0) {
        return
    }

    # Creating a new array of fields and sample values
    $lstFields = @()

    $recordIndex = 1
    foreach ($record in $InputObject) {
        $fieldNames = $record.PSObject.Properties.Name
        $fieldIndex = 1

        # Iterate through each property
        foreach ($fieldName in $fieldNames) {
            # Creating a new object for each property
            $field = [PSCustomObject][ordered]@{
                ScriptFileName = $ScriptName
                ScriptDescription = $ScriptDescription
                OutputFileName = $OutputFileName
                FieldName = $fieldName
                SampleValue = $record.$fieldName
                FieldIndex = $fieldIndex++
                RecordIndex = $recordIndex
            }

            # Add new object to the array
            $lstFields += $field
        }
    
        $recordIndex++
        if ($recordIndex -gt 3) {
            break
        }
    }

    # Save the field info to log file and csv file
    $csvLines = $lstFields | ConvertTo-Csv -NoTypeInformation
    $csvString = $csvLines -join "`n"
    LogText $csvString -LogTo File
    $lstFields | export-csv -Path ".\FieldInfo.csv" -NoTypeInformation -Append -Delimiter ","
}
#endregion

#region Ensure Module
function EnsureModuleLoaded {
    param (
        [Parameter(Mandatory=$true)]
        [string] $ModuleName,
        [Version] $MinimumVersion = '1.0.0'
    )

    try {
        # Check if the module is already loaded or available
        $module = Get-Module -Name $ModuleName -ListAvailable | Sort-Object Version -Descending | Select-Object -First 1
        $strDefaultInstallAction = "Y"
        if ($Headless) {
            $strDefaultInstallAction = "N"
        }

        if ($module) {
            if ($module.Version -lt $MinimumVersion) {
                $userResponse = QueryUser -Prompt "$ModuleName version $($module.Version) is older than the required minimum version $MinimumVersion. Do you want to upgrade it now? (Y/N)" -DefaultValue $strDefaultInstallAction
                if ($userResponse -eq 'Y' -or $userResponse -eq 'y') {
                    try {
                        
                        $updateModuleParams = @{
                            Name = $ModuleName
                            Scope = "CurrentUser"
                            Force = $true
                            Confirm = $false 
                            ErrorAction = "Stop"
                        };

                        LogText "Calling 'Update-Module -Name $ModuleName -Force'"
                        LogText "The update can take 5-10 minutes without any visual feedback. Please be patient." -Color Gray
                        Update-Module @updateModuleParams
                        Import-Module -Name $ModuleName
                        LogText "Module $ModuleName upgraded and imported"
                        return $true
                    } catch {
                        LogError "Failed to upgrade $ModuleName. Error: $_"
                        LogText "If this problem persists, you can try calling 'Uninstall-Module -Name $ModuleName' and rerunning this script" -Color Yellow
                        return $false
                    }
                } else {
                    LogText "Module $ModuleName was not upgraded" -Color Red
                    LogText "To upgrade the required module, follow one of these methods:"
                    LogText ""
                    LogText "[Online Devices]"
                    LogText "1. Open a PowerShell console and run:"
                    LogText "   Update-Module -Name $ModuleName -Force"
                    LogText ""
                    LogText "[Offline Devices]"
                    LogText "1. On an internet-connected PC, open a PowerShell console and run:"
                    LogText "   Save-Module -Name $ModuleName -Path C:\Modules"
                    LogText ""
                    LogText "2. Transfer the contents from 'C:\Modules' on the online PC to:"
                    LogText "   C:\Program Files\WindowsPowerShell\Modules on the offline device."
                    LogText ""
                    LogText "[Alternative]"
                    LogText "1. Download and install directly from:"
                    LogText "   https://www.powershellgallery.com/packages/$ModuleName"
                    LogText ""
                    LogText "Note: Upgrading is essential for optimal functionality."
                    return $false
                }
            } elseif (-not (Get-Module -Name $ModuleName)) {
                LogText "Importing Module $ModuleName"
                Import-Module -Name $ModuleName
                LogText "Module $ModuleName imported"
                return $true
            } else {
                LogText "Module $ModuleName already imported"
                return $true
            }
            return
        }

        # If the module is not available, ask the user if they want to install it
        $userResponse = QueryUser -Prompt "A required module ($ModuleName) is not currently installed. Do you want to install it now? (Y/N)" -DefaultValue $strDefaultInstallAction
        if ($userResponse -eq 'Y' -or $userResponse -eq 'y') {
            try {
                $installModuleParams = @{
                    Name = $ModuleName
                    Scope = "CurrentUser"
                    MinimumVersion = $MinimumVersion
                    Force = $true 
                    Confirm = $false 
                    AllowClobber = $true
                    ErrorAction = "Stop"
                };

                if ($SkipPublisherCheck) {
                    $installModuleParams.Add("SkipPublisherCheck", $true)
                }

                LogText "Calling 'Install-Module -Name $ModuleName -Force'"
                LogText "The installation can take 5-10 minutes without any visual feedback. Please be patient." -Color Gray
                Install-Module @installModuleParams
                LogText "Importing Module $ModuleName"
                Import-Module -Name $ModuleName
                LogText "Module $ModuleName has been installed"
                return $true
            } catch {
                LogError "Failed to install $ModuleName. Error: $_"
                return $false
            }
        } else {
            LogText "Module $ModuleName was not installed" -Color Red
            LogText "To install the required module, follow one of these methods:"
            LogText ""
            LogText "[Online Devices]"
            LogText "1. Open a PowerShell console and run:"
            LogText "   Install-Module -Name $ModuleName -Force"
            LogText ""
            LogText "[Offline Devices]"
            LogText "1. On an internet-connected PC, open a PowerShell console and run:"
            LogText "   Save-Module -Name $ModuleName -Path C:\Modules"
            LogText ""
            LogText "2. Transfer the contents from 'C:\Modules' on the online PC to:"
            LogText "   C:\Program Files\WindowsPowerShell\Modules on the offline device."
            LogText ""
            LogText "[Alternative]"
            LogText "1. Download and install directly from:"
            LogText "   https://www.powershellgallery.com/packages/$ModuleName"
            LogText ""
            LogText "Note: Installation is essential for this script to work"
            
            return $false
        }
    } catch {
        LogLastException
    }

    return $false
}
#endregion

function Get-AzVMAndDBs {

    try {
        Disconnect-AzAccount -ErrorAction SilentlyContinue | Out-Null
    }
    catch {
    }

    ##
    ## Get Az module VM details (successor of AzureRM(ARM))
    ##
    try {
					 
        ## Process the user credentials passed through terminal
        if ($UserName -and $Password) {
            $securePassword = ConvertTo-SecureString $Password -AsPlainText -Force

            ## Convert to Azure account aceptable        
            $cred = New-Object -TypeName System.Management.Automation.PSCredential ($UserName, $securePassword)
            
            ## Login the account user has entered
            LogTimeAndText "Logging in to Azure (User: $UserName)"
            $AzureAccount = Connect-AzAccount -Credential $cred -ErrorAction SilentlyContinue -ErrorVariable errAddAccount -WarningAction SilentlyContinue
            if ($errAddAccount.count -ne 0) {
                LogError "An error occured while trying to login into the Azure account. Please check your credentials or try again later."
                return
            }
        }
        else {
            LogTimeAndText "Logging in to Azure"
            $AzureAccount = Connect-AzAccount -ErrorAction SilentlyContinue -ErrorVariable errAddAccount -WarningAction SilentlyContinue
            
            if ($errAddAccount.count -ne 0) {
                LogError "An error occured while trying to login into the Azure account. Please check your credentials or try again later."
                return
            }
        }

        ## Get the Tenant List
        ## LogTimeAndText "Getting Azure Tenant Details"
        ## $tenants = @(Get-AzTenant -ErrorAction Stop -WarningAction SilentlyContinue)
        ## LogText "$($tenants.Count) tenants(s) found"

        ## Get the Subscription List
        LogTimeAndText "Getting Azure Subscription Details"
        $subscriptions = @(Get-AzSubscription -ErrorVariable AzSubscriptionError -ErrorAction Stop -WarningAction SilentlyContinue)

        LogText "$($subscriptions.Count) subscription(s) found"

        if ($Verbose) {  
            LogText ($subscriptions | Format-Table -property Name, ID -autosize | Out-String)
        }
        
        ## Arrays for storing VM and DB details
        $allVMs = New-Object System.Collections.Generic.List[object]
        $allSQLDatabases = New-Object System.Collections.Generic.List[object]

        ## Loop through each subscription
        foreach ($subscription in $subscriptions) {

            ## Get Subscription basic details
            $subscriptionId = $subscription.Id
            $subscriptionName = $subscription.Name

            ## Check if user has access to the subscription
            try {
                ## Set Default Subscription to get all its details
                LogTimeAndText "Switching to subscription $subscriptionName ($subscriptionId)"
                $selectedSub = Set-AzContext -SubscriptionId $subscriptionId -WarningAction SilentlyContinue
            }
            catch {
                LogError "The current user does not has access to Azure subscription - $subscriptionName ($subscriptionId)." -color Red
                Continue
            }

            ## Throws an exception if session has expired
            try {

                LogText "Querying VMs. " -NoNewLine

                $vms = @(Get-AzVM -ErrorVariable  vmListError -ErrorAction SilentlyContinue)

                LogText "$($vms.count) found."
            }            
            catch {
                LogError "An error occurred querying VMs. Credentials may have expired." -color Red
                Continue
            }

            foreach ($vm in $vms) { 

                LogText "Querying VM $($vm.Name)"

                ## Parse VM Network Details
                $vmNIId = ($vm.NetworkProfile.NetworkInterfaces.ID -split "/")[-1]
                $vmNI = Get-AzNetworkInterface -Name $vmNIId -ResourceGroupName $vm.ResourceGroupName

                ## Get Guest Host Name of the VM (note $vm.OSProfile.ComputerName is similar to VM name)
                $vms = Get-AzVM -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName -EA SilentlyContinue -Status

                ## Read all statuses of the VM
                $vmStatusDetail = ""
                foreach ($VMStatus in $vms.Statuses)
                { 
                    $vmStatusDetail += "$($VMStatus.DisplayStatus);"
                }

                ## Create a custom object to store VM details
                $vmDetails = [PSCustomObject][ordered]@{
                    TenantId = $subscription.TenantId
                    SubscriptionId = $subscriptionId
                    SubscriptionName = $subscriptionName
                    ResourceGroupName = $vm.ResourceGroupName
                    VMName = $vm.Name
                    GuestHostname = $vms.ComputerName
                    OS = $vm.StorageProfile.ImageReference.Offer
                    Status = $vmStatusDetail
                    LicenseType = $vm.LicenseType
                    Location = $vm.Location
                    AvailabilitySet = $vm.AvailabilitySetReference
                    InstanceSize = $vm.HardwareProfile.vmSize
                    AdminUsername = MaskName -Name $vm.OSProfile.AdminUsername
                    VMProvisioningState = $vm.ProvisioningState
                    CreationMethod = $vm.StorageProfile.osDisk.createOption
                    Publisher = $vm.StorageProfile.imageReference.publisher
                    VMImageName = $vm.StorageProfile.imageReference.sku
                    VMImageVersion = $vm.StorageProfile.imageReference.version
                    VMPrivateIPAddress = $vmNI.IpConfigurations.PrivateIpAddress
                    VMPrivateIPAllocationMethod = $vmNI.IpConfigurations.PrivateIpAllocationMethod
                }

                $allVMs.Add($vmDetails)
            }

            try {
                LogText "Querying SQL Servers. " -NoNewLine

                $sqlServers = @(Get-AzResourceGroup -ErrorVariable sqlServerError -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | 
                    Get-AzSqlServer -ErrorVariable sqlServerError -ErrorAction SilentlyContinue -WarningAction SilentlyContinue)

                LogText "$($sqlServers.count) found."

                foreach ($sqlServer in $sqlServers) {
                    
                    LogText "Querying SQL Databases on SQL Server $($sqlServer.ServerName). " -NoNewLine

                    $sqlDatabases = Get-AzSqlDatabase -ServerName $sqlServer.ServerName -ResourceGroupName $sqlServer.ResourceGroupName -ErrorAction SilentlyContinue -WarningAction SilentlyContinue

                    LogText "$($sqlDatabases.count) found."

                    foreach ($sqlDatabase in $sqlDatabases) {
                        $dbDetails = [PSCustomObject][ordered]@{
                            TenantId = $subscription.TenantId
                            SubscriptionId = $subscription.Id
                            SubscriptionName = $subscription.Name
                            ResourceGroupName = $sqlDatabase.ResourceGroupName
                            ServerName = $sqlDatabase.ServerName
                            DatabaseName = MaskName -Name $sqlDatabase.DatabaseName
                            Edition = $sqlDatabase.Edition
                            Status = $sqlDatabase.Status
                            CreationDate = $sqlDatabase.CreationDate
                            ElasticPoolName = $sqlDatabase.ElasticPoolName
                            ServiceObjective = $sqlDatabase.RequestedServiceObjectiveName
                            LicenseType = $sqlDatabase.LicenseType
                        }
                        
                        $allSQLDatabases.Add($dbDetails)
                    }
                }
            }            
            catch {
                LogError "An error occurred querying SQL databases. Credentials may have expired." -color Red
                Continue
            }         
        }       
                        
        $allVMs | Export-MyCsv -Path $OutputFile1 -IncludeIndex
        $allSQLDatabases | Export-MyCsv -Path $OutputFile2 -IncludeIndex
        
        # Clear the logged in user session.
        Disconnect-AzAccount | Out-Null
         
        LogTimeAndText "Azure Export Completed"          
                        
    } 
    catch {
        LogLastException

        ## An error occured. Clear the logged in user session.
        Disconnect-AzAccount | Out-Null
    }
}


function Get-AzureVMList {    
    
    try {
        InitialiseLogFile
        SetupOutputFormats
        LogEnvironmentDetails

        if (!(EnsureModuleLoaded -ModuleName "Az.Sql" -MinimumVersion "4.14.0") -or
            !(EnsureModuleLoaded -ModuleName "Az.Network" -MinimumVersion "7.3.0") -or
            !(EnsureModuleLoaded -ModuleName "Az.Compute" -MinimumVersion "7.1.1") -or
            !(EnsureModuleLoaded -ModuleName "Az.Resources" -MinimumVersion "6.16.1") -or
            !(EnsureModuleLoaded -ModuleName "Az.Accounts" -MinimumVersion "2.15.0")) { 
            return
        }

        Get-AzVMAndDBs

    } catch {
        LogLastException
    }
    
}

Get-AzureVMList