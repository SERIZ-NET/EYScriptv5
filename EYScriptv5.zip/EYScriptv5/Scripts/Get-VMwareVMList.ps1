 ##########################################################################
 # 
 # Get-VMwareVMList
 #
 ##########################################################################

 <#
.SYNOPSIS
Retrieves physical host and virtual machine data from a VMware vSphere or vCenter server

.DESCRIPTION
The Get-VMwareVMList script queries a single vSphere or vCenter server and produces a CSV file
including virtual machine and physical host details. The file (VMwareData.csv) contains one 
record per virtual machine. Data collected includes
    VM Name
    VM CPU, Memory & Network details
    Physical Host Name
    Physical Host CPU, Memory, Network, Cluster & vMotion details

If a vCenter server is queried, details for all VMs in the farm are retrieved.

.PARAMETER Server 
Host name of vSphere or vCenter server to scan
.PARAMETER Username
VMware Username (Required)
e.g. root (for vSphere server i.e. local account)
     jon.mulligan (for vCenter server i.e. Windows domain account)

.PARAMETER Password
VMware Password (Required)

.EXAMPLE
Get all guest & host info from from the farm managed by the vSphere server 'Reliant'. 
Get-VMwareVMList -VMserver Reliant

.COPYRIGHT
Copyright (C) 2024 Ernst & Young Global Limited. All rights reserved. The Irish firm Ernst & Young is a member practice of Ernst & Young Global Limited.

This script is proprietary to Ernst & Young Global Limited (or one of its member firms). Unauthorized copying of this file, via any medium, is strictly prohibited. Redistribution and use in source and binary forms, with or without modification, are not permitted without prior written permission from Ernst & Young Global Limited.

.LICENSE
This script is provided "AS IS" without warranty of any kind. Ernst & Young Global Limited expressly disclaims all warranties, whether express, implied, statutory, or otherwise, with respect to this script including all implied warranties of merchantability, fitness for a particular purpose, and non-infringement. In no event shall Ernst & Young Global Limited be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this script, even if advised of the possibility of such damage.

#>

Param(
    [string] $OutputFolder = ".\",
    [string] $OutputFilePrefix = "",
    [alias("o1")]
    [string] $OutputFile1 = "VMwareVMs.csv",
    [alias("o2")]
    [string] $OutputFile2 = "VMwareHosts.csv",
    [alias("o3")]
    [string] $OutputFile3 = "VMwareClusters.csv",
    [alias("o4")]
    [string] $OutputFile4 = "VMwareVMDRSRules.csv",
    [alias("o5")]
    [string] $OutputFile5 = "VMwareVMDRSGroups.csv",
    [alias("o6")]
    [string] $OutputFile6 = "VMwareVMotionData.csv",
    [alias("o7")]
    [string] $LogFile = "VMwareQueryLog.txt",
    [string] $Username,
    [string] $Password,
    [string] $SecurePassword,
    [alias("server")]
    $VMserver,
    $VMServerPort = 443,
    $VMServerProtocol = "",
    $SkipProxy = $true,
    [ValidateSet("VMData","VMDataPlusDRS","VMMigrationHistory","AllData")]
    $RequiredData = "VMDataPlusDRS",
    [alias("VMotionHistoryDaysValue")]
    $VMotionHistoryDays = 14,
    [ValidateSet("All","Servers","Clients")] 
    [string] $TargetType = "All",
    [switch] $MicrosoftOnly,       # Only collect inventory and configuration information for Microsoft products
    [switch] $SkipPublisherCheck,
    [switch] $Verbose,
    [switch] $Headless)


$ScriptDescription =       "VMware Export"
$ScriptVersion =           "5.0.10"

#region Logging
$script:OutFileSupportsNoNewLine = $false;
function InitialiseLogFile {

    if (!($script:OutputFolder)) {
        $script:OutputFolder = ".\"
    }

    if (!(Test-Path $script:OutputFolder)) {
        New-Item -ItemType Directory -Path $script:OutputFolder | Out-Null
    }

    $script:OutputFolder = Resolve-Path $script:OutputFolder | Select-Object -ExpandProperty Path

    if (!($script:OutputFolder.EndsWith('\'))) {
        $script:OutputFolder += '\'
    }

    if ($script:OutputFolder -and !($LogFile -like "*\*")) {
        $script:LogFile = Join-Path $script:OutputFolder "$($OutputFilePrefix)$LogFile"
    }

    if ($LogFile -and (Test-Path $LogFile)) {
        Remove-Item $LogFile
    }

    if ((Get-Command "Out-File").parameters["NoNewline"]) {
        $script:OutFileSupportsNoNewLine = $true;
    }

    PrefixOutputFilesWithFolder
    DecryptPassword
}

function PrefixOutputFilesWithFolder {
    
    # Check if $OutputFolder exists and is not empty
    if ($script:OutputFolder) {
        $counter = 1
        while ($true) {
            $outputFileVarName = "OutputFile$counter"
            # Check if the OutputFile variable exists
            if (Get-Variable -Name $outputFileVarName -Scope Script -ErrorAction SilentlyContinue) {
                # Get the value of the OutputFile variable
                $outputFileValue = Get-Variable -Name $outputFileVarName -ValueOnly -Scope Script
                # Check if it does not contain a backslash, and if so, prefix with OutputFolder
                if (-not $outputFileValue.Contains("\"))
                {
                    Set-Variable -Name $outputFileVarName -Value (Join-Path $script:OutputFolder "$($OutputFilePrefix)$outputFileValue") -Scope Script
                }
                $counter++
            } else {
                # Exit loop if the variable does not exist
                break
            }
        }
    }
} 

function LogText {
    param(
        [Parameter(Position=0, ValueFromRemainingArguments=$true, ValueFromPipeline=$true)]
        [Object] $Object,
        [System.ConsoleColor]$Color = [System.Console]::ForegroundColor,
        [switch]$NoNewLine = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"
    )

    if ($LogTo -ne "File") {
        # Display text on screen
        Write-Host -Object $Object -ForegroundColor $Color -NoNewline:$NoNewLine
    }
    
    if ($LogTo -ne "Console") {
        if ($LogFile) {
            if ($script:OutFileSupportsNoNewLine) {
                $Object | Out-File $LogFile -Encoding utf8 -Append -NoNewline:$NoNewLine 
            }
            else {
                $Object | Out-File $LogFile -Encoding utf8 -Append 
            }
        }
    }
}

function LogTimeAndText {
    param(
        [string] $Text,
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Blue,
        [switch]$IncludeDate = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    $output = "";
    if ($IncludeDate) {
        $output = Get-Date -Format "yyyy-MM-dd HH:mm:ss.ff"
    } else {
        $output = Get-Date -Format "HH:mm:ss.ff"
    }

    $output += " - "
    $output += $Text
    LogText $output -Color $Color -LogTo $LogTo
}

function LogError([string[]]$errorDescription){
    if ($Verbose){
        LogText ""
    }

    $output = $errorDescription -join "`r`n              "
    LogTimeAndText $output -Color Red

    Start-Sleep -s 3
}

function LogLastException() {
    $currentException = $Error[0].Exception;

    while ($currentException)
    {
        LogText -Color Red $currentException
        LogText -Color Red $currentException.Data
        LogText -Color Red $currentException.HelpLink
        LogText -Color Red $currentException.HResult
        LogText -Color Red $currentException.Message
        LogText -Color Red $currentException.Source
        LogText -Color Red $currentException.StackTrace
        LogText -Color Red $currentException.TargetSite

        $currentException = $currentException.InnerException
    }

    Start-Sleep -s 3
}

$script:MostRecentActivity = ""
function LogProgress([string]$Activity, [string]$Status, [Int32]$PercentComplete, [switch]$Completed ){
    
    if ($Activity) {
        $script:MostRecentActivity = $Activity
    } else {
        if ($script:MostRecentActivity) {
            $Activity = $script:MostRecentActivity
        } else {
            $Activity = "Unspecified"
        }
    }
    Write-Progress -activity $Activity -Status $Status -percentComplete $PercentComplete -Completed:$Completed
    LogTimeAndText $Status
}

function GetScriptPath
{
    if($PSCommandPath){
        return $PSCommandPath; }
        
    if($MyInvocation.ScriptName){
        return $MyInvocation.ScriptName }
        
    if($script:MyInvocation.MyCommand.Path){
        return $script:MyInvocation.MyCommand.Path }

    return $script:MyInvocation.MyCommand.Definition
}

function GetDotNetFrameworkVersion {
    #$release = Get-ItemPropertyValue -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release
    $regKey = Get-Item -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    $release = $regKey.GetValue("Release")
    switch ($release) {
        { $_ -ge 533320 } { $version = "4.8.1 or later ($release)"; break }
        { $_ -ge 528040 } { $version = "4.8 ($release)"; break }
        { $_ -ge 461808 } { $version = "4.7.2 ($release)"; break }
        { $_ -ge 461308 } { $version = "4.7.1 ($release)"; break }
        { $_ -ge 460798 } { $version = "4.7 ($release)"; break }
        { $_ -ge 394802 } { $version = "4.6.2 ($release)"; break }
        { $_ -ge 394254 } { $version = "4.6.1 ($release)"; break }
        { $_ -ge 393295 } { $version = "4.6 ($release)"; break }
        { $_ -ge 379893 } { $version = "4.5.2 ($release)"; break }
        { $_ -ge 378675 } { $version = "4.5.1 ($release)"; break }
        { $_ -ge 378389 } { $version = "4.5 ($release)"; break }
        default { $version = $null; break }
    }

    return $version
}

function LogEnvironmentDetails ([string[]] $OtherDetails){

    $script:ScriptPath = GetScriptPath
    $script:ScriptName = split-path $ScriptPath -leaf

    LogText " "
    LogHeaderText -FrameLine 
    LogHeaderText -LeftText " _______     __" -LeftColor Yellow
    LogHeaderText -LeftText "|  ___\ \   / /" -LeftColor Yellow
    LogHeaderText -LeftText "| |__  \ \_/ / " -LeftColor Yellow
    LogHeaderText -LeftText "|  __|  \   /  " -LeftColor Yellow
    LogHeaderText -LeftText "| |____  | |   " -LeftColor Yellow -RightText "$ScriptDescription  "
    LogHeaderText -LeftText "|______| |_|   " -LeftColor Yellow -RightText "Version $ScriptVersion  "
    LogHeaderText
    LogHeaderText -FrameLine 

    LogText " "
    LogText " $ScriptName" -Color Green 
    LogText " "

    if ($PSVersionTable.PSVersion.Major -ge 3) {
        $oSDetails = Get-CimInstance -ClassName Win32_OperatingSystem
    } else {
        $oSDetails = Get-WmiObject -Class Win32_OperatingSystem
    }
    $elevated = [bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")
    $currentThread = [System.Threading.Thread]::CurrentThread
    $dotNetFrameworkVersion = GetDotNetFrameworkVersion
    LogText -Color Gray "Computer Name:          $($env:COMPUTERNAME)"
    LogText -Color Gray "User Name:              $($env:USERNAME)@$($env:USERDNSDOMAIN)"
    LogText -Color Gray "Windows Version:        $($oSDetails.Caption)($($oSDetails.Version))"
    LogText -Color Gray "Memory kB:              $($oSDetails.TotalVisibleMemorySize.ToString("N0")) ($($oSDetails.FreePhysicalMemory.ToString("N0")) Free)"
    LogText -Color Gray "Locale:                 $($oSDetails.Locale) (Language $($oSDetails.OSLanguage))"
    LogText -Color Gray "PowerShell Host:        $($host.Version.Major)"
    LogText -Color Gray "PowerShell Version:     $($PSVersionTable.PSVersion)"
    LogText -Color Gray "PowerShell Word Size:   $($([IntPtr]::size) * 8) bit"
    LogText -Color Gray "Script Path:            $ScriptPath"
    LogText -Color Gray "Working Directory:      $PWD"
    LogText -Color Gray "CLR Version:            $($PSVersionTable.CLRVersion)"
    LogText -Color Gray ".Net Framework Version: $dotNetFrameworkVersion"
    LogText -Color Gray "Elevated:               $elevated"
    LogText -Color Gray "Current Date Time:      $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
    LogText -Color Gray "Default Date Format:    $($CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern)"
    LogText -Color Gray "Current Culture:        $((Get-Culture).EnglishName) (UI: $((Get-UICulture).EnglishName))"
    
    if (Test-Path "Variable:OutputFolder") {
        LogText -Color Gray "Output Folder:          $OutputFolder" 
    }
    if (Test-Path "Variable:OutputFile1") {
        LogText -Color Gray "Output File 1:          $OutputFile1" 
    }
    if (Test-Path "Variable:LogFile") {
        LogText -Color Gray "Log File:               $LogFile" 
    }
    if (Test-Path "Variable:ComputerName") {
        LogText -Color Gray "Target Computer Name:   $ComputerName" 
    }
    if (Test-Path "Variable:UserName") {
        LogText -Color Gray "Script User Name:       $UserName"
    }
    if (Test-Path "Variable:MicrosoftOnly") {
        LogText -Color Gray "Microsoft Only:         $MicrosoftOnly"
    }
    if (Test-Path "Variable:TargetType") {
        LogText -Color Gray "Target Type:            $TargetType"
    }
    if (Test-Path "Variable:ScriptRegime") {
        LogText -Color Gray "Script Regime:          $ScriptRegime"
    }
    if (Test-Path "Variable:RequiredData") {
        LogText -Color Gray "Required Data:          $RequiredData"
    }

    foreach ($detail in $OtherDetails){
        LogText -Color Gray $detail
    }

    LogText -Color Gray ""

}

function LogHeaderText {
    param(
        [string] $LeftText = " ",
        [System.ConsoleColor]$LeftColor = [System.ConsoleColor]::Blue,
        [string] $RightText,
        [System.ConsoleColor]$RightColor = [System.ConsoleColor]::DarkGray,
        [char] $FrameChar = "#",
        [switch] $FrameLine,
        [switch] $LeftAlignRightText,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    if ($FrameLine) {
        $strFullText = "  " + ($FrameChar.ToString() * 69)
        LogText $strFullText -Color DarkGray -LogTo $LogTo
        return
    }

    $strLeftFrame = "  $FrameChar  "
    $strLeftText = $LeftText
    $strRightText = $RightText
    $strRightFrame = "  $FrameChar"
    if ($LeftAlignRightText) {
        $strRightText = $RightText.PadRight(63 - $LeftText.Length)
    } else {
        $strLeftText = $LeftText.PadRight(63 - $RightText.Length)
    }
    

    if ($LogTo -eq "Console" -or $LogTo -eq "Both") {
        LogText $strLeftFrame -LogTo "Console" -NoNewLine -Color DarkGray
        LogText $strLeftText -LogTo "Console" -NoNewLine -Color $LeftColor
        LogText $strRightText -LogTo "Console" -NoNewLine -Color $RightColor
        LogText $strRightFrame -LogTo "Console" -Color DarkGray
    }

    if ($LogTo -eq "File" -or $LogTo -eq "Both") {
        $strFullText = $strLeftFrame + $strLeftText + $strRightText + $strRightFrame
        LogText $strFullText -LogTo "File" 
    }
}

function DecryptPassword {
    $strOneTimePassword = "%OneTimePassword%" # Replace this with the one-time password
    if ($SecurePassword) {
        $baOneTimePassword = [System.Convert]::FromBase64String($strOneTimePassword)
        $baSecurePassword = [System.Convert]::FromBase64String($SecurePassword)
        for($i=0; $i -lt $baSecurePassword.count ; $i++)
        {
            $baSecurePassword[$i] = $baSecurePassword[$i] -bxor $baOneTimePassword[$i%$baOneTimePassword.Length]
        }
        $script:Password = [System.Text.Encoding]::Unicode.GetString($baSecurePassword);
    }
}
#endregion

#region Setup Output Formats
function SetupOutputFormats {
    # Standardise date/time output to ISO 8601'ish format
    $bOutputFormatsUpdated = $false
    $currentThread = [System.Threading.Thread]::CurrentThread
    $desiredShortPattern = 'yyyy-MM-dd'
    $desiredLongPattern = 'yyyy-MM-dd HH:mm:ss'

    try {
        $cultureInvariant = [CultureInfo]::InvariantCulture.Clone()
        $cultureInvariant.DateTimeFormat.ShortDatePattern = $desiredShortPattern
        $cultureInvariant.DateTimeFormat.LongDatePattern = $desiredLongPattern
        $cultureInvariant.NumberFormat.NumberGroupSeparator = ""  
        $cultureInvariant.NumberFormat.NumberDecimalSeparator = "."
        $currentThread.CurrentCulture = $cultureInvariant
        $bOutputFormatsUpdated = $true
    }
    catch {
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $currentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $currentThread.CurrentCulture.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $currentThread.CurrentCulture.NumberFormat.NumberGroupSeparator = ""  
            $currentThread.CurrentCulture.NumberDecimalSeparator = "."
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $cultureCopy = $currentThread.CurrentCulture.Clone()
            $cultureCopy.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $cultureCopy.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $cultureCopy.NumberFormat.NumberGroupSeparator = ""  
            $cultureCopy.NumberDecimalSeparator = "."
            $currentThread.CurrentCulture = $cultureCopy
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread using clone of current culture"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        LogText "Failed to update output formats"
    }
}
#endregion

#region Query User
function QueryUser([string]$Message, [string]$Prompt, [switch]$AsSecureString = $false, [string]$DefaultValue){
    $strResult = ""
    
    if ($Message) {
        LogText $Message -color Yellow
    }

    if ($DefaultValue) {
        $Prompt += " (Default [$DefaultValue])"
    }

    $Prompt += ": "
    LogText $Prompt -color Yellow -NoNewLine
    
    if ($Headless) {
        LogText " (Headless - Using Default Value)" -color Yellow
    }
    else {
        $strResult = Read-Host -AsSecureString:$AsSecureString
    }

    if(!$strResult -or ($strResult.Length -eq 0)) {
        $strResult = $DefaultValue
        if ($AsSecureString) {
            $strResult = ConvertTo-SecureString $strResult -AsPlainText -Force
        }
    }

    return $strResult
}

function Get-ConsoleCredential([String] $Message, [String] $DefaultUsername, [switch] $AsPSCredential)
{
    $strUsername = QueryUser -Message $Message -Prompt "Username" -DefaultValue $DefaultUsername
    if (!$strUsername){
        return $null
    }

    $strSecurePassword = QueryUser -Prompt "Password" -AsSecureString
    if (!$strSecurePassword){
        return $null
    }

    if ($AsPSCredential) {
        $Creds = New-Object System.Management.Automation.PSCredential ($strUsername, $strSecurePassword)
    } else {
        $Creds = New-Object PSObject

        $bstrSecurePassword = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($strSecurePassword)
        $strUnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstrSecurePassword)

        $Creds | Add-Member -MemberType NoteProperty -Name "UserName" -Value $strUsername
        $Creds | Add-Member -MemberType NoteProperty -Name "Password" -Value $strUnsecurePassword
    }

    return $Creds
}
#endregion

#region Test Connection
$script:ConnectionDetails = [PSCustomObject][ordered]@{
    TargetName = ""
    ComputerName = ""
    ComputerDomain = ""
    IPAddress0 = ""
    NameResolution = [Nullable[bool]]$null
    Ping = [Nullable[bool]]$null
    PortSSH = [Nullable[bool]]$null
    PortHTTP = [Nullable[bool]]$null
    PortWMI = [Nullable[bool]]$null
    PortSMB1 = [Nullable[bool]]$null
    PortHTTPS = [Nullable[bool]]$null
    PortSMB2 = [Nullable[bool]]$null
    PortSQL = [Nullable[bool]]$null
    PortRDP = [Nullable[bool]]$null
    PortWinRM = [Nullable[bool]]$null
    PortWinRMS = [Nullable[bool]]$null 
    OtherPorts = @{}
    Error = ""
    ErrorDetails = ""
    CimConnectionType = $null
    CimSession = $null
    PSSession = $null
    HKLM = $null
    HKU = $null
}

function TestConnectivity {
    param(
        [string] $Target,
        [int[]] $Ports = @(22, 80, 135, 139, 443, 445, 1433, 3389, 5985, 5986)
    )

    $ConnectionDetails.TargetName = $Target
    $ConnectionDetails.ComputerName = $Target

    # Test name resolution
    LogText "Name Resolution: " -NoNewLine -Color Gray
    $ConnectionDetails.NameResolution = $false;
    try {
        $nameResolutionResult = [System.Net.Dns]::GetHostAddresses($Target)
        if ($nameResolutionResult.Count -gt 0) {
            $ConnectionDetails.IPAddress0 = $nameResolutionResult[0].IPAddressToString
            $ConnectionDetails.NameResolution = $true;
        }
    } catch {}
    
    if ($ConnectionDetails.NameResolution) {
        LogText "Succeeded" -Color Green
    } else {
        LogText "Failed" -Color Red
        return;
    }
    
    # Test Ping
    LogText "Ping: " -NoNewLine -Color Gray
    $ConnectionDetails.Ping = $false;
    try {
        $pingResult = Test-Connection -ComputerName $Target -Count 1 -ErrorAction SilentlyContinue
        if ($pingResult.StatusCode -eq 0) {
            $ConnectionDetails.Ping = $true
        } else {
            $ConnectionDetails.Ping = $false
        }
    } catch {}
    
    if ($ConnectionDetails.Ping) {
        LogText "Succeeded" -Color Green
    } else {
        LogText "Failed" -Color Red
    }
    
    # Test Ports
    LogText "Port Scan: " -NoNewLine -Color Gray

    $sockets = @()
    $asyncResults = @()

    # Start connections
    foreach ($port in $Ports) {
        $socket = New-Object System.Net.Sockets.TcpClient
        $sockets += $socket

        $asyncResult = $socket.BeginConnect($Target, $port, $null, $null)
        $asyncResults += $asyncResult
    }

    # Wait for 2 seconds or until all sockets have connected
    $timeout = 2000
    $endTime = (Get-Date).AddMilliseconds($timeout)

    foreach ($asyncResult in $asyncResults) {
        $remainingTime = ($endTime - (Get-Date)).TotalMilliseconds
        if ($remainingTime -le 0) {
            break
        }
        $asyncResult.AsyncWaitHandle.WaitOne($remainingTime) | Out-Null
    }

    # Check the status of each socket
    for ($i = 0; $i -lt $sockets.Count; $i++) {
        $socket = $sockets[$i]
        $port = $ports[$i]

        switch ($port) {
            22 {
                $ConnectionDetails.PortSSH = $socket.Connected
            }
            80 {
                $ConnectionDetails.PortHTTP = $socket.Connected
            }
            135 {
                $ConnectionDetails.PortWMI = $socket.Connected
            }
            139 {
                $ConnectionDetails.PortSMB1 = $socket.Connected
            }
            443 {
                $ConnectionDetails.PortHTTPS = $socket.Connected
            }
            445 {
                $ConnectionDetails.PortSMB2 = $socket.Connected
            }
            1433 {
                $ConnectionDetails.PortSQL = $socket.Connected
            }
            3389 {
                $ConnectionDetails.PortRDP = $socket.Connected
            }
            5985 {
                $ConnectionDetails.PortWinRM = $socket.Connected
            }
            5986 {
                $ConnectionDetails.PortWinRMS = $socket.Connected
            }
            default {
                $ConnectionDetails.OtherPorts.Add($port, $socket.Connected)
            }
        }

        # Close the socket
        $socket.Close()
    }

    LogConnectionResult -PortName "SSH" -Result $ConnectionDetails.PortSSH;
    LogConnectionResult -PortName "HTTP" -Result $ConnectionDetails.PortHTTP;
    LogConnectionResult -PortName "WMI" -Result $ConnectionDetails.PortWMI;
    LogConnectionResult -PortName "SMB" -Result $ConnectionDetails.PortSMB1;
    LogConnectionResult -PortName "HTTPS" -Result $ConnectionDetails.PortHTTPS;
    LogConnectionResult -PortName "SQL" -Result $ConnectionDetails.PortSQL;
    LogConnectionResult -PortName "RDP" -Result $ConnectionDetails.PortRDP;
    LogConnectionResult -PortName "WinRM" -Result $ConnectionDetails.PortWinRM;
    LogConnectionResult -PortName "WinRMS" -Result $ConnectionDetails.PortWinRMS;
    LogText ""

    # OtherPorts
}

function LogConnectionResult {
    param(
        [string] $PortName,
        $Result
    )

    if ($null -eq $Result) {
        return;
    }

    $resultText = "Failed"
    $colour = [System.ConsoleColor]::Yellow;
    if ($Result) {
        $resultText = "Succeeded"
        $colour = [System.ConsoleColor]::Green;
    }

    LogText "$PortName " -NoNewLine -Color $colour -LogTo Console
    LogText "$($PortName): $resultText"  -LogTo File
}
#endregion

#region Custom Export
$ScriptExcludeFields = $null
function Export-MyCsv {
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [PSCustomObject[]] $InputObject,
        [Parameter(Mandatory = $true)]
        [string] $Path,
        [switch] $Append,
        [switch] $IncludeIndex
    )

    begin {
        if ($null -eq $ScriptExcludeFields) {
            LoadExcludeFields
        }

        $fileExcludeFields = $null
        $fileID = GetFileNameFinalPart -FilePath $Path
        if ($ScriptExcludeFields.ContainsKey($fileID)) {
            $fileExcludeFields = $ScriptExcludeFields[$fileID].Split(',') | ForEach-Object { $_.Trim() }
        }

        $index = 1
        $outputData = New-Object 'System.Collections.Generic.List[object]'
    }

    process {
        foreach ($item in $InputObject) {
            
            # Create a duplicate of the item with only the required fields
            $processedItem = New-Object PSObject 
            foreach ($prop in $item.PSObject.Properties) {
                if ($null -eq $fileExcludeFields -or !$fileExcludeFields.Contains($prop.Name)) {
                    $processedItem | Add-Member -MemberType NoteProperty -Name $prop.Name -Value $prop.Value -Force
                }
            }

            # Add index if requested
            if ($IncludeIndex) {
                $processedItem | Add-Member -MemberType NoteProperty -Name 'Index' -Value $index -Force
                $index++
            }

            # Add the processed item to the list
            $outputData.Add($processedItem)
        }
    }

    end {
        # Convert the list to an array and export to CSV
        $outputData.ToArray() | Export-Csv -Path $Path -Encoding UTF8 -NoTypeInformation -Append:$Append -Delimiter ","

        # This function logs the field names and sample values of exported data to the log file and a CSV file
        # Uncomment the following line to enable this functionality
        #LogFieldInfo -InputObject $outputData -OutputFileName $fileID
        $outputData = $null
    }
}

function LoadExcludeFields {
    $script:ScriptExcludeFields = @{}

    if (!($ScriptDescription)) {
        return
    }

    # Import the CSV
    try {
        $csvData = Import-Csv -Path ".\ExcludeFields.csv" -ErrorAction SilentlyContinue
    } catch {
    }

    foreach ($row in $csvData | Where-Object { $_.Script -eq $ScriptDescription }) {
        $ScriptExcludeFields[$row.OutputFile] = $row.ExcludeFields
    }
}

function GetFileNameFinalPart {
    param (
        [string]$FilePath
    )

    # Return the last part of the filename i.e. Apps for the following values
    # c:\temp\20240102_101212_Apps.csv
    # c:\temp\Apps.csv

    # Get the filename without the extension
    $fileNameWithoutExtension = [System.IO.Path]::GetFileNameWithoutExtension($FilePath)

    # Split the filename by underscore or backslash, and take the last part
    $lastPart = ($fileNameWithoutExtension -split '[\\_]')[-1]

    return $lastPart
}

# Support function. Not currently called. The function is used for custom testing to aid the local development team where necessary
function LogFieldInfo {
    param(
        [PSCustomObject[]] $InputObject,
        [string] $OutputFileName
    )
    
    # This function logs the field names and sample values of exported data to the log file and a CSV file
    # It is not enabled by default
    if (!($InputObject) -or $InputObject.Count -eq 0) {
        return
    }

    # Creating a new array of fields and sample values
    $lstFields = @()

    $recordIndex = 1
    foreach ($record in $InputObject) {
        $fieldNames = $record.PSObject.Properties.Name
        $fieldIndex = 1

        # Iterate through each property
        foreach ($fieldName in $fieldNames) {
            # Creating a new object for each property
            $field = [PSCustomObject][ordered]@{
                ScriptFileName = $ScriptName
                ScriptDescription = $ScriptDescription
                OutputFileName = $OutputFileName
                FieldName = $fieldName
                SampleValue = $record.$fieldName
                FieldIndex = $fieldIndex++
                RecordIndex = $recordIndex
            }

            # Add new object to the array
            $lstFields += $field
        }
    
        $recordIndex++
        if ($recordIndex -gt 3) {
            break
        }
    }

    # Save the field info to log file and csv file
    $csvLines = $lstFields | ConvertTo-Csv -NoTypeInformation
    $csvString = $csvLines -join "`n"
    LogText $csvString -LogTo File
    $lstFields | export-csv -Path ".\FieldInfo.csv" -NoTypeInformation -Append -Delimiter ","
}
#endregion

#region Ensure Module
function EnsureModuleLoaded {
    param (
        [Parameter(Mandatory=$true)]
        [string] $ModuleName,
        [Version] $MinimumVersion = '1.0.0'
    )

    try {
        # Check if the module is already loaded or available
        $module = Get-Module -Name $ModuleName -ListAvailable | Sort-Object Version -Descending | Select-Object -First 1
        $strDefaultInstallAction = "Y"
        if ($Headless) {
            $strDefaultInstallAction = "N"
        }

        if ($module) {
            if ($module.Version -lt $MinimumVersion) {
                $userResponse = QueryUser -Prompt "$ModuleName version $($module.Version) is older than the required minimum version $MinimumVersion. Do you want to upgrade it now? (Y/N)" -DefaultValue $strDefaultInstallAction
                if ($userResponse -eq 'Y' -or $userResponse -eq 'y') {
                    try {
                        
                        $updateModuleParams = @{
                            Name = $ModuleName
                            Scope = "CurrentUser"
                            Force = $true
                            Confirm = $false 
                            ErrorAction = "Stop"
                        };

                        LogText "Calling 'Update-Module -Name $ModuleName -Force'"
                        LogText "The update can take 5-10 minutes without any visual feedback. Please be patient." -Color Gray
                        Update-Module @updateModuleParams
                        Import-Module -Name $ModuleName
                        LogText "Module $ModuleName upgraded and imported"
                        return $true
                    } catch {
                        LogError "Failed to upgrade $ModuleName. Error: $_"
                        LogText "If this problem persists, you can try calling 'Uninstall-Module -Name $ModuleName' and rerunning this script" -Color Yellow
                        return $false
                    }
                } else {
                    LogText "Module $ModuleName was not upgraded" -Color Red
                    LogText "To upgrade the required module, follow one of these methods:"
                    LogText ""
                    LogText "[Online Devices]"
                    LogText "1. Open a PowerShell console and run:"
                    LogText "   Update-Module -Name $ModuleName -Force"
                    LogText ""
                    LogText "[Offline Devices]"
                    LogText "1. On an internet-connected PC, open a PowerShell console and run:"
                    LogText "   Save-Module -Name $ModuleName -Path C:\Modules"
                    LogText ""
                    LogText "2. Transfer the contents from 'C:\Modules' on the online PC to:"
                    LogText "   C:\Program Files\WindowsPowerShell\Modules on the offline device."
                    LogText ""
                    LogText "[Alternative]"
                    LogText "1. Download and install directly from:"
                    LogText "   https://www.powershellgallery.com/packages/$ModuleName"
                    LogText ""
                    LogText "Note: Upgrading is essential for optimal functionality."
                    return $false
                }
            } elseif (-not (Get-Module -Name $ModuleName)) {
                LogText "Importing Module $ModuleName"
                Import-Module -Name $ModuleName
                LogText "Module $ModuleName imported"
                return $true
            } else {
                LogText "Module $ModuleName already imported"
                return $true
            }
            return
        }

        # If the module is not available, ask the user if they want to install it
        $userResponse = QueryUser -Prompt "A required module ($ModuleName) is not currently installed. Do you want to install it now? (Y/N)" -DefaultValue $strDefaultInstallAction
        if ($userResponse -eq 'Y' -or $userResponse -eq 'y') {
            try {
                $installModuleParams = @{
                    Name = $ModuleName
                    Scope = "CurrentUser"
                    MinimumVersion = $MinimumVersion
                    Force = $true 
                    Confirm = $false 
                    AllowClobber = $true
                    ErrorAction = "Stop"
                };

                if ($SkipPublisherCheck) {
                    $installModuleParams.Add("SkipPublisherCheck", $true)
                }

                LogText "Calling 'Install-Module -Name $ModuleName -Force'"
                LogText "The installation can take 5-10 minutes without any visual feedback. Please be patient." -Color Gray
                Install-Module @installModuleParams
                LogText "Importing Module $ModuleName"
                Import-Module -Name $ModuleName
                LogText "Module $ModuleName has been installed"
                return $true
            } catch {
                LogError "Failed to install $ModuleName. Error: $_"
                return $false
            }
        } else {
            LogText "Module $ModuleName was not installed" -Color Red
            LogText "To install the required module, follow one of these methods:"
            LogText ""
            LogText "[Online Devices]"
            LogText "1. Open a PowerShell console and run:"
            LogText "   Install-Module -Name $ModuleName -Force"
            LogText ""
            LogText "[Offline Devices]"
            LogText "1. On an internet-connected PC, open a PowerShell console and run:"
            LogText "   Save-Module -Name $ModuleName -Path C:\Modules"
            LogText ""
            LogText "2. Transfer the contents from 'C:\Modules' on the online PC to:"
            LogText "   C:\Program Files\WindowsPowerShell\Modules on the offline device."
            LogText ""
            LogText "[Alternative]"
            LogText "1. Download and install directly from:"
            LogText "   https://www.powershellgallery.com/packages/$ModuleName"
            LogText ""
            LogText "Note: Installation is essential for this script to work"
            
            return $false
        }
    } catch {
        LogLastException
    }

    return $false
}
#endregion

function Get-VMwareVMList
{
    try
    {
        InitialiseLogFile
        SetupOutputFormats
        LogEnvironmentDetails

        EnsureModuleLoaded -ModuleName "VMware.PowerCLI" -MinimumVersion "13.1.0.21624340"

        try
        {
            # Configure the environment
            LogTimeAndText "Configuring Connection Settings" 
            if ($SkipProxy) {
                Set-PowerCLIConfiguration -ProxyPolicy NoProxy -Confirm:$false -ErrorVariable $errorConfig | Out-Null
            }
            Set-PowerCLIConfiguration -InvalidCertificateAction ignore -Confirm:$false -ErrorVariable $errorConfig -ParticipateInCeip:$false | Out-Null
        }
        catch
        {
            LogError("Unable to configure connection settings. Continuing. Error: $_")
        }

        if (!($VMserver)){
            $VMserver = QueryUser -Message "VMware Server Name Required" -Prompt "VMware host or vCenter Name" -DefaultValue $env:computerName
        }

        if(!($Username -and $Password)){
            $Creds = Get-ConsoleCredential -Message "VMware Credentials Required" -DefaultUsername $Username -AsPSCredential
            if (!($Creds)) {
                LogError("Missing Parameter: Username and Password must be specified")
                return
            }
        }

        # Connect to the VMware server
        LogTimeAndText "Connecting to VMware server"
        TestConnectivity -Target $VMserver -Ports @($VMServerPort)

        $parameters = @{
            Server = $VMServer
        }
        if ($VMServerPort -ne 443) {
            $parameters.Add("Port", $VMServerPort);
        }
        if ($VMServerProtocol -ne "") {
            $parameters.Add("Protocol", $VMServerProtocol);
        }
        if ($Creds) {
            $parameters.Add("Credential", $Creds);
        }
        else {
            $parameters.Add("User", $Username);
            $parameters.Add("Password", $Password);
        }

        $viServer = Connect-VIServer @parameters
        
        if($viServer){
            LogTimeAndText "Connected to VMware server"
        }
        else {
            Throw "VMware logon failed"
        }

        # Get the VM & VM Host Data
        if ($RequiredData -eq "VMData" -or $RequiredData -eq "VMDataPlusDRS" -or $RequiredData -eq "AllData") {
            LogTimeAndText "Getting VM Info"

            $DataCenters = Get-Datacenter | Sort-Object -Property Name

            $lstVMs = ForEach ($Datacenter in ($DataCenters)) {
                ForEach ($VM in ($Datacenter | Get-VM | Sort-Object -Property Name)) {
                
                    $IPAddresses = "";
                    $MACAddresses = "";
                    $NetworkNames = "";
                    foreach ($NIC in $VM.Guest.Nics) {
                        $IPAddresses += $NIC.IPAddress -join ','
                        $MACAddresses += $NIC.MacAddress
                        $NetworkNames += $NIC.NetworkName
                
                        $IPAddresses += ','
                        $MACAddresses += ','
                        $NetworkNames += ','
                    }
                
                    "" | Select-Object -Property @{N="VM";E={$VM.Name}},
                    @{N="VMCPUCount";E={$vm.ExtensionData.Config.Hardware.NumCPU/$vm.ExtensionData.Config.Hardware.NumCoresPerSocket}},
                    @{N="VMCPUCoreCount";E={$vm.NumCPU}},
                    @{N="VMCPUCorePerCPUCount";E={$vm.ExtensionData.Config.Hardware.NumCoresPerSocket}},
                    @{N="PowerState";E={$VM.PowerState}},
                    @{N="FaultToleranceState";E={$VM.ExtensionData.Summary.Runtime.FaultToleranceState}},
                    @{N="OnlineStandby";E={$VM.ExtensionData.Summary.Runtime.OnlineStandby}},
                    ##@{N="Version";E={$VM.Version}},
                    @{N="Description";E={$VM.Description}},
                    ##@{N="Notes";E={$VM.Notes}},
                    ##@{N="MemoryMB";E={$VM.MemoryMB}},
                    @{N="ResourcePool";E={$VM.ResourcePool}},
                    @{N="ResourcePoolID";E={$VM.ResourcePoolId}},
                    ##@{N="PersistentID";E={$VM.PersistentId}},
                    @{N="ID";E={$VM.Id}},
                    @{N="UID";E={$VM.Uid}},
                    @{N="UUID";E={$VM.ExtensionData.Config.Uuid}},
                    @{N="Folder";E={$VM.Folder.Name}},
                    @{N="IPs";E={$IPAddresses}},
                    @{N="MACs";E={$MACAddresses}},
                    @{N="NetworkNames";E={$NetworkNames}},
                    @{N="OS";E={if ($VM.Guest.OSFullName) {$VM.Guest.OSFullName} else {$VM.ExtensionData.Guest.OSFullName}}},
                    @{N="FQDN";E={$VM.Guest.HostName}},
                    @{N="FQDN2";E={$VM.ExtensionData.Guest.HostName}},
                    ##@{N="ScreenDimensions";E={$VM.Guest.ScreenDimensions}},
                    @{N="GuestHostname";E={$VM.ExtensionData.Summary.Guest.HostName}},
                    @{N="GuestId";E={$VM.ExtensionData.Summary.Guest.GuestId}},
                    @{N="GuestFullName";E={$VM.ExtensionData.Summary.Guest.GuestFullName}},
                    @{N="GuestIP";E={$VM.ExtensionData.Summary.Guest.IpAddress}},
                    @{N="Datacenter";E={$Datacenter.name}},
                    @{N="Cluster";E={$vm.VMHost.Parent.Name}},
                    @{N="ClusterID";E={$vm.VMHost.Parent.ID}},
                    @{N="HostName1";E={$vm.VMHost.Name}},
                    @{N="HostName2";E={$vm.VMHost.ExtensionData.Summary.Config.Name}},
                    @{N="HostName3";E={$VM.VMHost.NetworkInfo.HostName}},
                    @{N="HostDomainName";E={$VM.VMHost.NetworkInfo.DomainName}},
                    @{N="HostCPUCount";E={$vm.VMHost.ExtensionData.Summary.Hardware.NumCpuPkgs}},
                    @{N="HostCPUCoreCount";E={$vm.VMHost.ExtensionData.Summary.Hardware.NumCpuCores/$vm.VMHost.ExtensionData.Summary.Hardware.NumCpuPkgs}},
                    @{N="HyperthreadingActive";E={$vm.VMHost.HyperthreadingActive}},
                    @{N="HostManufacturer";E={$VM.VMHost.Manufacturer}},
                    @{N="HostID";E={$VM.VMHost.Id}},
                    @{N="HostUID";E={$VM.VMHost.Uid}},
                    @{N="HostPowerState";E={$VM.VMHost.PowerState}},
                    @{N="HostHyperThreading";E={$VM.VMHost.HyperthreadingActive}},
                    @{N="HostvMotionEnabled";E={$vm.VMHost.ExtensionData.Summary.Config.VmotionEnabled}},
                    @{N="HostVendor";E={$VM.VMHost.ExtensionData.Hardware.SystemInfo.Vendor}},
                    @{N="HostModel";E={$VM.VMHost.ExtensionData.Hardware.SystemInfo.Model}},
                    ##@{N="HostRAM";E={$VM.VMHost.ExtensionData.Summary.Hardware.MemorySize}},
                    @{N="HostCPUModel";E={$VM.VMHost.ExtensionData.Summary.Hardware.CpuModel}},
                    @{N="HostThreadCount";E={$VM.VMHost.ExtensionData.Summary.Hardware.NumCpuThreads}},
                    ##@{N="HostCPUSpeed";E={$VM.VMHost.ExtensionData.Summary.Hardware.CpuMhz}},
                    @{N="HostProductName";E={$VM.VMHost.ExtensionData.Summary.Config.Product.Name}},
                    @{N="HostProductVersion";E={$VM.VMHost.ExtensionData.Summary.Config.Product.Version}},
                    @{N="HostProductBuild";E={$VM.VMHost.ExtensionData.Summary.Config.Product.Build}},
                    @{N="HostProductOS";E={$VM.VMHost.ExtensionData.Summary.Config.Product.OsType}},
                    ##@{N="HostProductLicenseKey";E={$VM.VMHost.LicenseKey}},
                    ##@{N="HostProductLicenseName";E={$VM.VMHost.ExtensionData.Summary.Config.Product.LicenseProductName}},
                    ##@{N="HostProductLicense Version";E={$VM.VMHost.ExtensionData.Summary.Config.Product.LicenseProductVersion}},
                    @{N="HostvMotionIPAddress";E={$VM.VMHost.ExtensionData.Config.vMotion.IPConfig.IpAddress}}##,
                    ##@{N="HostvMotionSubnetMask";E={$VM.VMHost.ExtensionData.Config.vMotion.IPConfig.SubnetMask}}   
                }
            }

            if ($MicrosoftOnly) {
                $lstVMs = $lstVMs | Where-Object { $_.OS -ilike "*windows*" }
            }

            if ($TargetType -eq "Servers") {
                $lstVMs = $lstVMs | Where-Object { $_.OS -ilike "*server*" }
            } elseif ($TargetType -eq "Clients") {
                $lstVMs = $lstVMs | Where-Object { -not ($_.OS -ilike "*server*") }
            } 
            
            $lstVMs | Export-MyCsv -Path $OutputFile1 -IncludeIndex

            $VmHostInfo = ForEach ($Datacenter in ($DataCenters)) {
                ForEach ($VMHost in ($Datacenter | Get-VMHost | Sort-Object -Property Name)) {
                
                    $strUuid = ""
                    try {
                        $EsxCli = Get-EsxCli -VMHost $VMHost
                        $Uuid = $EsxCli.system.uuid.get()
                        $strUuid = $Uuid.ToString();
                    }
                    catch {
                    }
                    
                    "" | Select-Object -Property @{N="VMHost";E={$VMHost.Name}},
                    @{N="Name2";E={$VMHost.ExtensionData.Summary.Config.Name}},
                    @{N="Name3";E={$VMHost.NetworkInfo.HostName}},
                    @{N="ID";E={$VMHost.Id}},
                    @{N="UID";E={$VMHost.Uid}},
                    @{N="HardwareUUID";E={$VMHost.ExtensionData.Hardware.SystemInfo.Uuid}},
                    @{N="VMwareUUID";E={$strUuid}},
                    @{N="Datacenter";E={$Datacenter.name}},
                    @{N="Cluster";E={$VMHost.Parent.Name}},
                    @{N="ClusterID";E={$VMHost.Parent.ID}},
                    @{N="IsStandalone";E={$VMHost.IsStandalone}},
                    @{N="DomainName";E={$VMHost.NetworkInfo.DomainName}},
                    @{N="CPUCount";E={$VMHost.ExtensionData.Summary.Hardware.NumCpuPkgs}},
                    @{N="CPUCoreCount";E={$VMHost.ExtensionData.Summary.Hardware.NumCpuCores/$VMHost.ExtensionData.Summary.Hardware.NumCpuPkgs}},
                    @{N="HyperthreadingActive";E={$VMHost.HyperthreadingActive}},
                    @{N="Manufacturer";E={$VMHost.Manufacturer}},
                    @{N="PowerState";E={$VMHost.PowerState}},
                    @{N="vMotionEnabled";E={$VMHost.ExtensionData.Summary.Config.VmotionEnabled}},
                    @{N="Vendor";E={$VMHost.ExtensionData.Hardware.SystemInfo.Vendor}},
                    @{N="Model";E={$VMHost.ExtensionData.Hardware.SystemInfo.Model}},
                    ##@{N="RAM";E={$VMHost.ExtensionData.Summary.Hardware.MemorySize}},
                    @{N="CPUModel";E={$VMHost.ExtensionData.Summary.Hardware.CpuModel}},
                    @{N="ThreadCount";E={$VMHost.ExtensionData.Summary.Hardware.NumCpuThreads}},
                    ##@{N="CPUSpeed";E={$VMHost.ExtensionData.Summary.Hardware.CpuMhz}},
                    @{N="ProductName";E={$VMHost.ExtensionData.Summary.Config.Product.Name}},
                    @{N="ProductVersion";E={$VMHost.ExtensionData.Summary.Config.Product.Version}},
                    @{N="ProductBuild";E={$VMHost.ExtensionData.Summary.Config.Product.Build}},
                    @{N="ProductOS";E={$VMHost.ExtensionData.Summary.Config.Product.OsType}},
                    @{N="InstallDate";E={CalculateInstallDate($strUuid)}},
                    ##@{N="ProductLicenseKey";E={$VMHost.LicenseKey}},
                    ##@{N="ProductLicenseName";E={$VMHost.ExtensionData.Summary.Config.Product.LicenseProductName}},
                    ##@{N="ProductLicense Version";E={$VMHost.ExtensionData.Summary.Config.Product.LicenseProductVersion}},
                    @{N="vMotionIPAddress";E={$VMHost.ExtensionData.Config.vMotion.IPConfig.IpAddress}}##,
                    ##@{N="vMotionSubnetMask";E={$VMHost.ExtensionData.Config.vMotion.IPConfig.SubnetMask}}   
                }
            }

            $VmHostInfo | Export-MyCsv -Path $OutputFile2 -IncludeIndex
        }

        if ($RequiredData -eq "VMDataPlusDRS" -or $RequiredData -eq "AllData") {

            LogTimeAndText "Getting VM DRS Info"

            $AllClusters = Get-Cluster
            if ($AllClusters){
                LogTimeAndText "$($AllClusters.Count) Cluster(s) found"

                # Save Cluster Details
                $ClusterInfo = $AllClusters | select Name, ID, UID, ParentID, HAEnabled, DrsEnabled, DrsMode, DrsAutomationLevel
                $ClusterInfo | Export-MyCsv -Path $OutputFile3 -IncludeIndex

                $DRSRules = Get-DrsRule -Cluster $AllClusters

                if ($DRSRules){
                    
                    $ExtendedDRSRules = ForEach ($DRSRule in $DRSRules) {
                
                        $VMIDs = $DRSRule.VMIds -join ','
                        $VMIDs2 = ""
                        $VMUIDs = ""
                        $VMUUIDs = ""
                        $AffineHostGroupName = ""
                        $AntiAffineHostGroupName = ""
                        $VmGroupName = ""

                        if ($DRSRule.Type -eq "VMAffinity" -or $DRSRule.Type -eq "AntiVMAffinity") {
                            $VMIDs2 = ($DRSRule.ExtensionData.VM | select Id) -join ','
                            $VMUIDs = ($DRSRule.ExtensionData.VM | select Uid) -join ','
                            #$VMUUIDs = ($DRSRule.ExtensionData.VM | select @{Name="UUID"; Expression={$_.ExtensionData.Config.Uuid}} | select -ExpandProperty UUID) -join ','
                            #$VMUUIDs = ($DRSRule.ExtensionData.VM | select @{Name="UUID"; Expression={$_.ExtensionData.Config.Uuid}} | select -ExpandProperty UUID) -join ','
                        }
                        elseif ($DRSRule.Type -eq "VMHostAffinity") {
                            $AffineHostGroupName = $DRSRule.ExtensionData.affineHostGroupName
                            $AntiAffineHostGroupName = $DRSRule.ExtensionData.antiAffineHostGroupName
                            $VmGroupName = $DRSRule.ExtensionData.vmGroupName
                        }

                        "" | Select-Object -Property @{N="Name";E={$DRSRule.Name}},
                            @{N="Key";E={$DRSRule.Key}},
                            @{N="Uid";E={$DRSRule.Uid}},
                            @{N="Cluster";E={$DRSRule.Cluster}},
                            @{N="ClusterId";E={$DRSRule.ClusterId}},
                            @{N="ClusterUid";E={$DRSRule.ClusterUid}},
                            @{N="Enabled";E={$DRSRule.Enabled}},
                            @{N="Mandatory";E={$DRSRule.Mandatory}},
                            @{N="Type";E={$DRSRule.Type}},
                            @{N="VMIDs";E={$VMIDs}},
                            @{N="VMIDs2";E={$VMIDs2}},
                            @{N="VMUIDs";E={$VMUIDs}},
                            @{N="VMUUIDs";E={$VMUUIDs}},
                            @{N="AffineHostGroupName";E={$AffineHostGroupName}},
                            @{N="AntiAffineHostGroupName";E={$AntiAffineHostGroupName}},
                            @{N="VmGroupName";E={$VmGroupName}}
                    }

                    $ExtendedDRSRules | Export-MyCsv -Path $OutputFile4 -IncludeIndex
                }

                $ExpandedDRSGroups = @()
                ForEach ($VMwareCluster in $AllClusters) {

                    $DRSGroups = $VMwareCluster.ExtensionData.ConfigurationEx.Group

                    if ($DRSGroups){
                    
                        $ExpandedDRSGroups += ForEach ($DRSGroup in $DRSGroups) {
                
                            $VMIDs = ""
                            $VMUIDs = ""
                            $VMNames = ""
                            $HostIDs = ""
                            $HostUIDs = ""
                            $HostNames = ""

                            if ($DRSGroup.VM) {
                                #$VMIDs = ($DRSGroup.VM | Select-Object -ExpandProperty Id) -join ','
                                #$VMUIDs = ($DRSGroup.VM | Select-Object -ExpandProperty Uid) -join ','
                                #$VMNames = ($DRSGroup.VM | Select-Object -ExpandProperty Name) -join ','
                            }
                            
                            if ($DRSGroup.Host) {
                                #$HostIDs = ($DRSGroup.Host | Select-Object -ExpandProperty Id) -join ','
                                #$HostUIDs = ($DRSGroup.Host | Select-Object -ExpandProperty Uid) -join ','
                                #$HostNames = ($DRSGroup.Host | Select-Object -ExpandProperty Name) -join ','
                            }

                            "" | Select-Object -Property @{N="Name";E={$DRSGroup.Name}},
                                @{N="Type";E={$DRSGroup.GetType()}},
                                @{N="ClusterName";E={$VMwareCluster.Name}},
                                @{N="ClusterID";E={$VMwareCluster.Id}},
                                @{N="VMIDs";E={$VMIDs}},
                                @{N="VMUIDs";E={$VMUIDs}},
                                @{N="VMNames";E={$VMNames}},
                                @{N="HostIDs";E={$HostIDs}},
                                @{N="HostUIDs";E={$HostUIDs}},
                                @{N="HostNames";E={$HostNames}},
                                @{N="VMs";E={$DRSGroup.VM}},
                                @{N="Hosts";E={$DRSGroup.Host}}
                        }
                    }
                }

                $ExpandedDRSGroups | Export-MyCsv -Path $OutputFile5 -IncludeIndex
            }
        }
    
        if ($RequiredData -eq "VMMigrationHistory" -or $RequiredData -eq "AllData") {

            LogTimeAndText "Getting VM History Info"

            Get-VMotionRecords | Export-MyCsv -Path $OutputFile6 -IncludeIndex
        }
    }
    catch 
    {
        LogLastException
    }

    LogTimeAndText "VMware Script Completed"
}

function CalculateInstallDate([string] $Uuid){
    try {
        if ($Uuid) {
            $hexSeconds = [Regex]::Match($Uuid, '^(\w{8,})-').Groups[1].Value
            $decSeconds = [Convert]::ToInt64($hexSeconds, 16)
            $dateDate = [TimeZone]::CurrentTimeZone.ToLocalTime(([DateTime]'1/1/1970').AddSeconds($decSeconds))
            if ($dateDate) {
                return $dateDate.ToString("yyyy-MM-dd HH:mm:ss")
            }
        }
    }
    catch {
    }
    return "";
}

function Get-VMotionRecords {

    # Search for any vmotion-related events
    $eventFilterSpec = New-Object VMware.Vim.EventFilterSpec
    $eventFilterSpec.Category = "info"
    $eventFilterSpec.Time = New-Object VMware.Vim.EventFilterSpecByTime
    $eventFilterSpec.Time.beginTime = (get-date).adddays(-$VMotionHistoryDays)
    $eventFilterSpec.Type = "VmMigratedEvent", "DrsVmMigratedEvent"
        
    $global:DefaultVIServer.ExtensionData.UpdateViewData("Content.EventManager.*")
    $eventMgr = $global:DefaultVIServer.ExtensionData.Content.LinkedView.EventManager

    $allEvents = @()
    $eventNumber = 100
    $ecollectionImpl = Get-View ($eventMgr.CreateCollectorForEvents($eventFilterSpec))
    $ecollection = $ecollectionImpl.ReadNextEvents($eventNumber)
    while($ecollection -ne $null){
        $allEvents += $ecollection
        $ecollection = $ecollectionImpl.ReadNextEvents($eventNumber)
    }
    $ecollectionImpl.DestroyCollector()

    $vMotions = @()
    $vMotions += $allEvents | Select CreatedTime,
            @{N="Type";E={$_.GetType().Name}},
            @{N="TypeId";E={$_.EventTypeId}},
            @{N="ID";E={$_.key}},
            @{N="UserName";E={if($_.UserName){$_.UserName}else{"System"}}},
            @{N="VM";E={$_.VM.Name}},
            @{N="VMId";E={$_.VM.vm.Id}},
            @{N="VMUid";E={$_.VM.vm.Uid}}, 
            @{N="SourceHost";E={$_.SourceHost.Name}},
            @{N="DestinationHost";E={$_.Host.Name}},
            @{N="Description";E={$_.FullFormattedMessage}},  
            @{N="ResourcePool";E={$_.ComputeResource.Name}}

    return $vmotions | Sort-Object -Property CreatedTime        
}

function EnvironmentConfigured {
    if (Get-Command "Connect-VIServer" -errorAction SilentlyContinue){
        return $true}
    else {
        return $false}
}

Get-VMwareVMList
