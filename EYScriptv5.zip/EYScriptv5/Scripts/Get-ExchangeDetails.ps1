 ##########################################################################
 #
 # Get-ExchangeDetails
 #
 ##########################################################################

 <#
.SYNOPSIS
Retrieves Exchange server, mail box, ActiveSync device and CAL information from an Exchange Server

.DESCRIPTION
The Get-ExchangeDetails script queries a single Exchange Server and produces up to 5 CSV files
    1)    ExchangeServerDetails.csv - One record per Exchange Server in the farm
    2)    ExchangeMailBoxes.csv - One record per MailBox
    3)    ExchangeDevices.csv - One record per ActiveSync device
    4)    ExchangeCALs.csv - General CAL requirement details 
    5)    ExchangeCALDetails.csv - Lists all servers and MailBoxes that require a license and 
          the type of license required
    Files are written to current working directory

.PARAMETER Server 
Host name of Exchange server to scan

.PARAMETER Office365
Flag. Query Office365 hosted Exchange environment. If this flag is set, the parameter 'Server' is ignored

.PARAMETER Username
Exchange Server Username

.PARAMETER Password
Exchange Server Password

.PARAMETER Verbose
Display extra progress information on screen

.PARAMETER RequiredData
By default the script collects Exchange server, mail box, ActiveSync device and CAL information from the 
selected Exchange server. It's possible to collect subsets of the data. Possible options are...
"AllData","ServerData","EntityData","UtilizationData","CALData"

.NOTES
This script supports Exchange server 2007 onwards. There are some limitations on what data can be
collected from different versions of Exchange server remotely. If the script fails to execute remotely
try
    1)    Specify a username and password (even if they are the details of the current user)
    2)  Execute the script locally on the Exchange Server

.COPYRIGHT
Copyright (C) 2024 Ernst & Young Global Limited. All rights reserved. The Irish firm Ernst & Young is a member practice of Ernst & Young Global Limited.

This script is proprietary to Ernst & Young Global Limited (or one of its member firms). Unauthorized copying of this file, via any medium, is strictly prohibited. Redistribution and use in source and binary forms, with or without modification, are not permitted without prior written permission from Ernst & Young Global Limited.

.LICENSE
This script is provided "AS IS" without warranty of any kind. Ernst & Young Global Limited expressly disclaims all warranties, whether express, implied, statutory, or otherwise, with respect to this script including all implied warranties of merchantability, fitness for a particular purpose, and non-infringement. In no event shall Ernst & Young Global Limited be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this script, even if advised of the possibility of such damage.

#>

 Param(
    [alias("server")]
    $ExchangeServer,
    [string] $OutputFolder = ".\",
    [string] $OutputFilePrefix = "",
    [alias("o1")]
    $OutputFile1 = "ExchangeServerDetails.csv",
    [alias("o2")]
    $OutputFile2 = "ExchangeMailBoxes.csv",
    [alias("o3")]
    $OutputFile3 = "ExchangeDevices.csv",
    [alias("o4")]
    $OutputFile4 = "ExchangeCALs.csv",
    [alias("o5")]
    $OutputFile5 = "ExchangeCALDetails.csv",
    [alias("o6")]
    [string] $LogFile = "ExchangeQueryLog.txt",
    [string] $UserName,
    [string] $Password,
    [string] $SecurePassword,
    [alias("Office365")]
    [switch] $ExchangeOnline,
    [switch] $UseSSL,
    [ValidateSet("AllData","ServerData","EntityData","UtilizationData","CALData")] 
    $RequiredData = "AllData",
    [ValidateSet("Both","RemoteSession","SnapIn")] 
    $ConnectionMethod = "Both",
    [switch] $Verbose,
    [switch] $Headless,
    [switch] $ListSnapIns)

$ScriptDescription =       "Exchange Server Scan"
$ScriptVersion =           "5.0.10"

#region Logging
$script:OutFileSupportsNoNewLine = $false;
function InitialiseLogFile {

    if (!($script:OutputFolder)) {
        $script:OutputFolder = ".\"
    }

    if (!(Test-Path $script:OutputFolder)) {
        New-Item -ItemType Directory -Path $script:OutputFolder | Out-Null
    }

    $script:OutputFolder = Resolve-Path $script:OutputFolder | Select-Object -ExpandProperty Path

    if (!($script:OutputFolder.EndsWith('\'))) {
        $script:OutputFolder += '\'
    }

    if ($script:OutputFolder -and !($LogFile -like "*\*")) {
        $script:LogFile = Join-Path $script:OutputFolder "$($OutputFilePrefix)$LogFile"
    }

    if ($LogFile -and (Test-Path $LogFile)) {
        Remove-Item $LogFile
    }

    if ((Get-Command "Out-File").parameters["NoNewline"]) {
        $script:OutFileSupportsNoNewLine = $true;
    }

    PrefixOutputFilesWithFolder
    DecryptPassword
}

function PrefixOutputFilesWithFolder {
    
    # Check if $OutputFolder exists and is not empty
    if ($script:OutputFolder) {
        $counter = 1
        while ($true) {
            $outputFileVarName = "OutputFile$counter"
            # Check if the OutputFile variable exists
            if (Get-Variable -Name $outputFileVarName -Scope Script -ErrorAction SilentlyContinue) {
                # Get the value of the OutputFile variable
                $outputFileValue = Get-Variable -Name $outputFileVarName -ValueOnly -Scope Script
                # Check if it does not contain a backslash, and if so, prefix with OutputFolder
                if (-not $outputFileValue.Contains("\"))
                {
                    Set-Variable -Name $outputFileVarName -Value (Join-Path $script:OutputFolder "$($OutputFilePrefix)$outputFileValue") -Scope Script
                }
                $counter++
            } else {
                # Exit loop if the variable does not exist
                break
            }
        }
    }
} 

function LogText {
    param(
        [Parameter(Position=0, ValueFromRemainingArguments=$true, ValueFromPipeline=$true)]
        [Object] $Object,
        [System.ConsoleColor]$Color = [System.Console]::ForegroundColor,
        [switch]$NoNewLine = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"
    )

    if ($LogTo -ne "File") {
        # Display text on screen
        Write-Host -Object $Object -ForegroundColor $Color -NoNewline:$NoNewLine
    }
    
    if ($LogTo -ne "Console") {
        if ($LogFile) {
            if ($script:OutFileSupportsNoNewLine) {
                $Object | Out-File $LogFile -Encoding utf8 -Append -NoNewline:$NoNewLine 
            }
            else {
                $Object | Out-File $LogFile -Encoding utf8 -Append 
            }
        }
    }
}

function LogTimeAndText {
    param(
        [string] $Text,
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Blue,
        [switch]$IncludeDate = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    $output = "";
    if ($IncludeDate) {
        $output = Get-Date -Format "yyyy-MM-dd HH:mm:ss.ff"
    } else {
        $output = Get-Date -Format "HH:mm:ss.ff"
    }

    $output += " - "
    $output += $Text
    LogText $output -Color $Color -LogTo $LogTo
}

function LogError([string[]]$errorDescription){
    if ($Verbose){
        LogText ""
    }

    $output = $errorDescription -join "`r`n              "
    LogTimeAndText $output -Color Red

    Start-Sleep -s 3
}

function LogLastException() {
    $currentException = $Error[0].Exception;

    while ($currentException)
    {
        LogText -Color Red $currentException
        LogText -Color Red $currentException.Data
        LogText -Color Red $currentException.HelpLink
        LogText -Color Red $currentException.HResult
        LogText -Color Red $currentException.Message
        LogText -Color Red $currentException.Source
        LogText -Color Red $currentException.StackTrace
        LogText -Color Red $currentException.TargetSite

        $currentException = $currentException.InnerException
    }

    Start-Sleep -s 3
}

$script:MostRecentActivity = ""
function LogProgress([string]$Activity, [string]$Status, [Int32]$PercentComplete, [switch]$Completed ){
    
    if ($Activity) {
        $script:MostRecentActivity = $Activity
    } else {
        if ($script:MostRecentActivity) {
            $Activity = $script:MostRecentActivity
        } else {
            $Activity = "Unspecified"
        }
    }
    Write-Progress -activity $Activity -Status $Status -percentComplete $PercentComplete -Completed:$Completed
    LogTimeAndText $Status
}

function GetScriptPath
{
    if($PSCommandPath){
        return $PSCommandPath; }
        
    if($MyInvocation.ScriptName){
        return $MyInvocation.ScriptName }
        
    if($script:MyInvocation.MyCommand.Path){
        return $script:MyInvocation.MyCommand.Path }

    return $script:MyInvocation.MyCommand.Definition
}

function GetDotNetFrameworkVersion {
    #$release = Get-ItemPropertyValue -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release
    $regKey = Get-Item -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    $release = $regKey.GetValue("Release")
    switch ($release) {
        { $_ -ge 533320 } { $version = "4.8.1 or later ($release)"; break }
        { $_ -ge 528040 } { $version = "4.8 ($release)"; break }
        { $_ -ge 461808 } { $version = "4.7.2 ($release)"; break }
        { $_ -ge 461308 } { $version = "4.7.1 ($release)"; break }
        { $_ -ge 460798 } { $version = "4.7 ($release)"; break }
        { $_ -ge 394802 } { $version = "4.6.2 ($release)"; break }
        { $_ -ge 394254 } { $version = "4.6.1 ($release)"; break }
        { $_ -ge 393295 } { $version = "4.6 ($release)"; break }
        { $_ -ge 379893 } { $version = "4.5.2 ($release)"; break }
        { $_ -ge 378675 } { $version = "4.5.1 ($release)"; break }
        { $_ -ge 378389 } { $version = "4.5 ($release)"; break }
        default { $version = $null; break }
    }

    return $version
}

function LogEnvironmentDetails ([string[]] $OtherDetails){

    $script:ScriptPath = GetScriptPath
    $script:ScriptName = split-path $ScriptPath -leaf

    LogText " "
    LogHeaderText -FrameLine 
    LogHeaderText -LeftText " _______     __" -LeftColor Yellow
    LogHeaderText -LeftText "|  ___\ \   / /" -LeftColor Yellow
    LogHeaderText -LeftText "| |__  \ \_/ / " -LeftColor Yellow
    LogHeaderText -LeftText "|  __|  \   /  " -LeftColor Yellow
    LogHeaderText -LeftText "| |____  | |   " -LeftColor Yellow -RightText "$ScriptDescription  "
    LogHeaderText -LeftText "|______| |_|   " -LeftColor Yellow -RightText "Version $ScriptVersion  "
    LogHeaderText
    LogHeaderText -FrameLine 

    LogText " "
    LogText " $ScriptName" -Color Green 
    LogText " "

    if ($PSVersionTable.PSVersion.Major -ge 3) {
        $oSDetails = Get-CimInstance -ClassName Win32_OperatingSystem
    } else {
        $oSDetails = Get-WmiObject -Class Win32_OperatingSystem
    }
    $elevated = [bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")
    $currentThread = [System.Threading.Thread]::CurrentThread
    $dotNetFrameworkVersion = GetDotNetFrameworkVersion
    LogText -Color Gray "Computer Name:          $($env:COMPUTERNAME)"
    LogText -Color Gray "User Name:              $($env:USERNAME)@$($env:USERDNSDOMAIN)"
    LogText -Color Gray "Windows Version:        $($oSDetails.Caption)($($oSDetails.Version))"
    LogText -Color Gray "Memory kB:              $($oSDetails.TotalVisibleMemorySize.ToString("N0")) ($($oSDetails.FreePhysicalMemory.ToString("N0")) Free)"
    LogText -Color Gray "Locale:                 $($oSDetails.Locale) (Language $($oSDetails.OSLanguage))"
    LogText -Color Gray "PowerShell Host:        $($host.Version.Major)"
    LogText -Color Gray "PowerShell Version:     $($PSVersionTable.PSVersion)"
    LogText -Color Gray "PowerShell Word Size:   $($([IntPtr]::size) * 8) bit"
    LogText -Color Gray "Script Path:            $ScriptPath"
    LogText -Color Gray "Working Directory:      $PWD"
    LogText -Color Gray "CLR Version:            $($PSVersionTable.CLRVersion)"
    LogText -Color Gray ".Net Framework Version: $dotNetFrameworkVersion"
    LogText -Color Gray "Elevated:               $elevated"
    LogText -Color Gray "Current Date Time:      $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
    LogText -Color Gray "Default Date Format:    $($CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern)"
    LogText -Color Gray "Current Culture:        $((Get-Culture).EnglishName) (UI: $((Get-UICulture).EnglishName))"
    
    if (Test-Path "Variable:OutputFolder") {
        LogText -Color Gray "Output Folder:          $OutputFolder" 
    }
    if (Test-Path "Variable:OutputFile1") {
        LogText -Color Gray "Output File 1:          $OutputFile1" 
    }
    if (Test-Path "Variable:LogFile") {
        LogText -Color Gray "Log File:               $LogFile" 
    }
    if (Test-Path "Variable:ComputerName") {
        LogText -Color Gray "Target Computer Name:   $ComputerName" 
    }
    if (Test-Path "Variable:UserName") {
        LogText -Color Gray "Script User Name:       $UserName"
    }
    if (Test-Path "Variable:MicrosoftOnly") {
        LogText -Color Gray "Microsoft Only:         $MicrosoftOnly"
    }
    if (Test-Path "Variable:TargetType") {
        LogText -Color Gray "Target Type:            $TargetType"
    }
    if (Test-Path "Variable:ScriptRegime") {
        LogText -Color Gray "Script Regime:          $ScriptRegime"
    }
    if (Test-Path "Variable:RequiredData") {
        LogText -Color Gray "Required Data:          $RequiredData"
    }

    foreach ($detail in $OtherDetails){
        LogText -Color Gray $detail
    }

    LogText -Color Gray ""

}

function LogHeaderText {
    param(
        [string] $LeftText = " ",
        [System.ConsoleColor]$LeftColor = [System.ConsoleColor]::Blue,
        [string] $RightText,
        [System.ConsoleColor]$RightColor = [System.ConsoleColor]::DarkGray,
        [char] $FrameChar = "#",
        [switch] $FrameLine,
        [switch] $LeftAlignRightText,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    if ($FrameLine) {
        $strFullText = "  " + ($FrameChar.ToString() * 69)
        LogText $strFullText -Color DarkGray -LogTo $LogTo
        return
    }

    $strLeftFrame = "  $FrameChar  "
    $strLeftText = $LeftText
    $strRightText = $RightText
    $strRightFrame = "  $FrameChar"
    if ($LeftAlignRightText) {
        $strRightText = $RightText.PadRight(63 - $LeftText.Length)
    } else {
        $strLeftText = $LeftText.PadRight(63 - $RightText.Length)
    }
    

    if ($LogTo -eq "Console" -or $LogTo -eq "Both") {
        LogText $strLeftFrame -LogTo "Console" -NoNewLine -Color DarkGray
        LogText $strLeftText -LogTo "Console" -NoNewLine -Color $LeftColor
        LogText $strRightText -LogTo "Console" -NoNewLine -Color $RightColor
        LogText $strRightFrame -LogTo "Console" -Color DarkGray
    }

    if ($LogTo -eq "File" -or $LogTo -eq "Both") {
        $strFullText = $strLeftFrame + $strLeftText + $strRightText + $strRightFrame
        LogText $strFullText -LogTo "File" 
    }
}

function DecryptPassword {
    $strOneTimePassword = "%OneTimePassword%" # Replace this with the one-time password
    if ($SecurePassword) {
        $baOneTimePassword = [System.Convert]::FromBase64String($strOneTimePassword)
        $baSecurePassword = [System.Convert]::FromBase64String($SecurePassword)
        for($i=0; $i -lt $baSecurePassword.count ; $i++)
        {
            $baSecurePassword[$i] = $baSecurePassword[$i] -bxor $baOneTimePassword[$i%$baOneTimePassword.Length]
        }
        $script:Password = [System.Text.Encoding]::Unicode.GetString($baSecurePassword);
    }
}
#endregion

#region Setup Output Formats
function SetupOutputFormats {
    # Standardise date/time output to ISO 8601'ish format
    $bOutputFormatsUpdated = $false
    $currentThread = [System.Threading.Thread]::CurrentThread
    $desiredShortPattern = 'yyyy-MM-dd'
    $desiredLongPattern = 'yyyy-MM-dd HH:mm:ss'

    try {
        $cultureInvariant = [CultureInfo]::InvariantCulture.Clone()
        $cultureInvariant.DateTimeFormat.ShortDatePattern = $desiredShortPattern
        $cultureInvariant.DateTimeFormat.LongDatePattern = $desiredLongPattern
        $cultureInvariant.NumberFormat.NumberGroupSeparator = ""  
        $cultureInvariant.NumberFormat.NumberDecimalSeparator = "."
        $currentThread.CurrentCulture = $cultureInvariant
        $bOutputFormatsUpdated = $true
    }
    catch {
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $currentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $currentThread.CurrentCulture.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $currentThread.CurrentCulture.NumberFormat.NumberGroupSeparator = ""  
            $currentThread.CurrentCulture.NumberDecimalSeparator = "."
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $cultureCopy = $currentThread.CurrentCulture.Clone()
            $cultureCopy.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $cultureCopy.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $cultureCopy.NumberFormat.NumberGroupSeparator = ""  
            $cultureCopy.NumberDecimalSeparator = "."
            $currentThread.CurrentCulture = $cultureCopy
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread using clone of current culture"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        LogText "Failed to update output formats"
    }
}
#endregion

#region Query User
function QueryUser([string]$Message, [string]$Prompt, [switch]$AsSecureString = $false, [string]$DefaultValue){
    $strResult = ""
    
    if ($Message) {
        LogText $Message -color Yellow
    }

    if ($DefaultValue) {
        $Prompt += " (Default [$DefaultValue])"
    }

    $Prompt += ": "
    LogText $Prompt -color Yellow -NoNewLine
    
    if ($Headless) {
        LogText " (Headless - Using Default Value)" -color Yellow
    }
    else {
        $strResult = Read-Host -AsSecureString:$AsSecureString
    }

    if(!$strResult -or ($strResult.Length -eq 0)) {
        $strResult = $DefaultValue
        if ($AsSecureString) {
            $strResult = ConvertTo-SecureString $strResult -AsPlainText -Force
        }
    }

    return $strResult
}

function Get-ConsoleCredential([String] $Message, [String] $DefaultUsername, [switch] $AsPSCredential)
{
    $strUsername = QueryUser -Message $Message -Prompt "Username" -DefaultValue $DefaultUsername
    if (!$strUsername){
        return $null
    }

    $strSecurePassword = QueryUser -Prompt "Password" -AsSecureString
    if (!$strSecurePassword){
        return $null
    }

    if ($AsPSCredential) {
        $Creds = New-Object System.Management.Automation.PSCredential ($strUsername, $strSecurePassword)
    } else {
        $Creds = New-Object PSObject

        $bstrSecurePassword = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($strSecurePassword)
        $strUnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstrSecurePassword)

        $Creds | Add-Member -MemberType NoteProperty -Name "UserName" -Value $strUsername
        $Creds | Add-Member -MemberType NoteProperty -Name "Password" -Value $strUnsecurePassword
    }

    return $Creds
}
#endregion

#region Custom Export
$ScriptExcludeFields = $null
function Export-MyCsv {
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [PSCustomObject[]] $InputObject,
        [Parameter(Mandatory = $true)]
        [string] $Path,
        [switch] $Append,
        [switch] $IncludeIndex
    )

    begin {
        if ($null -eq $ScriptExcludeFields) {
            LoadExcludeFields
        }

        $fileExcludeFields = $null
        $fileID = GetFileNameFinalPart -FilePath $Path
        if ($ScriptExcludeFields.ContainsKey($fileID)) {
            $fileExcludeFields = $ScriptExcludeFields[$fileID].Split(',') | ForEach-Object { $_.Trim() }
        }

        $index = 1
        $outputData = New-Object 'System.Collections.Generic.List[object]'
    }

    process {
        foreach ($item in $InputObject) {
            
            # Create a duplicate of the item with only the required fields
            $processedItem = New-Object PSObject 
            foreach ($prop in $item.PSObject.Properties) {
                if ($null -eq $fileExcludeFields -or !$fileExcludeFields.Contains($prop.Name)) {
                    $processedItem | Add-Member -MemberType NoteProperty -Name $prop.Name -Value $prop.Value -Force
                }
            }

            # Add index if requested
            if ($IncludeIndex) {
                $processedItem | Add-Member -MemberType NoteProperty -Name 'Index' -Value $index -Force
                $index++
            }

            # Add the processed item to the list
            $outputData.Add($processedItem)
        }
    }

    end {
        # Convert the list to an array and export to CSV
        $outputData.ToArray() | Export-Csv -Path $Path -Encoding UTF8 -NoTypeInformation -Append:$Append -Delimiter ","

        # This function logs the field names and sample values of exported data to the log file and a CSV file
        # Uncomment the following line to enable this functionality
        #LogFieldInfo -InputObject $outputData -OutputFileName $fileID
        $outputData = $null
    }
}

function LoadExcludeFields {
    $script:ScriptExcludeFields = @{}

    if (!($ScriptDescription)) {
        return
    }

    # Import the CSV
    try {
        $csvData = Import-Csv -Path ".\ExcludeFields.csv" -ErrorAction SilentlyContinue
    } catch {
    }

    foreach ($row in $csvData | Where-Object { $_.Script -eq $ScriptDescription }) {
        $ScriptExcludeFields[$row.OutputFile] = $row.ExcludeFields
    }
}

function GetFileNameFinalPart {
    param (
        [string]$FilePath
    )

    # Return the last part of the filename i.e. Apps for the following values
    # c:\temp\20240102_101212_Apps.csv
    # c:\temp\Apps.csv

    # Get the filename without the extension
    $fileNameWithoutExtension = [System.IO.Path]::GetFileNameWithoutExtension($FilePath)

    # Split the filename by underscore or backslash, and take the last part
    $lastPart = ($fileNameWithoutExtension -split '[\\_]')[-1]

    return $lastPart
}

# Support function. Not currently called. The function is used for custom testing to aid the local development team where necessary
function LogFieldInfo {
    param(
        [PSCustomObject[]] $InputObject,
        [string] $OutputFileName
    )
    
    # This function logs the field names and sample values of exported data to the log file and a CSV file
    # It is not enabled by default
    if (!($InputObject) -or $InputObject.Count -eq 0) {
        return
    }

    # Creating a new array of fields and sample values
    $lstFields = @()

    $recordIndex = 1
    foreach ($record in $InputObject) {
        $fieldNames = $record.PSObject.Properties.Name
        $fieldIndex = 1

        # Iterate through each property
        foreach ($fieldName in $fieldNames) {
            # Creating a new object for each property
            $field = [PSCustomObject][ordered]@{
                ScriptFileName = $ScriptName
                ScriptDescription = $ScriptDescription
                OutputFileName = $OutputFileName
                FieldName = $fieldName
                SampleValue = $record.$fieldName
                FieldIndex = $fieldIndex++
                RecordIndex = $recordIndex
            }

            # Add new object to the array
            $lstFields += $field
        }
    
        $recordIndex++
        if ($recordIndex -gt 3) {
            break
        }
    }

    # Save the field info to log file and csv file
    $csvLines = $lstFields | ConvertTo-Csv -NoTypeInformation
    $csvString = $csvLines -join "`n"
    LogText $csvString -LogTo File
    $lstFields | export-csv -Path ".\FieldInfo.csv" -NoTypeInformation -Append -Delimiter ","
}
#endregion

#region Test Connection
$script:ConnectionDetails = [PSCustomObject][ordered]@{
    TargetName = ""
    ComputerName = ""
    ComputerDomain = ""
    IPAddress0 = ""
    NameResolution = [Nullable[bool]]$null
    Ping = [Nullable[bool]]$null
    PortSSH = [Nullable[bool]]$null
    PortHTTP = [Nullable[bool]]$null
    PortWMI = [Nullable[bool]]$null
    PortSMB1 = [Nullable[bool]]$null
    PortHTTPS = [Nullable[bool]]$null
    PortSMB2 = [Nullable[bool]]$null
    PortSQL = [Nullable[bool]]$null
    PortRDP = [Nullable[bool]]$null
    PortWinRM = [Nullable[bool]]$null
    PortWinRMS = [Nullable[bool]]$null 
    OtherPorts = @{}
    Error = ""
    ErrorDetails = ""
    CimConnectionType = $null
    CimSession = $null
    PSSession = $null
    HKLM = $null
    HKU = $null
}

function TestConnectivity {
    param(
        [string] $Target,
        [int[]] $Ports = @(22, 80, 135, 139, 443, 445, 1433, 3389, 5985, 5986)
    )

    $ConnectionDetails.TargetName = $Target
    $ConnectionDetails.ComputerName = $Target

    # Test name resolution
    LogText "Name Resolution: " -NoNewLine -Color Gray
    $ConnectionDetails.NameResolution = $false;
    try {
        $nameResolutionResult = [System.Net.Dns]::GetHostAddresses($Target)
        if ($nameResolutionResult.Count -gt 0) {
            $ConnectionDetails.IPAddress0 = $nameResolutionResult[0].IPAddressToString
            $ConnectionDetails.NameResolution = $true;
        }
    } catch {}
    
    if ($ConnectionDetails.NameResolution) {
        LogText "Succeeded" -Color Green
    } else {
        LogText "Failed" -Color Red
        return;
    }
    
    # Test Ping
    LogText "Ping: " -NoNewLine -Color Gray
    $ConnectionDetails.Ping = $false;
    try {
        $pingResult = Test-Connection -ComputerName $Target -Count 1 -ErrorAction SilentlyContinue
        if ($pingResult.StatusCode -eq 0) {
            $ConnectionDetails.Ping = $true
        } else {
            $ConnectionDetails.Ping = $false
        }
    } catch {}
    
    if ($ConnectionDetails.Ping) {
        LogText "Succeeded" -Color Green
    } else {
        LogText "Failed" -Color Red
    }
    
    # Test Ports
    LogText "Port Scan: " -NoNewLine -Color Gray

    $sockets = @()
    $asyncResults = @()

    # Start connections
    foreach ($port in $Ports) {
        $socket = New-Object System.Net.Sockets.TcpClient
        $sockets += $socket

        $asyncResult = $socket.BeginConnect($Target, $port, $null, $null)
        $asyncResults += $asyncResult
    }

    # Wait for 2 seconds or until all sockets have connected
    $timeout = 2000
    $endTime = (Get-Date).AddMilliseconds($timeout)

    foreach ($asyncResult in $asyncResults) {
        $remainingTime = ($endTime - (Get-Date)).TotalMilliseconds
        if ($remainingTime -le 0) {
            break
        }
        $asyncResult.AsyncWaitHandle.WaitOne($remainingTime) | Out-Null
    }

    # Check the status of each socket
    for ($i = 0; $i -lt $sockets.Count; $i++) {
        $socket = $sockets[$i]
        $port = $ports[$i]

        switch ($port) {
            22 {
                $ConnectionDetails.PortSSH = $socket.Connected
            }
            80 {
                $ConnectionDetails.PortHTTP = $socket.Connected
            }
            135 {
                $ConnectionDetails.PortWMI = $socket.Connected
            }
            139 {
                $ConnectionDetails.PortSMB1 = $socket.Connected
            }
            443 {
                $ConnectionDetails.PortHTTPS = $socket.Connected
            }
            445 {
                $ConnectionDetails.PortSMB2 = $socket.Connected
            }
            1433 {
                $ConnectionDetails.PortSQL = $socket.Connected
            }
            3389 {
                $ConnectionDetails.PortRDP = $socket.Connected
            }
            5985 {
                $ConnectionDetails.PortWinRM = $socket.Connected
            }
            5986 {
                $ConnectionDetails.PortWinRMS = $socket.Connected
            }
            default {
                $ConnectionDetails.OtherPorts.Add($port, $socket.Connected)
            }
        }

        # Close the socket
        $socket.Close()
    }

    LogConnectionResult -PortName "SSH" -Result $ConnectionDetails.PortSSH;
    LogConnectionResult -PortName "HTTP" -Result $ConnectionDetails.PortHTTP;
    LogConnectionResult -PortName "WMI" -Result $ConnectionDetails.PortWMI;
    LogConnectionResult -PortName "SMB" -Result $ConnectionDetails.PortSMB1;
    LogConnectionResult -PortName "HTTPS" -Result $ConnectionDetails.PortHTTPS;
    LogConnectionResult -PortName "SQL" -Result $ConnectionDetails.PortSQL;
    LogConnectionResult -PortName "RDP" -Result $ConnectionDetails.PortRDP;
    LogConnectionResult -PortName "WinRM" -Result $ConnectionDetails.PortWinRM;
    LogConnectionResult -PortName "WinRMS" -Result $ConnectionDetails.PortWinRMS;
    LogText ""

    # OtherPorts
}

function LogConnectionResult {
    param(
        [string] $PortName,
        $Result
    )

    if ($null -eq $Result) {
        return;
    }

    $resultText = "Failed"
    $colour = [System.ConsoleColor]::Yellow;
    if ($Result) {
        $resultText = "Succeeded"
        $colour = [System.ConsoleColor]::Green;
    }

    LogText "$PortName " -NoNewLine -Color $colour -LogTo Console
    LogText "$($PortName): $resultText"  -LogTo File
}
#endregion

function EnvironmentConfigured {
    if (Get-Command "Get-MailboxStatistics" -errorAction SilentlyContinue){
        return $true}
    else {
        return $false}
}

function ExchangeOnlineModuleLoaded {
    if (Get-Command "Connect-ExchangeOnline" -errorAction SilentlyContinue){
        return $true}
    else {
        return $false}
}

function CountItems {
    Param(
    $InputObject)

    if (-not $InputObject){
        return 0
    }
    elseif (Get-Member -inputobject $InputObject -name "Count" -Membertype Properties) {
        return $InputObject.Count
    }
    else {
        return 1
    }
}

function Get-ExchangeDetails {

    InitialiseLogFile
    SetupOutputFormats
    LogEnvironmentDetails -OtherDetails @(
        "Server Parameter:       $ExchangeServer");

    if ($ExchangeOnline) {
        $script:ConnectionMethod = "RemoteSession"
        $script:ExchangeServer = "ps.outlook.com"
        $script:UseSSL = $true
    }

    if (($ConnectionMethod -eq "Both") -or ($ConnectionMethod -eq "RemoteSession"))
    {
        if (!($ExchangeServer))
        {
            # Target server was not specified on the command line. Query user.
            $ExchangeServer = QueryUser -Prompt "Exchange Server" -DefaultValue "$($env:computerName)"
        }

        # Can we connect to the Exchange server?
        $connectivityTestPorts = @(80)
        if ($UseSSL) {
            $connectivityTestPorts = @(443)
        }

        TestConnectivity -Target $ExchangeServer -Ports $connectivityTestPorts

        if ($ConnectionDetails.NameResolution -eq $false) {
            LogError "Name resolution failed for $ExchangeServer"
            return
        }
        if ($UseSSL -and $ConnectionDetails.PortHTTPS -eq $false) {
            LogText "Warning: Unable to connect to Port 443 on $ExchangeServer"
        } elseif (!($UseSSL) -and $ConnectionDetails.PortHTTP -eq $false) {
            LogText "Warning: Unable to connect to Port 80 on $ExchangeServer"
        }

        # Prompt for credentials if not specified
        if(!($UserName -and $Password)){
            $exchangeCreds = Get-ConsoleCredential -Message "Exchange Server Credentials Required" -DefaultUsername $UserName -AsPSCredential
        }
        else 
        {
            # Create the Credentials object
            $securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
            $exchangeCreds = New-Object System.Management.Automation.PSCredential ($UserName, $securePassword)
        }

        # Connect to exchange server
        LogTimeAndText "Connecting to Exchange Server $ExchangeServer"
        $connectionUri = "http://"
        if ($UseSSL) {
            $connectionUri = "https://"
        }
        $connectionUri += $ExchangeServer + "/powershell/"
        $authenticationType = "Kerberos"

    
        if ($Verbose)
        {
            LogText "ConnectionUri: $connectionUri"
            LogText "AuthenticationType: $authenticationType"
            LogText "UserName: $($exchangeCreds.UserName)"
        }

        if ($exchangeCreds)
        {
            $exchangeSession = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri $connectionUri -Authentication $authenticationType -AllowRedirection -Credential $exchangeCreds -WarningAction:silentlycontinue
        }
        else
        {
            $exchangeSession = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri $connectionUri -Authentication $authenticationType -AllowRedirection -WarningAction:silentlycontinue
        }
    }
        
    if ($exchangeSession) {
        LogTimeAndText "Importing Session"
        Import-PSSession $exchangeSession -AllowClobber -WarningAction:silentlycontinue
    }

    if (!(EnvironmentConfigured))
    {
        # Exchange environment not configured
        if ($ConnectionMethod -eq "Both" -or $ConnectionMethod -eq "SnapIn")
        {
            # Load Exchange SnapIns
            LogTimeAndText "Loading SnapIns"
            
            $allSnapIns = get-pssnapin -registered | Sort-Object -Descending
            if ($ListSnapIns)
            {
                LogText "SnapIns"
                $allSnapIns | ForEach-Object { LogText "Name: $($_.Name) Version: $($_.PSVersion)"}
            }
            
            foreach ($snapIn in $allSnapIns){
                if (($snapIn.name -eq 'Microsoft.Exchange.Management.PowerShell.SnapIn') -or
                    ($snapIn.name -eq 'Microsoft.Exchange.Management.PowerShell.Admin') -or
                    ($snapIn.name -eq 'Microsoft.Exchange.Management.PowerShell.E2010') -or
                    ($snapIn.name -eq 'Microsoft.Exchange.Management.PowerShell.E2013')){
                    LogText "Adding SnapIn: $($snapIn.Name)"
                    add-PSSnapin -Name $snapIn.name
                    
                    if (EnvironmentConfigured) {
                        break
                    }
                }
            }
        }
    }
    
    if (!(EnvironmentConfigured))
    {
        LogError ("The script was unable to connect to Exchange server", 
                    "To maximise the chance of connectivity, please",
                    "   1) Ensure that the Exchange PowerShell Module is installed on this device and/or",
                    "   2) Execute this script on the Exchange server")
        exit
    }   

    # Get the list of Exchange Servers (Not supported in Office365)
    if (!($ExchangeOnline))
    {
        LogProgress -activity "Exchange Data Export" -Status "Getting server details" -percentComplete 15
        if (Get-Command "Get-ExchangeServer" -errorAction SilentlyContinue){
            $exchangeServers = Get-ExchangeServer # -Identity $ExchangeServer

            $exchangeServers | Select-Object Name, Domain,
                ExchangeVersion, Edition,
                DistinguishedName, Identity, Guid,
                ObjectCategory, @{Name="ObjectClass"; Expression={$_.ObjectClass -join ";"}},
                ExchangeLegacyServerRole,
                Fqdn,
                InternetWebProxyBypassList,
                IsHubTransportServer,
                IsClientAccessServer,
                IsEdgeServer,
                IsMailboxServer,
                IsProvisionedServer,
                IsUnifiedMessagingServer,
                IsFrontendTransportServer,
                AdminDisplayVersion,
                Site,
                ServerRole,
                ProductID,
                IsExchangeTrialEdition,
                IsExpiredExchangeTrialEdition,
                @{Name="MailboxProvisioningAttributes"; Expression={$_.MailboxProvisioningAttributes -join ";"}},
                RemainingTrialPeriod,
                WhenChangedUTC,
                WhenCreatedUTC,
                OriginatingServer,
                ObjectState | Export-MyCsv -Path $OutputFile1 -IncludeIndex
        
            if ($Verbose) {
                LogText "Server Count: $($exchangeServers.Count)"
            }
        }
        else {
            LogText "Exchange cmdlet Get-ExchangeServer not found. Does current user have sufficient permissions?" 
        }
    }

    $lstMailBoxData = New-Object System.Collections.Generic.List[System.Management.Automation.PSObject]
    $lstActiveSyncDeviceData = New-Object System.Collections.Generic.List[System.Management.Automation.PSObject]
    $dictMailBoxData = @{}

    if ($RequiredData -eq "EntityData" -or $RequiredData -eq "UtilizationData" -or $RequiredData -eq "AllData")
    {
        # Get the list of mailboxes from Exchange
        LogProgress -activity "Exchange Data Export" -Status "Querying Mailboxes" -percentComplete 20

        # Get best function
        $fnGetMailbox = "Get-Mailbox"
        #if (Get-Command "Get-EXOMailbox" -errorAction SilentlyContinue) {
        #    $fnGetMailbox = "Get-EXOMailbox" Get-EXOMailbox
        #}
        # Removed the use of Get-EXOMailbox as it does not include many fields
        $mailBoxes = &$fnGetMailbox -ResultSize 'Unlimited'
        if ($mailBoxes) 
        {
            $Script:TotalMailboxes = CountItems($mailBoxes)
            LogTimeAndText "Mailbox Count: $Script:TotalMailboxes"

            foreach ($mailBox in $mailBoxes) {
                
                $mailBoxData = $mailBox | Select-Object -Property UserPrincipalName, SamAccountName, DisplayName, Alias, Identity,
                    PrimarySmtpAddress, 
                    DistinguishedName, Guid, RecipientType, RecipientTypeDetails, IsMailboxEnabled, WhenMailboxCreated, WhenCreatedUTC, 
                    WhenChangedUTC, ServerName, Office, ExchangeVersion, ObjectCategory, 
                    @{n='EmailAddresses';e={($_ | Select-Object -expand EmailAddresses) -join ", "}}, 
                    ##@{n='ProtocolSettings';e={($_ | Select-Object -expand ProtocolSettings) -join ", "}},
                    ##@{n='Languages';e={($_ | Select-Object -expand Languages) -join ", "}},
                    ##@{n='AddressListMembership';e={($_ | Select-Object -expand AddressListMembership) -join ", "}},
                    @{n='ObjectClass';e={($_ | Select-Object -expand ObjectClass) -join ", "}},
                    AccountDisabled,
                    IsLinked, IsShared, IsMonitoringMailbox, IsRootPublicFolderMailbox, IsInactiveMailbox,
                    OrganizationalUnit, Database,
                    #CASMailbox details
                    ActiveSyncMailboxPolicy, ActiveSyncEnabled, OwaMailboxPolicy, OWAEnabled, OWAforDevicesEnabled, 
                    ECPEnabled, EmwsEnabled, PopEnabled, ImapEnabled, MAPIEnabled, EwsEnabled, OriginatingServer, 
                    # MailboxStatistics details
                    LastLogonTime, LastLogoffTime, LastInteractionTime, LastUserActionTime, LastUserActionUpdateTime, LastLoggedOnUserAccount, 
                    MailboxType, MailboxTypeDetail, IsQuarantined, IsArchiveMailbox, IsMoveDestination, ItemCount

                $lstMailBoxData.Add($mailBoxData)
                if ($mailBoxData.DistinguishedName) {
                    $dictMailBoxData[$mailBoxData.DistinguishedName] = $mailBoxData;
                }
            }

            # Save the details that we have so far in case the script doesn't complete successfully
            $lstMailBoxData | Export-MyCsv -Path $OutputFile2 -IncludeIndex

            LogProgress -activity "Exchange Data Export" -Status "Querying CAS Mailboxes" -percentComplete 30
            try {
                $casMailBoxes = Get-CASMailbox -ResultSize 'Unlimited'
                if ($casMailBoxes) {
                    $casMailBoxCount = CountItems($casMailBoxes)
                    LogTimeAndText "CAS Mailbox Count: $casMailBoxCount"

                    foreach ($casMailBox in $casMailBoxes) {
                        $mailBox = $dictMailBoxData[$casMailBox.DistinguishedName];
                        if ($mailBox) {
                            $mailBox.ActiveSyncMailboxPolicy = $casMailBox.ActiveSyncMailboxPolicy
                            $mailBox.ActiveSyncEnabled = $casMailBox.ActiveSyncEnabled
                            $mailBox.OwaMailboxPolicy = $casMailBox.OwaMailboxPolicy
                            $mailBox.OWAEnabled = $casMailBox.OWAEnabled
                            $mailBox.OWAforDevicesEnabled = $casMailBox.OWAforDevicesEnabled
                            $mailBox.ECPEnabled = $casMailBox.ECPEnabled
                            $mailBox.EmwsEnabled = $casMailBox.EmwsEnabled
                            $mailBox.PopEnabled = $casMailBox.PopEnabled
                            $mailBox.ImapEnabled = $casMailBox.ImapEnabled
                            $mailBox.MAPIEnabled = $casMailBox.MAPIEnabled
                            $mailBox.EwsEnabled = $casMailBox.EwsEnabled
                            $mailBox.OriginatingServer = $casMailBox.OriginatingServer
                        } else {
                            LogText "$(Get-Date -Format HH:mm:ss.ff) Mailbox not found. User: $($casMailBox.DistinguishedName)"
                        }
                    }

                    # Save the details that we have so far in case the script doesn't complete successfully
                    $lstMailBoxData | Export-MyCsv -Path $OutputFile2 -IncludeIndex
                }

            } catch {
                LogLastException
            }
            
        }
        
        # Get Device details
        try {
            LogProgress -activity "Exchange Data Export" -Status "Querying Device Data" -percentComplete 60
            if (Get-Command "Get-ActiveSyncDevice" -errorAction SilentlyContinue) {
                if ((Get-Command "Get-ActiveSyncDevice").parameters['ResultSize']) {
                    $activeSyncDevices = Get-ActiveSyncDevice -ResultSize 'Unlimited' -WarningAction:silentlycontinue
                }
                else {
                    $activeSyncDevices = Get-ActiveSyncDevice -WarningAction:silentlycontinue
                }
                
                if ($activeSyncDevices)
                {
                    $activeSyncDeviceCount = CountItems($activeSyncDevices)
                    LogText "Device Count: $activeSyncDeviceCount"
                    

                    foreach ($activeSyncDevice in $activeSyncDevices) {
                    
                        $activeSyncDeviceData = $activeSyncDevice | select -Property Identity, FriendlyName, Name, 
                            DeviceId, Guid, DeviceOS, 
                            DeviceType, DeviceModel, UserDisplayName, OrganizationId, DeviceActiveSyncVersion, 
                            IsManaged, IsCompliant, IsDisabled, 
                            FirstSyncTime, WhenCreatedUTC, WhenChangedUTC, LastPingHeartbeat, LastSyncAttemptTime, LastSuccessSync, 
                            LastPolicyUpdateTime, DevicePolicyApplied, Status,
                            ClientType, ClientVersion, DeviceAccessState, DeviceAccessStateReason

                        $lstActiveSyncDeviceData.Add($activeSyncDeviceData)
                    }

                    # Save the details that we have so far in case the script doesn't complete successfully
                    $lstActiveSyncDeviceData | Export-MyCsv -Path $OutputFile3 -IncludeIndex
                }
            }
            elseif ((Get-Command "Get-ActiveSyncDeviceStatistics" -errorAction SilentlyContinue) -and
                    $mailBoxes -and
                    ($RequiredData -eq "UtilizationData" -or $RequiredData -eq "AllData")) {
                #Exchange 2007 support 'Get-ActiveSyncDeviceStatistics' but not 'Get-ActiveSyncDevice'
                $lstActiveSyncDeviceData = $mailBoxes | ForEach-Object { Get-ActiveSyncDeviceStatistics -Mailbox $_}
                $lstActiveSyncDeviceData | Export-MyCsv -Path $OutputFile3 -IncludeIndex
            }
            else {
                LogText "Exchange cmdlet Get-ActiveSyncDevice not found. Mobile device data not available" 
            }
        } catch {
            LogLastException
        }
        
    }

    if ($RequiredData -eq "UtilizationData" -or $RequiredData -eq "AllData")
    {
        # Get ActiveSyncDevice Stats
        LogProgress -activity "Exchange Data Export" -Status "Querying Device Statistics" -percentComplete 70
        try {
            $activeSyncDeviceCounter = 1
            if ($Verbose) {
                LogText  "$(Get-Date -Format HH:mm:ss.ff) $([string]::Format("{0,-5} {1,-19} {2,-35} {3,-20}","Count","User","DeviceOS","LastSuccessSync"))"
            }
    
            $fnGetActiveSyncDeviceStatistics = "Get-ActiveSyncDeviceStatistics"
            if (Get-Command "Get-EXOMobileDeviceStatistics" -errorAction SilentlyContinue) {
                $fnGetActiveSyncDeviceStatistics = "Get-EXOMobileDeviceStatistics"
            }
    
            foreach ($activeSyncDevice in $lstActiveSyncDeviceData) {
                $activeSyncDeviceStatistics = &$fnGetActiveSyncDeviceStatistics -Identity $activeSyncDevice.Identity -WarningAction:silentlycontinue -ErrorAction:silentlycontinue
                if ($activeSyncDeviceStatistics){
                    $activeSyncDevice.FirstSyncTime = $activeSyncDeviceStatistics.FirstSyncTime
                    $activeSyncDevice.LastPingHeartbeat = $activeSyncDeviceStatistics.LastPingHeartbeat
                    $activeSyncDevice.LastSyncAttemptTime = $activeSyncDeviceStatistics.LastSyncAttemptTime
                    $activeSyncDevice.LastSuccessSync = $activeSyncDeviceStatistics.LastSuccessSync
                    $activeSyncDevice.LastPolicyUpdateTime = $activeSyncDeviceStatistics.LastPolicyUpdateTime
                    $activeSyncDevice.DevicePolicyApplied = $activeSyncDeviceStatistics.DevicePolicyApplied
                    $activeSyncDevice.Status = $activeSyncDeviceStatistics.Status
                    $activeSyncDevice.ClientType = $activeSyncDeviceStatistics.ClientType
                    $activeSyncDevice.ClientVersion = $activeSyncDeviceStatistics.ClientVersion
                    $activeSyncDevice.DeviceAccessState = $activeSyncDeviceStatistics.DeviceAccessState
                    $activeSyncDevice.DeviceAccessStateReason = $activeSyncDeviceStatistics.DeviceAccessStateReason
    
                    if ($Verbose) {
                        $activeDeviceUser = GetUserNameFromDeviceID -DeviceID $activeSyncDevice.Identity
                        LogText  "$(Get-Date -Format HH:mm:ss.ff) $([string]::Format("{0,-5} {1,-19} {2,-35} {3,-20}", $activeSyncDeviceCounter, $activeDeviceUser,
                            $activeSyncDevice.DeviceOS, $activeSyncDevice.LastSuccessSync))"
                    }
                }
    
                if ($activeSyncDeviceCounter % 1000 -eq 0) {
                    LogText "Device Count: $activeSyncDeviceCounter. Flushing Records"
                    $lstActiveSyncDeviceData | Export-MyCsv -Path $OutputFile3 -IncludeIndex
                }
    
                $activeSyncDeviceCounter++
            }
    
            $lstActiveSyncDeviceData | Export-MyCsv -Path $OutputFile3 -IncludeIndex
        } catch {
            LogLastException
        }

        try {
            # Get MailBoxStatistics
            LogProgress -activity "Exchange Data Export" -Status "Querying Mailbox Statistics" -percentComplete 80
            $mailBoxCounter = 1
            if ($Verbose) {
                LogText "$(Get-Date -Format HH:mm:ss.ff) $([string]::Format('{0,-5} {1,-55} {2,-20}','Count','UserPrincipalName','LastUserActionTime'))"
            }
                
            foreach ($mailBox in $lstMailBoxData) {

                $mailBoxStatistics = Get-MailboxStatistics -Identity $mailBox.Identity -WarningAction:silentlycontinue
                if ($mailBoxStatistics) {
                    $mailBox.LastLogonTime = $mailBoxStatistics.LastLogonTime
                    $mailBox.LastLogoffTime = $mailBoxStatistics.LastLogoffTime
                    $mailBox.LastInteractionTime = $mailBoxStatistics.LastInteractionTime
                    $mailBox.LastUserActionTime = $mailBoxStatistics.LastUserActionTime
                    $mailBox.LastUserActionUpdateTime = $mailBoxStatistics.LastUserActionUpdateTime
                    $mailBox.LastLoggedOnUserAccount = $mailBoxStatistics.LastLoggedOnUserAccount
                    $mailBox.MailboxType = $mailBoxStatistics.MailboxType
                    $mailBox.MailboxTypeDetail = $mailBoxStatistics.MailboxTypeDetail
                    $mailBox.IsQuarantined = $mailBoxStatistics.IsQuarantined
                    $mailBox.IsArchiveMailbox = $mailBoxStatistics.IsArchiveMailbox
                    $mailBox.IsMoveDestination = $mailBoxStatistics.IsMoveDestination
                    $mailBox.ItemCount = $mailBoxStatistics.ItemCount
                }
                
                if ($Verbose) {
                    LogText "$(Get-Date -Format HH:mm:ss.ff) $([string]::Format('{0,-5} {1,-55} {2,-20}', $mailBoxCounter, $($mailBox.UserPrincipalName), $($mailBox.LastUserActionTime)))"
                }

                if ($mailBoxCounter % 1000 -eq 0) {
                    LogText "Mailbox Count: $mailBoxCounter. Flushing Records"
                $lstMailBoxData | Export-MyCsv $OutputFile2 -IncludeIndex
                }
                    
                $mailBoxCounter++
            }

            # Final export of Mailbox info
            $lstMailBoxData | Export-MyCsv -Path $OutputFile2 -IncludeIndex
        } catch {
            LogLastException
        }

    }
    
    if (($RequiredData -eq "AllData" -or $RequiredData -eq "CALData") -and (!($ExchangeOnline))) {
        GetCALReqs2013Plus
    }

    if ($exchangeSession) {
        LogProgress -activity "Exchange Data Export" -Status "Cleaning Session" -percentComplete 98
        Remove-PSSession -Session $exchangeSession
    }
        
    LogProgress -activity "Exchange Data Export" -complete -Status "Complete"
}

function GetUserNameFromDeviceID {
    param([string] $DeviceID = "")

    $deviceIDParts = $DeviceID.Split("/\")
    if ($deviceIDParts.length -eq 0){
        return ""
    }

    $indexEASD = [array]::IndexOf($deviceIDParts, "ExchangeActiveSyncDevices")
    if ($indexEASD -gt 0){
        $nameParts = $deviceIDParts[$indexEASD - 1].Split("@")
        if ($nameParts.Length -gt 0){
            return $nameParts[0]
        }
    }

    return $deviceIDParts[0]
}

function GetCALReqs2013Plus() {
    try {
        $exchangeLicenseTypes = Get-ExchangeServerAccessLicense

        $totalStandardCALs = (Get-ExchangeServerAccessLicenseUser -LicenseName ($exchangeLicenseTypes | Where-Object {($_.UnitLabel -eq "CAL") -and ($_.LicenseName -like "*Standard*")}).licenseName | Measure-Object).Count
        $totalEnterpriseCALs = (Get-ExchangeServerAccessLicenseUser -LicenseName ($exchangeLicenseTypes | Where-Object {($_.UnitLabel -eq "CAL") -and ($_.LicenseName -like "*Enterprise*")}).licenseName | Measure-Object).Count
        
        LogText "Total Users:           $TotalMailboxes" 
        LogText "Total Standard CALs:   $totalStandardCALs" 
        LogText "Total Enterprise CALs: $totalEnterpriseCALs"
    
        $calReport = New-Object -TypeName System.Object
        $calReport | Add-Member -MemberType NoteProperty -Name TotalMailboxes -Value $TotalMailboxes
        $calReport | Add-Member -MemberType NoteProperty -Name TotalStandardCALs -Value $totalStandardCALs
        $calReport | Add-Member -MemberType NoteProperty -Name TotalEnterpriseCALs -Value $totalEnterpriseCALs
        $calReport | Export-MyCsv -Path $OutputFile4 -IncludeIndex

        $exchangeLicenses = @()
        foreach ($exchangeLicenseType in $exchangeLicenseTypes){
            $exchangeLicenses += Get-ExchangeServerAccessLicenseUser -LicenseName $exchangeLicenseType.LicenseName 
        }

        if ($exchangeLicenses){
            $exchangeLicenses | Select-Object Name, LicenseName | Export-MyCsv -Path $OutputFile5 -IncludeIndex
        }
    }
    catch {
        LogLastException
    }
}

try {
    Get-ExchangeDetails
}
catch {
    LogLastException
}