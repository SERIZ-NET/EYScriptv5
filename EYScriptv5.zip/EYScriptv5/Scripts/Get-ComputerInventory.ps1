#########################################################
#                                                                     
# Get-ComputerInventory.ps1
#
#########################################################

<#

.COPYRIGHT
Copyright (C) 2024 Ernst & Young Global Limited. All rights reserved. The Irish firm Ernst & Young is a member practice of Ernst & Young Global Limited.

This script is proprietary to Ernst & Young Global Limitend (or one of its member firms). Unauthorized copying of this file, via any medium, is strictly prohibited. Redistribution and use in source and binary forms, with or without modification, are not permitted without prior written permission from Ernst & Young Global Limited.

.LICENSE
This script is provided "AS IS" without warranty of any kind. Ernst & Young Global Limited expressly disclaims all warranties, whether express, implied, statutory, or otherwise, with respect to this script including all implied warranties of merchantability, fitness for a particular purpose, and non-infringement. In no event shall Ernst & Young Global Limited be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this script, even if advised of the possibility of such damage.

#>

Param(
    [alias("target")]    
    [string] $ComputerName = $env:COMPUTERNAME,
    [string] $UserName,
    [string] $Password,
    [switch] $IgnoreCertificateErrors,
    [string] $OutputFolder = ".\",
    [string] $OutputFilePrefix = "",
    [alias("o1")][string] $OutputFile1 = "Inv_SystemInfo.csv",
    [alias("o2")][string] $OutputFile2 = "Inv_Applications.csv",
    [alias("o3")][string] $OutputFile3 = "Inv_Services.csv",
    [alias("o4")][string] $OutputFile4 = "Inv_SQL.csv",
    [alias("o5")][string] $OutputFile5 = "Inv_Cluster.csv",
    [alias("o6")][string] $OutputFile6 = "Inv_SoftwareLicenseInfo.csv",
    [alias("o7")][string] $OutputFile7 = "Inv_EventLog.csv",
    [alias("o8")][string] $OutputFile8 = "Inv_UserLogons.csv",
    [alias("o9")][string] $OutputFile9 = "Inv_UserProfiles.csv",
    [alias("o10")][string] $OutputFile10 = "Inv_DNS.csv",
    [alias("o11")][string] $OutputFile11 = "Inv_HyperVVMs.csv",
    [alias("o12")][string] $OutputFile12 = "Inv_HyperVHosts.csv",
    [alias("o13")][string] $OutputFile13 = "Inv_AccessGroup.csv",
    [alias("o14")][string] $OutputFile14 = "Inv_DiskSpace.csv",
    [alias("o15")][string] $OutputFile15 = "Inv_HotFixes.csv",
    [alias("o16")][string] $OutputFile16 = "Inv_IP.csv",
    [alias("o17")][string] $OutputFile17 = "Inv_Processes.csv",
    [alias("o18")][string] $OutputFile18 = "Inv_EventLogLogons.csv",
    [alias("o19")][string] $OutputFile19 = "Inv_Result.txt",
    [alias("o20")][string] $LogFile = "Inv_InventoryLog.txt",
    [string] $SummaryLogFile = "",
    [ValidateSet("All","Servers","Clients")] 
    [string] $TargetType = "All",
    [switch] $MicrosoftOnly,       # Only collect inventory and configuration information for Microsoft products
    [string] $AdditionalMicrosoftFilter = "",
    [ValidateSet("BC","SPLA","SAM","SQL","General")]
    [string] $ScriptRegime = "General",
    [string] $OperatingSystem = "",
    [datetime] $LastADLogon,
    [switch] $AddComputerNameAsFilePrefix,
    [switch] $Verbose)


$ScriptDescription =       "Windows Inventory Scan"
$ScriptVersion =           "5.0.10"
$ConnectivityTestPorts =   @(22, 80, 135, 139, 443, 445, 1433, 3389, 5985, 5986)


#region Logging
$script:OutFileSupportsNoNewLine = $false;
function InitialiseLogFile {

    if (!($script:OutputFolder)) {
        $script:OutputFolder = ".\"
    }

    if (!(Test-Path $script:OutputFolder)) {
        New-Item -ItemType Directory -Path $script:OutputFolder | Out-Null
    }

    $script:OutputFolder = Resolve-Path $script:OutputFolder | Select-Object -ExpandProperty Path

    if (!($script:OutputFolder.EndsWith('\'))) {
        $script:OutputFolder += '\'
    }

    if ($AddComputerNameAsFilePrefix) {
        $OutputFilePrefix = $OutputFilePrefix + $ComputerName + "_"
    }

    if ($script:OutputFolder -and !($LogFile -like "*\*")) {
        $script:LogFile = Join-Path $script:OutputFolder "$($OutputFilePrefix)$LogFile"
    }

    if ($LogFile -and (Test-Path $LogFile)) {
        Remove-Item $LogFile
    }

    if ((Get-Command "Out-File").parameters["NoNewline"]) {
        $script:OutFileSupportsNoNewLine = $true;
    }

    PrefixOutputFilesWithFolder
    DecryptPassword
}

function PrefixOutputFilesWithFolder {
    
    # Check if $OutputFolder exists and is not empty
    if ($script:OutputFolder) {
        $counter = 1
        while ($true) {
            $outputFileVarName = "OutputFile$counter"
            # Check if the OutputFile variable exists
            if (Get-Variable -Name $outputFileVarName -Scope Script -ErrorAction SilentlyContinue) {
                # Get the value of the OutputFile variable
                $outputFileValue = Get-Variable -Name $outputFileVarName -ValueOnly -Scope Script
                # Check if it does not contain a backslash, and if so, prefix with OutputFolder
                if (-not $outputFileValue.Contains("\"))
                {
                    Set-Variable -Name $outputFileVarName -Value (Join-Path $script:OutputFolder "$($OutputFilePrefix)$outputFileValue") -Scope Script
                }
                $counter++
            } else {
                # Exit loop if the variable does not exist
                break
            }
        }
    }
} 

function LogText {
    param(
        [Parameter(Position=0, ValueFromRemainingArguments=$true, ValueFromPipeline=$true)]
        [Object] $Object,
        [System.ConsoleColor]$Color = [System.Console]::ForegroundColor,
        [switch]$NoNewLine = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"
    )

    if ($LogTo -ne "File") {
        # Display text on screen
        Write-Host -Object $Object -ForegroundColor $Color -NoNewline:$NoNewLine
    }
    
    if ($LogTo -ne "Console") {
        if ($LogFile) {
            if ($script:OutFileSupportsNoNewLine) {
                $Object | Out-File $LogFile -Encoding utf8 -Append -NoNewline:$NoNewLine 
            }
            else {
                $Object | Out-File $LogFile -Encoding utf8 -Append 
            }
        }
    }
}

function LogTimeAndText {
    param(
        [string] $Text,
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Blue,
        [switch]$IncludeDate = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    $output = "";
    if ($IncludeDate) {
        $output = Get-Date -Format "yyyy-MM-dd HH:mm:ss.ff"
    } else {
        $output = Get-Date -Format "HH:mm:ss.ff"
    }

    $output += " - "
    $output += $Text
    LogText $output -Color $Color -LogTo $LogTo
}

function LogError([string[]]$errorDescription){
    if ($Verbose){
        LogText ""
    }

    $output = $errorDescription -join "`r`n              "
    LogTimeAndText $output -Color Red

    Start-Sleep -s 3
}

function LogLastException() {
    $currentException = $Error[0].Exception;

    while ($currentException)
    {
        LogText -Color Red $currentException
        LogText -Color Red $currentException.Data
        LogText -Color Red $currentException.HelpLink
        LogText -Color Red $currentException.HResult
        LogText -Color Red $currentException.Message
        LogText -Color Red $currentException.Source
        LogText -Color Red $currentException.StackTrace
        LogText -Color Red $currentException.TargetSite

        $currentException = $currentException.InnerException
    }

    Start-Sleep -s 3
}

function RecordCriticalScanException([string]$Source) {
    $ResultsSummary.CriticalScanError = $true
    $ResultsSummary.CriticalScanErrorMessage += "$($Source): $($Error[0].Exception.ToString()) `r`n" 
}

$script:MostRecentActivity = ""
function LogProgress([string]$Activity, [string]$Status, [Int32]$PercentComplete, [switch]$Completed ){
    
    if ($Activity) {
        $script:MostRecentActivity = $Activity
    } else {
        if ($script:MostRecentActivity) {
            $Activity = $script:MostRecentActivity
        } else {
            $Activity = "Unspecified"
        }
    }
    Write-Progress -activity $Activity -Status $Status -percentComplete $PercentComplete -Completed:$Completed
    LogTimeAndText $Status
}

function GetScriptPath
{
    if($PSCommandPath){
        return $PSCommandPath; }
        
    if($MyInvocation.ScriptName){
        return $MyInvocation.ScriptName }
        
    if($script:MyInvocation.MyCommand.Path){
        return $script:MyInvocation.MyCommand.Path }

    return $script:MyInvocation.MyCommand.Definition
}

function GetDotNetFrameworkVersion {
    #$release = Get-ItemPropertyValue -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release
    $regKey = Get-Item -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    $release = $regKey.GetValue("Release")
    switch ($release) {
        { $_ -ge 533320 } { $version = "4.8.1 or later ($release)"; break }
        { $_ -ge 528040 } { $version = "4.8 ($release)"; break }
        { $_ -ge 461808 } { $version = "4.7.2 ($release)"; break }
        { $_ -ge 461308 } { $version = "4.7.1 ($release)"; break }
        { $_ -ge 460798 } { $version = "4.7 ($release)"; break }
        { $_ -ge 394802 } { $version = "4.6.2 ($release)"; break }
        { $_ -ge 394254 } { $version = "4.6.1 ($release)"; break }
        { $_ -ge 393295 } { $version = "4.6 ($release)"; break }
        { $_ -ge 379893 } { $version = "4.5.2 ($release)"; break }
        { $_ -ge 378675 } { $version = "4.5.1 ($release)"; break }
        { $_ -ge 378389 } { $version = "4.5 ($release)"; break }
        default { $version = $null; break }
    }

    return $version
}

function LogEnvironmentDetails ([string[]] $OtherDetails){

    $script:ScriptPath = GetScriptPath
    $script:ScriptName = split-path $ScriptPath -leaf

    LogText " "
    LogHeaderText -FrameLine 
    LogHeaderText -LeftText " _______     __" -LeftColor Yellow
    LogHeaderText -LeftText "|  ___\ \   / /" -LeftColor Yellow
    LogHeaderText -LeftText "| |__  \ \_/ / " -LeftColor Yellow
    LogHeaderText -LeftText "|  __|  \   /  " -LeftColor Yellow
    LogHeaderText -LeftText "| |____  | |   " -LeftColor Yellow -RightText "$ScriptDescription  "
    LogHeaderText -LeftText "|______| |_|   " -LeftColor Yellow -RightText "Version $ScriptVersion  "
    LogHeaderText
    LogHeaderText -FrameLine 

    LogText " "
    LogText " $ScriptName" -Color Green 
    LogText " "

    if ($PSVersionTable.PSVersion.Major -ge 3) {
        $oSDetails = Get-CimInstance -ClassName Win32_OperatingSystem
    } else {
        $oSDetails = Get-WmiObject -Class Win32_OperatingSystem
    }
    $elevated = [bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")
    $currentThread = [System.Threading.Thread]::CurrentThread
    $dotNetFrameworkVersion = GetDotNetFrameworkVersion
    LogText -Color Gray "Computer Name:          $($env:COMPUTERNAME)"
    LogText -Color Gray "User Name:              $($env:USERNAME)@$($env:USERDNSDOMAIN)"
    LogText -Color Gray "Windows Version:        $($oSDetails.Caption)($($oSDetails.Version))"
    LogText -Color Gray "Memory kB:              $($oSDetails.TotalVisibleMemorySize.ToString("N0")) ($($oSDetails.FreePhysicalMemory.ToString("N0")) Free)"
    LogText -Color Gray "Locale:                 $($oSDetails.Locale) (Language $($oSDetails.OSLanguage))"
    LogText -Color Gray "PowerShell Host:        $($host.Version.Major)"
    LogText -Color Gray "PowerShell Version:     $($PSVersionTable.PSVersion)"
    LogText -Color Gray "PowerShell Word Size:   $($([IntPtr]::size) * 8) bit"
    LogText -Color Gray "Script Path:            $ScriptPath"
    LogText -Color Gray "Working Directory:      $PWD"
    LogText -Color Gray "CLR Version:            $($PSVersionTable.CLRVersion)"
    LogText -Color Gray ".Net Framework Version: $dotNetFrameworkVersion"
    LogText -Color Gray "Elevated:               $elevated"
    LogText -Color Gray "Current Date Time:      $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
    LogText -Color Gray "Default Date Format:    $($CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern)"
    LogText -Color Gray "Current Culture:        $((Get-Culture).EnglishName) (UI: $((Get-UICulture).EnglishName))"
    
    if (Test-Path "Variable:OutputFolder") {
        LogText -Color Gray "Output Folder:          $OutputFolder" 
    }
    if (Test-Path "Variable:OutputFile1") {
        LogText -Color Gray "Output File 1:          $OutputFile1" 
    }
    if (Test-Path "Variable:LogFile") {
        LogText -Color Gray "Log File:               $LogFile" 
    }
    if (Test-Path "Variable:ComputerName") {
        LogText -Color Gray "Target Computer Name:   $ComputerName" 
    }
    if (Test-Path "Variable:UserName") {
        LogText -Color Gray "Script User Name:       $UserName"
    }
    if (Test-Path "Variable:MicrosoftOnly") {
        LogText -Color Gray "Microsoft Only:         $MicrosoftOnly"
    }
    if (Test-Path "Variable:TargetType") {
        LogText -Color Gray "Target Type:            $TargetType"
    }
    if (Test-Path "Variable:ScriptRegime") {
        LogText -Color Gray "Script Regime:          $ScriptRegime"
    }
    if (Test-Path "Variable:RequiredData") {
        LogText -Color Gray "Required Data:          $RequiredData"
    }

    foreach ($detail in $OtherDetails){
        LogText -Color Gray $detail
    }

    LogText -Color Gray ""

}

function LogHeaderText {
    param(
        [string] $LeftText = " ",
        [System.ConsoleColor]$LeftColor = [System.ConsoleColor]::Blue,
        [string] $RightText,
        [System.ConsoleColor]$RightColor = [System.ConsoleColor]::DarkGray,
        [char] $FrameChar = "#",
        [switch] $FrameLine,
        [switch] $LeftAlignRightText,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    if ($FrameLine) {
        $strFullText = "  " + ($FrameChar.ToString() * 69)
        LogText $strFullText -Color DarkGray -LogTo $LogTo
        return
    }

    $strLeftFrame = "  $FrameChar  "
    $strLeftText = $LeftText
    $strRightText = $RightText
    $strRightFrame = "  $FrameChar"
    if ($LeftAlignRightText) {
        $strRightText = $RightText.PadRight(63 - $LeftText.Length)
    } else {
        $strLeftText = $LeftText.PadRight(63 - $RightText.Length)
    }
    

    if ($LogTo -eq "Console" -or $LogTo -eq "Both") {
        LogText $strLeftFrame -LogTo "Console" -NoNewLine -Color DarkGray
        LogText $strLeftText -LogTo "Console" -NoNewLine -Color $LeftColor
        LogText $strRightText -LogTo "Console" -NoNewLine -Color $RightColor
        LogText $strRightFrame -LogTo "Console" -Color DarkGray
    }

    if ($LogTo -eq "File" -or $LogTo -eq "Both") {
        $strFullText = $strLeftFrame + $strLeftText + $strRightText + $strRightFrame
        LogText $strFullText -LogTo "File" 
    }
}

function DecryptPassword {
    $strOneTimePassword = "%OneTimePassword%" # Replace this with the one-time password
    if ($SecurePassword) {
        $baOneTimePassword = [System.Convert]::FromBase64String($strOneTimePassword)
        $baSecurePassword = [System.Convert]::FromBase64String($SecurePassword)
        for($i=0; $i -lt $baSecurePassword.count ; $i++)
        {
            $baSecurePassword[$i] = $baSecurePassword[$i] -bxor $baOneTimePassword[$i%$baOneTimePassword.Length]
        }
        $script:Password = [System.Text.Encoding]::Unicode.GetString($baSecurePassword);
    }
}
#endregion

#region Setup Output Formats
function SetupOutputFormats {
    # Standardise date/time output to ISO 8601'ish format
    $bOutputFormatsUpdated = $false
    $currentThread = [System.Threading.Thread]::CurrentThread
    $desiredShortPattern = 'yyyy-MM-dd'
    $desiredLongPattern = 'yyyy-MM-dd HH:mm:ss'

    try {
        $cultureInvariant = [CultureInfo]::InvariantCulture.Clone()
        $cultureInvariant.DateTimeFormat.ShortDatePattern = $desiredShortPattern
        $cultureInvariant.DateTimeFormat.LongDatePattern = $desiredLongPattern
        $cultureInvariant.NumberFormat.NumberGroupSeparator = ""  
        $cultureInvariant.NumberFormat.NumberDecimalSeparator = "."
        $currentThread.CurrentCulture = $cultureInvariant
        $bOutputFormatsUpdated = $true
    }
    catch {
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $currentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $currentThread.CurrentCulture.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $currentThread.CurrentCulture.NumberFormat.NumberGroupSeparator = ""  
            $currentThread.CurrentCulture.NumberDecimalSeparator = "."
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $cultureCopy = $currentThread.CurrentCulture.Clone()
            $cultureCopy.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $cultureCopy.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $cultureCopy.NumberFormat.NumberGroupSeparator = ""  
            $cultureCopy.NumberDecimalSeparator = "."
            $currentThread.CurrentCulture = $cultureCopy
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread using clone of current culture"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        LogText "Failed to update output formats"
    }
}
#endregion

#region Query User
function QueryUser([string]$Message, [string]$Prompt, [switch]$AsSecureString = $false, [string]$DefaultValue){
    $strResult = ""
    
    if ($Message) {
        LogText $Message -color Yellow
    }

    if ($DefaultValue) {
        $Prompt += " (Default [$DefaultValue])"
    }

    $Prompt += ": "
    LogText $Prompt -color Yellow -NoNewLine
    
    if ($Headless) {
        LogText " (Headless - Using Default Value)" -color Yellow
    }
    else {
        $strResult = Read-Host -AsSecureString:$AsSecureString
    }

    if(!$strResult -or ($strResult.Length -eq 0)) {
        $strResult = $DefaultValue
        if ($AsSecureString) {
            $strResult = ConvertTo-SecureString $strResult -AsPlainText -Force
        }
    }

    return $strResult
}

function Get-ConsoleCredential([String] $Message, [String] $DefaultUsername, [switch] $AsPSCredential)
{
    $strUsername = QueryUser -Message $Message -Prompt "Username" -DefaultValue $DefaultUsername
    if (!$strUsername){
        return $null
    }

    $strSecurePassword = QueryUser -Prompt "Password" -AsSecureString
    if (!$strSecurePassword){
        return $null
    }

    if ($AsPSCredential) {
        $Creds = New-Object System.Management.Automation.PSCredential ($strUsername, $strSecurePassword)
    } else {
        $Creds = New-Object PSObject

        $bstrSecurePassword = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($strSecurePassword)
        $strUnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstrSecurePassword)

        $Creds | Add-Member -MemberType NoteProperty -Name "UserName" -Value $strUsername
        $Creds | Add-Member -MemberType NoteProperty -Name "Password" -Value $strUnsecurePassword
    }

    return $Creds
}
#endregion

#region Test Connection
$script:ConnectionDetails = [PSCustomObject][ordered]@{
    TargetName = ""
    ComputerName = ""
    ComputerDomain = ""
    IPAddress0 = ""
    NameResolution = [Nullable[bool]]$null
    Ping = [Nullable[bool]]$null
    PortSSH = [Nullable[bool]]$null
    PortHTTP = [Nullable[bool]]$null
    PortWMI = [Nullable[bool]]$null
    PortSMB1 = [Nullable[bool]]$null
    PortHTTPS = [Nullable[bool]]$null
    PortSMB2 = [Nullable[bool]]$null
    PortSQL = [Nullable[bool]]$null
    PortRDP = [Nullable[bool]]$null
    PortWinRM = [Nullable[bool]]$null
    PortWinRMS = [Nullable[bool]]$null 
    OtherPorts = @{}
    Error = ""
    ErrorDetails = ""
    CimConnectionType = $null
    CimSession = $null
    PSSession = $null
    HKLM = $null
    HKU = $null
}

function TestConnectivity {
    param(
        [string] $Target,
        [int[]] $Ports = @(22, 80, 135, 139, 443, 445, 1433, 3389, 5985, 5986)
    )

    $ConnectionDetails.TargetName = $Target
    $ConnectionDetails.ComputerName = $Target

    # Test name resolution
    LogText "Name Resolution: " -NoNewLine -Color Gray
    $ConnectionDetails.NameResolution = $false;
    try {
        $nameResolutionResult = [System.Net.Dns]::GetHostAddresses($Target)
        if ($nameResolutionResult.Count -gt 0) {
            $ConnectionDetails.IPAddress0 = $nameResolutionResult[0].IPAddressToString
            $ConnectionDetails.NameResolution = $true;
        }
    } catch {}
    
    if ($ConnectionDetails.NameResolution) {
        LogText "Succeeded" -Color Green
    } else {
        LogText "Failed" -Color Red
        return;
    }
    
    # Test Ping
    LogText "Ping: " -NoNewLine -Color Gray
    $ConnectionDetails.Ping = $false;
    try {
        $pingResult = Test-Connection -ComputerName $Target -Count 1 -ErrorAction SilentlyContinue
        if ($pingResult.StatusCode -eq 0) {
            $ConnectionDetails.Ping = $true
        } else {
            $ConnectionDetails.Ping = $false
        }
    } catch {}
    
    if ($ConnectionDetails.Ping) {
        LogText "Succeeded" -Color Green
    } else {
        LogText "Failed" -Color Red
    }
    
    # Test Ports
    LogText "Port Scan: " -NoNewLine -Color Gray

    $sockets = @()
    $asyncResults = @()

    # Start connections
    foreach ($port in $Ports) {
        $socket = New-Object System.Net.Sockets.TcpClient
        $sockets += $socket

        $asyncResult = $socket.BeginConnect($Target, $port, $null, $null)
        $asyncResults += $asyncResult
    }

    # Wait for 2 seconds or until all sockets have connected
    $timeout = 2000
    $endTime = (Get-Date).AddMilliseconds($timeout)

    foreach ($asyncResult in $asyncResults) {
        $remainingTime = ($endTime - (Get-Date)).TotalMilliseconds
        if ($remainingTime -le 0) {
            break
        }
        $asyncResult.AsyncWaitHandle.WaitOne($remainingTime) | Out-Null
    }

    # Check the status of each socket
    for ($i = 0; $i -lt $sockets.Count; $i++) {
        $socket = $sockets[$i]
        $port = $ports[$i]

        switch ($port) {
            22 {
                $ConnectionDetails.PortSSH = $socket.Connected
            }
            80 {
                $ConnectionDetails.PortHTTP = $socket.Connected
            }
            135 {
                $ConnectionDetails.PortWMI = $socket.Connected
            }
            139 {
                $ConnectionDetails.PortSMB1 = $socket.Connected
            }
            443 {
                $ConnectionDetails.PortHTTPS = $socket.Connected
            }
            445 {
                $ConnectionDetails.PortSMB2 = $socket.Connected
            }
            1433 {
                $ConnectionDetails.PortSQL = $socket.Connected
            }
            3389 {
                $ConnectionDetails.PortRDP = $socket.Connected
            }
            5985 {
                $ConnectionDetails.PortWinRM = $socket.Connected
            }
            5986 {
                $ConnectionDetails.PortWinRMS = $socket.Connected
            }
            default {
                $ConnectionDetails.OtherPorts.Add($port, $socket.Connected)
            }
        }

        # Close the socket
        $socket.Close()
    }

    LogConnectionResult -PortName "SSH" -Result $ConnectionDetails.PortSSH;
    LogConnectionResult -PortName "HTTP" -Result $ConnectionDetails.PortHTTP;
    LogConnectionResult -PortName "WMI" -Result $ConnectionDetails.PortWMI;
    LogConnectionResult -PortName "SMB" -Result $ConnectionDetails.PortSMB1;
    LogConnectionResult -PortName "HTTPS" -Result $ConnectionDetails.PortHTTPS;
    LogConnectionResult -PortName "SQL" -Result $ConnectionDetails.PortSQL;
    LogConnectionResult -PortName "RDP" -Result $ConnectionDetails.PortRDP;
    LogConnectionResult -PortName "WinRM" -Result $ConnectionDetails.PortWinRM;
    LogConnectionResult -PortName "WinRMS" -Result $ConnectionDetails.PortWinRMS;
    LogText ""

    # OtherPorts
}

function LogConnectionResult {
    param(
        [string] $PortName,
        $Result
    )

    if ($null -eq $Result) {
        return;
    }

    $resultText = "Failed"
    $colour = [System.ConsoleColor]::Yellow;
    if ($Result) {
        $resultText = "Succeeded"
        $colour = [System.ConsoleColor]::Green;
    }

    LogText "$PortName " -NoNewLine -Color $colour -LogTo Console
    LogText "$($PortName): $resultText"  -LogTo File
}
#endregion

#region Connect To Computer
function ConnectToComputer ($ComputerName) {

    try {
        LogTimeAndText "Connecting to $ComputerName"

        if ($UserName -and -not $Password) {
            $creds = Get-ConsoleCredential -DefaultUsername $UserName
            if (!($creds) -or !($creds.Password)) {
                LogError "Password Required"
                return $false
            }

            $script:Password = $creds.Password
        } 

        TestConnectivity -Target $ComputerName -Ports $ConnectivityTestPorts

        if ($ConnectionDetails.NameResolution -eq $false) {
            $ConnectionDetails.ErrorDetails = "Device name could not be resolved"
            $ConnectionDetails.Error = "Name Not Found"
            return $false
        }

        if ($ConnectionDetails.PortWinRMS) {
            # Try to connect using WinRM over https
            LogText "Connecting using WinRM over HTTPS"
            if (CreateCimAndPSSession -UseSSL) {
                $ConnectionDetails.CimConnectionType = "WinRMS"
            }
        }

        if ((!($ConnectionDetails.CimConnectionType)) -and $ConnectionDetails.PortWinRM) {
            # Try to connect using WinRM over http
            LogText "Connecting using WinRM over HTTP"
            if (CreateCimAndPSSession) {
                $ConnectionDetails.CimConnectionType = "WinRM"
            }
        }

        if ((!($ConnectionDetails.CimConnectionType)) -and $ConnectionDetails.PortWMI) {
            # Try to connect using DCOM
            LogText "Connecting using DCOM"
            if (CreateCimAndPSSession -UseDCOM) {
                $ConnectionDetails.CimConnectionType = "DCOM"
            }
        }

        if ($ConnectionDetails.PortSMB1) {
            # Try to connect to Remote Registry service
            LogText "Connecting to Remote Registry"
            ConnectToRegistry | Out-Null
        }

        if ((IsRegistryConnected) -or (IsCimConnected)) {
            # Successfully connected using 1 or more connection methods
            return $true
        }

        if (!$ConnectionDetails.Error) {

            if ($ConnectionDetails.Ping -or $ConnectionDetails.PortSSH -or $ConnectionDetails.PortHTTP -or
                $ConnectionDetails.PortWMI -or $ConnectionDetails.PortSMB1 -or $ConnectionDetails.PortHTTPS -or
                $ConnectionDetails.PortSMB2 -or $ConnectionDetails.PortSQL -or $ConnectionDetails.PortRDP -or
                $ConnectionDetails.PortWinRM -or $ConnectionDetails.PortWinRMS) {
                
                # We were able to connect on one or more ports, but not using WinRM or DCOM
                $ConnectionDetails.ErrorDetails = "Device responded, but WinRM and DCOM WMI) services were not available"
                $ConnectionDetails.Error = "Blocked By Firewall"
            } elseif ($ConnectionDetails.ErrorDetails -like "*0x800706ba*" -or 
                $ConnectionDetails.ErrorDetails -like "*The RPC server is unavailable*") {
                $ConnectionDetails.Error = "RPC Unavailable"
            } else {
                # No response from target device
                $ConnectionDetails.ErrorDetails = "The device did not respond"
                $ConnectionDetails.Error = "No Response"
            }
        }
    } catch {
        $ConnectionDetails.Error = "Unexpected Error"
        $ConnectionDetails.ErrorDetails = $Error[0].Exception.ToString()
    }
    
    LogText -Color Red "Unable to connect to $ComputerName ($($ConnectionDetails.Error))"
    LogText  "Error Details:`r`n($($ConnectionDetails.ErrorDetails))"

    return $false
}

function CreateCimAndPSSession {
    param(
        [switch] $UseSSL,
        [switch] $UseDCOM
    )

    try {
        $paramsCimOptions = @{}
        $paramsCimSession = @{}
        $paramsPSOptions = @{}
        $paramsPSSession = @{}

        if ($UseDCOM) {
            $paramsCimOptions["Protocol"] = "DCOM"
        } else {
            if ($UseSSL) {
                # $paramsCimOptions["Protocol"] = "Wsman" This is assumed for this parameter set.
                $paramsCimOptions["UseSsl"] = $true
                $paramsCimSession["Port"] = 5986

                $paramsPSSession["UseSsl"] = $true

                if ($IgnoreCertificateErrors) {
                    $paramsCimOptions["SkipCACheck"] = $true
                    $paramsCimOptions["SkipCNCheck"] = $true
                    $paramsCimOptions["SkipRevocationCheck"] = $true

                    $paramsPSOptions["SkipCACheck"] = $true
                    $paramsPSOptions["SkipCNCheck"] = $true
                    $paramsPSOptions["SkipRevocationCheck"] = $true
                } 
            } else {
                $paramsCimOptions["Protocol"] = "Wsman"
                $paramsCimSession["Port"] = 5985
            }
        }

        if ($UserName -and $Password) {
            $credential = New-Object System.Management.Automation.PSCredential -ArgumentList $Username, (ConvertTo-SecureString -String $Password -AsPlainText -Force)
            $paramsCimSession["Credential"] = $credential
            $paramsPSSession["Credential"] = $credential
        }

        $paramsCimSession["SessionOption"] = New-CimSessionOption @paramsCimOptions
        $paramsCimSession["ComputerName"] = $ComputerName
        $paramsCimSession["ErrorVariable"] = "NewSessionError"
        $paramsCimSession["ErrorAction"] = "SilentlyContinue"

        $paramsPSSession["SessionOption"] = New-PSSessionOption @paramsPSOptions
        $paramsPSSession["ComputerName"] = $ComputerName
        $paramsPSSession["ErrorVariable"] = "NewSessionError"
        $paramsPSSession["ErrorAction"] = "SilentlyContinue"

        # Splat the parameters onto New-CimSession
        $ConnectionDetails.CimSession = New-CimSession @paramsCimSession
        if (!($UseDCOM)) {
            $ConnectionDetails.PSSession = New-PSSession @paramsPSSession
        }
        
        if (!($ConnectionDetails.CimSession)) {
            $ConnectionDetails.ErrorDetails = $NewSessionError[0] | Out-String
            $ConnectionDetails.Error = "Error"

            if ($ConnectionDetails.ErrorDetails -like "*0x80070005*" -or 
                $ConnectionDetails.ErrorDetails -like "*PermissionDenied*"  -or 
                $ConnectionDetails.ErrorDetails -like "*Access is denied*") {
                $ConnectionDetails.Error = "Access Denied"
            } elseif ($ConnectionDetails.ErrorDetails -like "*0x803380e4*" -or 
                $ConnectionDetails.ErrorDetails -like "*HTTPS transport must be used*") {
                $ConnectionDetails.Error = "Untrusted Device"
            }

            return $false
        }

        # Test the connection - This could throw an exception
        $win32CS = Get-CimInstance -ClassName Win32_ComputerSystem -CimSession $ConnectionDetails.CimSession
        $ConnectionDetails.ComputerName = $win32CS.Name
        if (!([string]::IsNullOrEmpty($win32CS.Domain))) {
            $ConnectionDetails.ComputerDomain = $win32CS.Domain
        }

        return $true

    } catch {
        $ConnectionDetails.ErrorDetails = $Error[0].Exception.ToString();
        $ConnectionDetails.Error = "Exception"
    }

    return $false
}

Add-Type @"
    using System;
    using System.Runtime.InteropServices;
    public class NetworkConnection {
        [DllImport("mpr.dll")]
        public static extern int WNetAddConnection2(ref NETRESOURCE netResource,
            string password, string username, uint flags);

        [DllImport("mpr.dll")]
        public static extern int WNetCancelConnection2(string name, uint flags,
            bool force);

        [StructLayout(LayoutKind.Sequential)]
        public struct NETRESOURCE {
            public int dwScope;
            public int dwType;
            public int dwDisplayType;
            public int dwUsage;
            public string lpLocalName;
            public string lpRemoteName;
            public string lpComment;
            public string lpProvider;
        }
    }
"@

function ConnectToRegistry {
    try {

        if ($UserName -and $Password) {
            $netResource = New-Object NetworkConnection+NETRESOURCE
            $netResource.dwType = 1 # RESOURCETYPE_DISK
            $netResource.lpRemoteName = "\\$ComputerName\IPC$"
            $flags = 4 # CONNECT_TEMPORARY

            $result = [NetworkConnection]::WNetAddConnection2([ref]$netResource, $Password, $UserName, $flags)
            if ($result -ne 0) {
                LogText "Warning authenticating to Remote Registry: $result"
            }
        }

        $ConnectionDetails.HKLM = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $ComputerName)
        $ConnectionDetails.HKU = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('Users', $ComputerName)
        if ($ConnectionDetails.HKLM) {
            
            $regComputerName = ""
            $subKey = $ConnectionDetails.HKLM.OpenSubKey("SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName")
            if ($subKey) {
                $regComputerName = $subKey.GetValue("ComputerName")
                if (!($ConnectionDetails.ComputerName)) {
                    $ConnectionDetails.ComputerName = $regComputerName
                }
            }

            try {
                $regDomainName = ""
                $subKey = $ConnectionDetails.HKLM.OpenSubKey("SYSTEM\CurrentControlSet\Services\Tcpip\Parameters")
                if ($subKey) {
                    $regDomainName = $subKey.GetValue("Domain")
                    if (!([string]::IsNullOrEmpty($regDomainName))) {
                        if ([string]::IsNullOrEmpty($ConnectionDetails.ComputerDomain)) {
                            $ConnectionDetails.ComputerDomain = $regDomainName
                        }
                    }
                }
            } catch {}
            
            return $true
        }
    } catch {
        LogText "Error authenticating to Remote Registry: $($_.Exception.Message)"
        $ConnectionDetails.HKLM = $null
        $ConnectionDetails.HKU = $null
    }

    return $false
}

function IsRegistryConnected {
    return (($null -ne $ConnectionDetails.HKLM) -and ($null -ne $ConnectionDetails.HKU))
}

function IsCimConnected {
    return ($null -ne $ConnectionDetails.CimConnectionType)
}

function GetConnectionType {
    $strConnectionType = "None"

    if (IsCimConnected) {
        $strConnectionType = $ConnectionDetails.CimConnectionType
    } elseif (IsRegistryConnected) {
        $strConnectionType = "Registry"
    }

    if ($ConnectionDetails.PSSession) {
        $strConnectionType += "+"
    }

    return $strConnectionType
}
#endregion

#region Custom Export
$ScriptExcludeFields = $null
function Export-MyCsv {
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [PSCustomObject[]] $InputObject,
        [Parameter(Mandatory = $true)]
        [string] $Path,
        [switch] $Append,
        [switch] $IncludeIndex
    )

    begin {
        if ($null -eq $ScriptExcludeFields) {
            LoadExcludeFields
        }

        $fileExcludeFields = $null
        $fileID = GetFileNameFinalPart -FilePath $Path
        if ($ScriptExcludeFields.ContainsKey($fileID)) {
            $fileExcludeFields = $ScriptExcludeFields[$fileID].Split(',') | ForEach-Object { $_.Trim() }
        }

        $index = 1
        $outputData = New-Object 'System.Collections.Generic.List[object]'
    }

    process {
        foreach ($item in $InputObject) {
            
            # Create a duplicate of the item with only the required fields
            $processedItem = New-Object PSObject 
            foreach ($prop in $item.PSObject.Properties) {
                if ($null -eq $fileExcludeFields -or !$fileExcludeFields.Contains($prop.Name)) {
                    $processedItem | Add-Member -MemberType NoteProperty -Name $prop.Name -Value $prop.Value -Force
                }
            }

            # Add index if requested
            if ($IncludeIndex) {
                $processedItem | Add-Member -MemberType NoteProperty -Name 'Index' -Value $index -Force
                $index++
            }

            # Add the processed item to the list
            $outputData.Add($processedItem)
        }
    }

    end {
        # Convert the list to an array and export to CSV
        $outputData.ToArray() | Export-Csv -Path $Path -Encoding UTF8 -NoTypeInformation -Append:$Append -Delimiter ","

        # This function logs the field names and sample values of exported data to the log file and a CSV file
        # Uncomment the following line to enable this functionality
        #LogFieldInfo -InputObject $outputData -OutputFileName $fileID
        $outputData = $null
    }
}

function LoadExcludeFields {
    $script:ScriptExcludeFields = @{}

    if (!($ScriptDescription)) {
        return
    }

    # Import the CSV
    try {
        $csvData = Import-Csv -Path ".\ExcludeFields.csv" -ErrorAction SilentlyContinue
    } catch {
    }

    foreach ($row in $csvData | Where-Object { $_.Script -eq $ScriptDescription }) {
        $ScriptExcludeFields[$row.OutputFile] = $row.ExcludeFields
    }
}

function GetFileNameFinalPart {
    param (
        [string]$FilePath
    )

    # Return the last part of the filename i.e. Apps for the following values
    # c:\temp\20240102_101212_Apps.csv
    # c:\temp\Apps.csv

    # Get the filename without the extension
    $fileNameWithoutExtension = [System.IO.Path]::GetFileNameWithoutExtension($FilePath)

    # Split the filename by underscore or backslash, and take the last part
    $lastPart = ($fileNameWithoutExtension -split '[\\_]')[-1]

    return $lastPart
}

# Support function. Not currently called. The function is used for custom testing to aid the local development team where necessary
function LogFieldInfo {
    param(
        [PSCustomObject[]] $InputObject,
        [string] $OutputFileName
    )
    
    # This function logs the field names and sample values of exported data to the log file and a CSV file
    # It is not enabled by default
    if (!($InputObject) -or $InputObject.Count -eq 0) {
        return
    }

    # Creating a new array of fields and sample values
    $lstFields = @()

    $recordIndex = 1
    foreach ($record in $InputObject) {
        $fieldNames = $record.PSObject.Properties.Name
        $fieldIndex = 1

        # Iterate through each property
        foreach ($fieldName in $fieldNames) {
            # Creating a new object for each property
            $field = [PSCustomObject][ordered]@{
                ScriptFileName = $ScriptName
                ScriptDescription = $ScriptDescription
                OutputFileName = $OutputFileName
                FieldName = $fieldName
                SampleValue = $record.$fieldName
                FieldIndex = $fieldIndex++
                RecordIndex = $recordIndex
            }

            # Add new object to the array
            $lstFields += $field
        }
    
        $recordIndex++
        if ($recordIndex -gt 3) {
            break
        }
    }

    # Save the field info to log file and csv file
    $csvLines = $lstFields | ConvertTo-Csv -NoTypeInformation
    $csvString = $csvLines -join "`n"
    LogText $csvString -LogTo File
    $lstFields | export-csv -Path ".\FieldInfo.csv" -NoTypeInformation -Append -Delimiter ","
}
#endregion

#region Registry
# Define the registry hives
$HKEY_USERS = [uint32]2147483651
$HKEY_LOCAL_MACHINE = [uint32]2147483650

function GetRegSubKeys ($Hive, $Path) {
    try 
    {
        if (IsCimConnected) {
            $value = Invoke-CimMethod -Namespace "root\cimv2" -ClassName "StdRegProv" -MethodName EnumKey -CimSession $ConnectionDetails.CimSession -Arguments @{
                hDefKey = $Hive
                sSubKeyName = $Path
            }
            if ($value.ReturnValue -ne 5) {
                return $value.sNames
            }
        } elseif (IsRegistryConnected) {
    
            $hiveToUse = $ConnectionDetails.HKLM
            if ($Hive -eq $HKEY_USERS) {
                $hiveToUse = $ConnectionDetails.HKU
            }
    
            $subKey = $hiveToUse.OpenSubKey($Path)
            if ($subKey) {
                return $subKey.GetSubKeyNames()
            }
            
        }
    } catch {
    }

    $strFullPath = "HKLM:"
    if ($Hive -eq $HKEY_USERS) {
        $strFullPath = "HKU:"
    }
    $strFullPath += $Path

    LogText "Unable to read registry location $strFullPath" -Color Yellow

    return $null
}

function GetRegStringValue ($Hive, $Path, $ValueName) {
    
    try {
        if (IsCimConnected) {
            $value = Invoke-CimMethod -Namespace "root\cimv2" -ClassName "StdRegProv" -MethodName GetStringValue -CimSession $ConnectionDetails.CimSession -Arguments @{
                hDefKey = $Hive
                sSubKeyName = $Path
                sValueName = $ValueName
            }
            if ($value.ReturnValue -ne 5) {
                return $value.sValue
            }
        } elseif (IsRegistryConnected) {
            $hiveToUse = $ConnectionDetails.HKLM
            if ($Hive -eq $HKEY_USERS) {
                $hiveToUse = $ConnectionDetails.HKU
            }
    
            $subKey = $hiveToUse.OpenSubKey($Path)
            if ($subKey) {
                return $subKey.GetValue($ValueName)
            }
    
        } 
    } catch {}

    $strFullPath = "HKLM:"
    if ($Hive -eq $HKEY_USERS) {
        $strFullPath = "HKU:"
    }
    $strFullPath += "$Path\$ValueName"

    LogText "Unable to read registry string $strFullPath" -Color Yellow
    
    return $null
}

function GetRegDWORDValue ($Hive, $Path, $ValueName) {
    try {
        
        if (IsCimConnected) {
            $value = Invoke-CimMethod -Namespace "root\cimv2" -ClassName "StdRegProv" -MethodName GetDWORDValue -CimSession $ConnectionDetails.CimSession -Arguments @{
                hDefKey = $Hive
                sSubKeyName = $Path
                sValueName = $ValueName
            }
            if ($value.ReturnValue -ne 5) {
                return $value.uValue
            }
        } elseif (IsRegistryConnected) {
            $hiveToUse = $ConnectionDetails.HKLM
            if ($Hive -eq $HKEY_USERS) {
                $hiveToUse = $ConnectionDetails.HKU
            }
    
            $subKey = $hiveToUse.OpenSubKey($Path)
            if ($subKey) {
                return $subKey.GetValue($ValueName)
            }
    
        }
    } catch {}
    
    LogText "Unable to read registry DWORD $strFullPath" -Color Yellow
    return $null
}
#endregion

#region HyperV
function GetHyperVVMs {
    function New-VMRecord {
        return [PSCustomObject][ordered]@{
            FQDN = ""
            Name = ""
            GUID = ""
            Host = ""
            OSName = ""
            OSEditionId = ""
            OSVersion = ""
            CSDVersion = ""
            Description = ""
            State = ""
            StateID = ""
            State2 = ""
            CreationTime = ""
            InstallDate = ""
            OnTimeInMilliseconds = ""
            TimeOfLastStateChange = ""
            ReplicationState = ""
            IsClustered = ""
            ProductType = ""
            ProcessorArchitecture = ""
            ProcessorCount = ""
            ProcessorCount2 = ""
            HwThreadCountPerCore = ""
            MACAddresses = ""
            NetworkAddressesIPv4 = ""
            NetworkAddressesIPv6 = ""
            MemoryAssigned = ""
            SuiteMask = ""
            IntegrationServicesVersion = ""
            Note = ""
        }
    }

    # Status
    # StatusDescriptions
    
    $dictVMs = @{}

    # Initialize hashtable with mandatory parameters
    $params = @{
        Namespace   = 'root\virtualization'
        ClassName   = 'Msvm_ComputerSystem'
        ErrorAction = 'SilentlyContinue'
    }

    # Conditionally add the CimSession if it exists in $ConnectionDetails
    if ($ConnectionDetails.CimSession) {
        $params['CimSession'] = $ConnectionDetails.CimSession
    }

    $hyperVClass = Get-CimClass @params
    if ($null -eq $hyperVClass) {
        $params['Namespace'] = "root\virtualization\v2"
        $hyperVClass = Get-CimClass @params
    }

    if ($null -eq $hyperVClass) {
        Write-Host "Unable to locate Hyper-V WMI namespace" -ForegroundColor Red
    } else {
        $VMs = Get-CimInstance @params | Where-Object {($_.Caption -split " ").Length -eq 2} 
        # Example Captions - "Virtual Machine, "Máquina virtual", "Виртуальная машина"

        $params.Remove('ClassName')
        $params['ResultClassName'] = 'Msvm_KvpExchangeComponent'
        
        foreach ($vm in $VMs) {
            $vmRecord = New-VMRecord
            $vmRecord.Name = $vm.ElementName
            $vmRecord.GUID = $vm.Name
            $vmRecord.Host = $env:COMPUTERNAME
            $vmRecord.Description = $vm.Description
            $vmRecord.StateID = $vm.EnabledState
            $vmRecord.InstallDate = $vm.InstallDate
            $vmRecord.OnTimeInMilliseconds = $vm.OnTimeInMilliseconds
            $vmRecord.TimeOfLastStateChange = $vm.TimeOfLastStateChange

            switch ($vm.EnabledState) 
            {
                0        {$vmRecord.State = "Unknown"} # -> State
                2        {$vmRecord.State = "Enabled"}
                3        {$vmRecord.State = "Disabled"}
                4        {$vmRecord.State = "Shut Down"}
                6        {$vmRecord.State = "Offline"}
                32768    {$vmRecord.State = "Paused"}
                32769    {$vmRecord.State = "Suspended"}
                32770    {$vmRecord.State = "Starting"}
                32771    {$vmRecord.State = "Snapshotting"}
                32773    {$vmRecord.State = "Saving"}
                32774    {$vmRecord.State = "Stopping"}
                32776    {$vmRecord.State = "Pausing"}
                32777    {$vmRecord.State = "Resuming"}
                default  {$vmRecord.State = "Unknown"}
            }

            # Get the KVP Object
            try {
                $params['InputObject'] = $vm
                $Kvp = Get-CimAssociatedInstance @params
            }
            catch {
                Write-Host "Error retrieving info for VM $($vm.Name)" -ForegroundColor Red
                $Kvp = $null
            }

            # Convert XML to Object
            foreach($StrDataItem in $Kvp.GuestIntrinsicExchangeItems)
            {
                $XmlDataItem = [xml]($StrDataItem)
                $AttributeName = $XmlDataItem.Instance.Property | Where-Object {$_.Name -eq "Name"}
                $AttributeValue = $XmlDataItem.Instance.Property | Where-Object{$_.Name -eq "Data"}
            
                switch -exact ($AttributeName.Value)
                {
                    "FullyQualifiedDomainName"    {$vmRecord.FQDN = $AttributeValue.Value; break;} 
                    "OSName"                      {$vmRecord.OSName = $AttributeValue.Value; break;}
                    "OSVersion"                   {$vmRecord.OSVersion = $AttributeValue.Value; break;}
                    "CSDVersion"                  {$vmRecord.CSDVersion = $AttributeValue.Value; break;}
                    "ProductType"                 {$vmRecord.ProductType = $AttributeValue.Value; break;}
                    "NetworkAddressIPv4"          {$vmRecord.NetworkAddressesIPv4 = $AttributeValue.Value; break;}
                    "NetworkAddressIPv6"          {$vmRecord.NetworkAddressesIPv6 = $AttributeValue.Value; break;}
                    "OSEditionId"                 {$vmRecord.OSEditionId = $AttributeValue.Value; break;}
                    "ProcessorArchitecture"       {$vmRecord.ProcessorArchitecture = $AttributeValue.Value; break;}
                    "SuiteMask"                   {$vmRecord.SuiteMask = $AttributeValue.Value; break;}        
                }
            }

            $dictVMs[$vmRecord.GUID] = $vmRecord
        }
    }
    
    if (Get-Module -Name "Hyper-V" -ListAvailable) {
        if (!(Get-Module -Name "Hyper-V")) {
            Import-Module -Name "Hyper-V"
        }

        foreach ($vm in Get-VM) {

            if ($dictVMs.ContainsKey(($vm.VMId).Guid)) {
                $vmRecord = $dictVMs[($vm.VMId).Guid]
            } else {
                $vmRecord = New-VMRecord
                $vmRecord.GUID = ($vm.VMId).Guid
                $dictVMs[$vmRecord.GUID] = $vmRecord
            }

            $networkAddressesIPv4 = ($vm.NetworkAdapters | ForEach-Object {
                $_.IPAddresses | Where-Object { $_ -match '^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$'}}) -join ', '

            $networkAddressesIPv6 = ($vm.NetworkAdapters | ForEach-Object {
                $_.IPAddresses | Where-Object { $_ -match '^([0-9a-fA-F]{0,4}:){1,7}[0-9a-fA-F]{0,4}$'}}) -join ', '

            # Note
            $vmRecord.Name = $vm.Name
            $vmRecord.State2 = $vm.State
            $vmRecord.ReplicationState = $vm.ReplicationState
            $vmRecord.MemoryAssigned = $vm.MemoryAssigned
            $vmRecord.IntegrationServicesVersion = $vm.IntegrationServicesVersion
            $vmRecord.Host = $vm.ComputerName
            $vmRecord.CreationTime = $vm.CreationTime
            $vmRecord.IsClustered = $vm.IsClustered
            $vmRecord.ProcessorCount = $vm.ProcessorCount
            if ($networkAddressesIPv4) {
                $vmRecord.NetworkAddressesIPv4 = $networkAddressesIPv4
            }
            if ($networkAddressesIPv6) {
                $vmRecord.NetworkAddressesIPv6 = $networkAddressesIPv6
            }
            $vmRecord.MACAddresses = ($vm.NetworkAdapters | Select-Object -expand MacAddress) -join ', '
            $vmRecord.Note = $vm.Note

    
            $proc = $vm | Get-VMProcessor
            if ($proc) {
                $vmRecord.ProcessorCount2 = $proc.Count
                $vmRecord.HwThreadCountPerCore = $proc.HwThreadCountPerCore
            }
        }
    }

    return $dictVMs.Values | Sort-Object Name
}

function GetHyperVHosts {
    if (Get-Module -Name "Hyper-V" -ListAvailable) {
        if (!(Get-Module -Name "Hyper-V")) {
            Import-Module -Name "Hyper-V"
        }

        Get-VMHost -ComputerName $using:ComputerName | 
            Select-Object -Property Name, LogicalProcessorCount, MacAddressMinimum, MacAddressMaximum, VirtualMachineMigrationEnabled, FullyQualifiedDomainName | Sort-Object Name
    }
}

function GetModule {
    return Get-Module -ListAvailable | Where-Object { $_.Name -eq 'Hyper-V' }
}

function GetHyperVVMsAndHosts () {
    param(
        [string] $VMFile,
        [string] $HostFile
    )
    
    if ($ConnectionDetails.PSSession) {
        $moduleAvailable = Invoke-Command -Session $ConnectionDetails.PSSession ${Function:GetModule}
        if (!($moduleAvailable)) {
            LogError "Hyper-V PowerShell module not available"
            return
        }

        LogText "Getting Hyper-V VM info (Using PSSession)"
        $vms = Invoke-Command -Session $ConnectionDetails.PSSession ${Function:GetHyperVVMs}

        LogText "Getting Hyper-V Host info (Using PSSession)"
        $hosts = Invoke-Command -Session $ConnectionDetails.PSSession ${Function:GetHyperVHosts}
        
    } else {
        LogText "Getting Hyper-V VM info"
        $vms = GetHyperVVMs
        
        LogText "Getting Hyper-V Host info"
        $hosts = GetHyperVHosts
    }

    if ($MicrosoftOnly) {
        $vms = $vms | Where-Object {
            [string]::IsNullOrWhiteSpace($_.OSName) -or $_.OSName -like "*Windows*"
        }
    }

    if ($TargetType -eq "Servers") {
        $vms = $vms | Where-Object { [string]::IsNullOrWhiteSpace($_.OSName) -or $_.OSName -like "*Server*" }
    } elseif ($TargetType -eq "Clients") {
        $vms = $vms | Where-Object { [string]::IsNullOrWhiteSpace($_.OSName) -or -not ($_.OSName -like "*Server*") }
    }

    $vms | Export-MyCsv -Path $VMFile -IncludeIndex
    $hosts | Export-MyCsv -Path $HostFile -IncludeIndex
}
#endregion

$script:ResultsSummary = @{
    StartTime                   = Get-Date
    OperatingSystem             = ""
    OperatingSystemVersion      = ""
    SoftwareRecordsTotal        = -1
    SoftwareRecords             = -1
    WindowsServices             = -1
    SoftwareLicenseRecords      = -1
    MSIInstallerEvents          = -1
    LogonEvents                 = -1
    RunningProcesses            = -1
    AccessGroupMembers          = -1
    UserProfiles                = -1
    HyperVInstalled             = -1
    ClusteringInstalled         = -1
    ScanMethod                  = ""
    CriticalScanError           = $false
    CriticalScanErrorMessage    = ""
}

function Get-ComputerInventory() {
    
    try {
        InitialiseLogFile
        SetupOutputFormats
        LogEnvironmentDetails

        if (!(ConnectToComputer -ComputerName $ComputerName)) {
            LogSummary
            return -1
        }

        if (!(GetSystemInfo)) {
            LogSummary
            return -1
        }

        GetInstalledSoftware
        GetServices
        GetSQLServerDetails
        
        if (IsCimConnected) {

            GetClusterInfo

            if ($ScriptRegime -ne "SQL") { 
                GetSoftwareLicenseInfo 
                GetMSIInstallerEvents
                GetLogonEvents
                GetComputerLogons
                GetUserProfiles
                GetDNSRecords
                GetHyperVDetails
                GetAccessGroupsMembers
            }
            if (($ScriptRegime -eq "GENERAL") -or ($ScriptRegime -eq "SAM")) {
                ##GetDiskDetails
                ##GetHotFixes
            }
            if (($ScriptRegime -eq "GENERAL") -or ($ScriptRegime -eq "SAM") -or ($ScriptRegime -eq "BC")) {
                GetIPAddresses
            }
            if (($ScriptRegime -eq "GENERAL") -or ($ScriptRegime -eq "SQL") -or ($ScriptRegime -eq "BC")) {
                GetProcesses
            }
        }
        
        LogSummary
        
        LogTimeAndText "Inventory Collection ($ComputerName) Completed"

        return 0

    }
    catch {
        LogLastException
    }
}

function GetSystemInfo {

    try {
        LogTimeAndText  "Getting System Info"

        $SystemInfo = [PSCustomObject][ordered]@{
            ComputerName                   = $ConnectionDetails.TargetName
            Name                           = ""
            Caption                        = ""
            ##TypeDescription                = ""
            ##BuildNumber                    = ""
            FullVersion                    = ""
            ##ServicePack                    = ""
            ComputerDomain                 = ""
            ##TotalPhysicalMemory            = ""
            Model                          = ""
            Manufacturer                   = ""
            BiosManufacturer               = ""
            ProcessorName                  = ""
            ##MaxSpeed                     = ""
            ProcessorCount                 = 0
            TotalCoreCount                 = 0
            TotalLogicalProcessorCount     = 0
            ProcessorCountStatusEnabled    = 0
            ##ProcessorCountStatusDisabled = 0
            ##ProcessorCountStatusOther    = 0
            ProcessorInfoStatus            = ""
            ScanTime                       = $ResultsSummary.StartTime
            BIOSDate                       = ""
            InstallDate                    = ""
            LastBootUpTime                 = ""
            LocalDateTime                  = ""
            ADInstalled                    = -1
            IISInstalled                   = -1
            RDSInstalled                   = -1
            HyperVInstalled                = -1
            ClusteringInstalled            = -1
            ScriptName                     = $ScriptName
            ScriptVersion                  = $ScriptVersion
            ConnectionType                 = GetConnectionType
        }

        if (IsCimConnected) {
            # Get OS information using the CIM session
            LogText "Querying Win32_OperatingSystem"
            $win32OS = Get-CimInstance -ClassName Win32_OperatingSystem -CimSession $ConnectionDetails.CimSession

            $bIsServer = $win32OS.Caption -ilike "*server*"

            if ($bIsServer -and $TargetType -eq "Clients") {
                LogText -Color Yellow "$($ConnectionDetails.TargetName) will not be scanned because it is a Windows Server"
                return $false
            } elseif (!$bIsServer -and $TargetType -eq "Servers") {
                LogText -Color Yellow "$($ConnectionDetails.TargetName) will not be scanned because it is a Windows Client"
                return $false
            }

            # Get computer & BIOS information using the CIM session
            LogText "Querying Win32_ComputerSystem"
            $win32CS = Get-CimInstance -ClassName Win32_ComputerSystem -CimSession $ConnectionDetails.CimSession

            LogText "Querying Win32_BIOS"
            $win32BIOS = Get-CimInstance -ClassName Win32_BIOS -CimSession $ConnectionDetails.CimSession

            $SystemInfo.Name = $win32OS.CSName
            $SystemInfo.Caption = $win32OS.Caption
            ##$SystemInfo.TypeDescription = $win32OS.OtherTypeDescription
            ##$SystemInfo.BuildNumber = $win32OS.BuildNumber
            $SystemInfo.FullVersion = $win32OS.Version
            ##$SystemInfo.ServicePack = $win32OS.CSDVersion

            $SystemInfo.ComputerDomain = $win32CS.Domain
            if ([string]::IsNullOrEmpty($SystemInfo.ComputerDomain)) {
                $SystemInfo.ComputerDomain = $ConnectionDetails.ComputerDomain
            }
            ##$SystemInfo.TotalPhysicalMemory = "$([math]::Round($win32CS.TotalPhysicalMemory / 1MB)) MB"
            $SystemInfo.Model = $win32CS.Model
            $SystemInfo.Manufacturer = $win32CS.Manufacturer
            
            $SystemInfo.BiosManufacturer = $win32BIOS.Manufacturer

            # Get CPU information using the CIM session
            LogText "Querying Win32_Processor"
            $lstCPUs = Get-CimInstance -ClassName Win32_Processor -CimSession $ConnectionDetails.CimSession

            if (!($lstCPUs)) {
                $SystemInfo.ProcessorInfoStatus = "No CPU information available"
            } else {
                $processorCount = 0
                $processorCountStatusEnabled = 0
                $processorCountStatusDisabled = 0
                $processorCountStatusOther = 0
                $coresPerProcessor = 0
                $logicalProcessorsPerProcessor = 0

                foreach($cpu in $lstCPUs) {
                    $SystemInfo.ProcessorName = $cpu.Name.Trim()
                    ##$SystemInfo.MaxSpeed = $cpu.MaxClockSpeed

                    switch ($cpu.StatusInfo ) {
                        "3" { $processorCountStatusEnabled++ }
                        "4" { $processorCountStatusDisabled++ }
                        default { $processorCountStatusOther++ }
                    }

                    $coresPerProcessor = $cpu.NumberOfCores
                    $logicalProcessorsPerProcessor = $cpu.NumberOfLogicalProcessors

                    if (($null -eq $cpu.StatusInfo) -or ($null -eq $coresPerProcessor) -or ($null -eq $logicalProcessorsPerProcessor)) {
                        $SystemInfo.ProcessorInfoStatus = "Warning: Old WMI"
                    }

                    $processorCount++
                }

                $SystemInfo.ProcessorCount = $processorCount
                $SystemInfo.TotalCoreCount = $processorCount * $coresPerProcessor
                $SystemInfo.TotalLogicalProcessorCount = $processorCount * $logicalProcessorsPerProcessor
                ##$SystemInfo.ProcessorCountStatusEnabled = $processorCountStatusEnabled
                ##$SystemInfo.ProcessorCountStatusDisabled = $processorCountStatusDisabled
                ##$SystemInfo.ProcessorCountStatusOther = $processorCountStatusOther
            }

            if ($ScriptRegime -ne "SQL") { 

                $SystemInfo.BIOSDate = $win32BIOS.ReleaseDate.ToString("yyyy-MM-dd")
                $SystemInfo.InstallDate = $win32OS.InstallDate.ToString("yyyy-MM-dd")
                $SystemInfo.LastBootUpTime = $win32OS.LastBootUpTime.ToString("yyyy-MM-dd")
                $SystemInfo.LocalDateTime = $win32OS.LocalDateTime.ToString("yyyy-MM-dd")


                # Get server feature information using the CIM session
                LogText "Querying Win32_ServerFeature"
                $win32ServerFeatures = Get-CimInstance -ClassName Win32_ServerFeature -CimSession $ConnectionDetails.CimSession -ErrorAction SilentlyContinue

                if ($win32ServerFeatures) {
                    $SystemInfo.ADInstalled = 0
                    $SystemInfo.IISInstalled = 0
                    $SystemInfo.RDSInstalled = 0
                    $SystemInfo.HyperVInstalled = 0
                    $ResultsSummary.HyperVInstalled = 0
                    $SystemInfo.ClusteringInstalled = 0
                    $ResultsSummary.ClusteringInstalled = 0

                    foreach ($feature in $win32ServerFeatures) {
                        switch ($feature.ID) {
                            2  { $SystemInfo.IISInstalled = 1 }
                            10 { $SystemInfo.ADInstalled = 1 }
                            18 { $SystemInfo.RDSInstalled = 1 }
                            20 { $SystemInfo.HyperVInstalled = 1; $ResultsSummary.HyperVInstalled = 1 }
                            33 { $SystemInfo.ClusteringInstalled = 1; $ResultsSummary.ClusteringInstalled = 1 }
                        }
                    }
                }
            } 
        } elseif (IsRegistryConnected) {
            
            # Get OS information using the CIM session
            LogText "Querying System Info From Registry"

            $oSName = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "SOFTWARE\Microsoft\Windows NT\CurrentVersion" -ValueName "ProductName"
            $bIsServer = $oSName -ilike "*server*"

            if ($bIsServer -and $TargetType -eq "Clients") {
                LogText -Color Yellow "$($ConnectionDetails.TargetName) will not be scanned because it is a Windows Server"
                return $false
            } elseif (!$bIsServer -and $TargetType -eq "Servers") {
                LogText -Color Yellow "$($ConnectionDetails.TargetName) will not be scanned because it is a Windows Client"
                return $false
            }

            $SystemInfo.Name = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName" -ValueName "ComputerName"
            $SystemInfo.Caption = $oSName
            $SystemInfo.FullVersion = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "SOFTWARE\Microsoft\Windows NT\CurrentVersion" -ValueName "CurrentVersion"
            $SystemInfo.ComputerDomain = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -ValueName "Domain"
            $SystemInfo.Model = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "HARDWARE\DESCRIPTION\System\BIOS" -ValueName "SystemProductName"
            $SystemInfo.Manufacturer = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "HARDWARE\DESCRIPTION\System\BIOS" -ValueName "SystemManufacturer"
            $SystemInfo.BiosManufacturer = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "HARDWARE\DESCRIPTION\System\BIOS" -ValueName "BIOSVendor"

            $SystemInfo.ProcessorName = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "HARDWARE\DESCRIPTION\System\CentralProcessor\0" -ValueName "ProcessorNameString"
            if ($SystemInfo.ProcessorName) {
                $SystemInfo.ProcessorName = $SystemInfo.ProcessorName.Trim()
            }
            $SystemInfo.ProcessorCount = -1;
            $SystemInfo.TotalCoreCount = -1;
            $SystemInfo.TotalLogicalProcessorCount = -1
            $SystemInfo.ProcessorCountStatusEnabled = -1
            $processorKeys = GetRegSubKeys -Hive $HKEY_LOCAL_MACHINE -Path "HARDWARE\DESCRIPTION\System\CentralProcessor"
            if ($processorKeys) {
                $SystemInfo.TotalLogicalProcessorCount = $processorKeys.Count
            }
        }
        
        if ($ScriptRegime -eq "SQL")
        {
            # Remove unused fields
            $propertiesToRemove = @('BIOSDate', 'InstallDate', 'LastBootUpTime', 'LocalDateTime', 'IISInstalled', 'ADInstalled', 'RDSInstalled', 'HyperVInstalled', 'ClusteringInstalled')
            foreach ($prop in $propertiesToRemove) {
                $SystemInfo.PSObject.Properties.Remove($prop)
            }
        }

        $SystemInfo.Name = $win32OS.CSName

        # Were we able to get the device information?
        if ($SystemInfo.Name -eq "" -and $SystemInfo.Caption -eq "" ) {
            LogText "Unable to retrieve basic device information" -Color Yellow
            return $false;
        }

        $ResultsSummary.OperatingSystem = $SystemInfo.Caption
        $ResultsSummary.OperatingSystemVersion = $SystemInfo.FullVersion
        
        $SystemInfo | Export-MyCsv -Path $OutputFile1

        return $true
    }
    catch {
        LogLastException
        RecordCriticalScanException "GetSystemInfo"
    }

    return $false;
}

function GetInstalledSoftware {

    try {
        LogTimeAndText  "Getting Installed Software"
    
        # Define the paths
        $uninstallPaths = @(
            'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
            'SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
        )

        $lstRecords = New-Object System.Collections.ArrayList        

        foreach ($uninstallPath in $uninstallPaths) {
            # Enumerate subkeys
            $subkeys = GetRegSubKeys -Hive $HKEY_LOCAL_MACHINE -Path $uninstallPath

            foreach ($subkey in $subkeys) {
                $softwareRecord = GetSoftwareRecord -Hive $HKEY_LOCAL_MACHINE -Path "$uninstallPath\$subkey"
                if ($softwareRecord.DisplayName) {
                    $lstRecords.Add($softwareRecord) | out-null
                }
            }
        }

        # Enumerate through each user
        $userSIDs = GetRegSubKeys -Hive $HKEY_USERS -Path ''

        foreach ($userSID in $userSIDs) {
            # Skip system profiles (like .DEFAULT, service profiles, etc.)
            if ($userSID -notmatch "_Classes$") {
                
                $userUninstallPath = "$userSID\$($uninstallPaths[0])"
                $subkeys = GetRegSubKeys -Hive $HKEY_USERS -Path $userUninstallPath

                foreach ($subkey in $subkeys) {

                    $softwareRecord = GetSoftwareRecord -Hive $HKEY_USERS -Path "$userUninstallPath\$subkey"
                    if ($softwareRecord.DisplayName) {
                        $lstRecords.Add($softwareRecord) | out-null
                    }
                }
            }
        }

        $countAll = $lstRecords.Count
        $countMicrosoft = ($lstRecords | Where-Object { $_.IsMicrosoft -eq $true }).Count
        $countPersonalInstall = ($lstRecords | Where-Object { $_.AllUsers -eq $false }).Count

        LogText "Software Installations: $countAll"
        LogText "Microsoft Software Installations: $countMicrosoft"
        LogText "Personal Software Installations: $countPersonalInstall"

        $ResultsSummary.SoftwareRecords = $countAll
        $ResultsSummary.SoftwareRecordsTotal = $countAll

        # Add IE line, but do not include it in the total application stats completed above
        $strIEVersion = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "SOFTWARE\Microsoft\Internet Explorer" -ValueName "svcVersion"
        if (!($strIEVersion)) {
            $strIEVersion = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "SOFTWARE\Microsoft\Internet Explorer" -ValueName "Version"
        }

        if ($strIEVersion) {
            $softwareRecord = [PSCustomObject][ordered]@{
                DisplayName = "Internet Explorer"
                DisplayVersion = $strIEVersion
                VersionMajor = $strIEVersion
                Publisher = "Microsoft"
                AllUsers = $true
                IsMicrosoft = $true
            }
            $lstRecords.Add($softwareRecord) | out-null
        }

        # Add OS line, but do not include it in the total application stats completed above
        # It serves only a technical purpose as an indicator of a successful scan in case no applications are identified
        if ($ResultsSummary.OperatingSystem) {
            $osRecord = [PSCustomObject][ordered]@{
                DisplayName = $ResultsSummary.OperatingSystem
                DisplayVersion = $ResultsSummary.OperatingSystemVersion
                VersionMajor = $ResultsSummary.OperatingSystemVersion
                Publisher = "Microsoft"
                AllUsers = $true
                IsMicrosoft = $true
            }
            $lstRecords.Add($osRecord) | out-null
        }

        if ($MicrosoftOnly) {
            $ResultsSummary.SoftwareRecords = $countMicrosoft
            $lstRecords = $lstRecords | Where-Object { $_.IsMicrosoft -eq $true }
        } 
        
        $lstRecords | Select-Object @{Name="ComputerName"; Expression={$ConnectionDetails.ComputerName}},
            @{Name="ComputerDomain"; Expression={$ConnectionDetails.ComputerDomain}},
            @{Name="DisplayName"; Expression={$_.DisplayName}},
            @{Name="InstallDate"; Expression={$_.InstallDate}},
            @{Name="VersionMajor"; Expression={$_.VersionMajor}},
            @{Name="DisplayVersion"; Expression={$_.DisplayVersion}},
            @{Name="Publisher"; Expression={$_.Publisher}},
            @{Name="QuietDisplayName"; Expression={$_.QuietDisplayName}},
            @{Name="AllUsers"; Expression={$_.AllUsers}},
            @{Name="IsMicrosoft"; Expression={$_.IsMicrosoft}}, 
            InstallLocation, InstallLocationCreationDate | Export-MyCsv -Path $OutputFile2 -IncludeIndex
    }
    catch {
        LogLastException
        RecordCriticalScanException "GetInstalledSoftware"
    }
}

function GetSoftwareRecord ($Hive, $Path) {
    $softwareRecord = [PSCustomObject][ordered]@{
        DisplayName = GetRegStringValue -Hive $Hive -Path $Path -ValueName "DisplayName"
        QuietDisplayName = GetRegStringValue -Hive $Hive -Path $Path -ValueName "QuietDisplayName"
        InstallDate = GetRegStringValue -Hive $Hive -Path $Path -ValueName "InstallDate"
        InstallLocation = GetRegStringValue -Hive $Hive -Path $Path -ValueName "InstallLocation"
        InstallLocationCreationDate = ""
        DisplayVersion = GetRegStringValue -Hive $Hive -Path $Path -ValueName "DisplayVersion"
        Publisher = GetRegStringValue -Hive $Hive -Path $Path -ValueName "Publisher"
        VersionMajor = GetRegDWORDValue -Hive $Hive -Path $Path -ValueName "VersionMajor"
        VersionMinor = GetRegDWORDValue -Hive $Hive -Path $Path -ValueName "VersionMinor"
        AllUsers = $true
        IsMicrosoft = $false
    }

    if (!($softwareRecord.DisplayName)) {
        $softwareRecord.DisplayName = $softwareRecord.QuietDisplayName
    }

    if (($null -ne $softwareRecord.VersionMajor) -and ($null -ne $softwareRecord.VersionMinor)) {
        $softwareRecord.VersionMajor = "$($softwareRecord.VersionMajor).$($softwareRecord.VersionMinor)"
    }

    if ($Hive -eq $HKEY_USERS) {
        $softwareRecord.AllUsers = $false
    }

    if ($softwareRecord.Publisher -ilike "*microsoft*") {
        $softwareRecord.IsMicrosoft = $true

        #if (($ScriptRegime -eq "GENERAL") -or ($ScriptRegime -eq "SPLA")) {
            if ($softwareRecord.InstallLocation) {
                if (($softwareRecord.DisplayName -ilike "*office*") -or
                    ($softwareRecord.DisplayName -ilike "*visio*") -or
                    ($softwareRecord.DisplayName -ilike "*project*") -or
                    ($softwareRecord.DisplayName -ilike "*365*") -or
                    ($softwareRecord.DisplayName -ilike "*sql server*")) {
                    $softwareRecord.InstallLocationCreationDate = GetFolderCreationDate -Path $softwareRecord.InstallLocation
                }
            }
        #}
    }

    return $softwareRecord
}

$FolderCreationDates = @{}
function GetFolderCreationDate ($Path) {

    $pattern = '^["''\s\/\\]+|["''\s\/\\]+$'
    $cleanPath = $Path -replace $pattern, ''

    if ($FolderCreationDates.ContainsKey($cleanPath)) {
        return $FolderCreationDates[$cleanPath]
    }

    $directoryInfo = ""
    $creationDate = ""
    $wmiPath = $cleanPath.Replace("\", "\\")#" -replace '\\', '\\' #-replace ':', '\:'

    try {
        $directoryInfo = Get-CimInstance -Query "SELECT * FROM Win32_Directory WHERE Name = '$wmiPath'" -CimSession $ConnectionDetails.CimSession -ErrorAction SilentlyContinue
    
        if ($directoryInfo) {
            $creationDate = $directoryInfo.CreationDate.ToString("yyyy-MM-dd")
        }
    } catch {}
    
    $FolderCreationDates[$cleanPath] = $creationDate

    return $creationDate
}

function GetServices {

    try {

        LogTimeAndText  "Getting Windows Services"

        $lstServices = $null;
        
        if (IsCimConnected) {
            LogText "Querying Win32_Service"
            $lstServices = Get-CimInstance -ClassName Win32_Service -CimSession $ConnectionDetails.CimSession
        } elseif (IsRegistryConnected) {
            LogText "Querying Registry For Services"
            $lstServices = GetAllWindowsServicesFromRegistry
        }

        if ($MicrosoftOnly) {

            # Identifiers for important Windows Services
            $matchStrings = @(
                "Microsoft", "Windows", 
                "365", 
                "SQL Server", "MSSQL", "ReportServer", "SQLSERVER", "MSOLAP", "MsDtsServer", "SQLAgent", "SPADMIN", # SQL Server
                "MSExchange", # Exchange Server
                "smstsmgr", "CcmExec", # System Center
                "BizTalk", "BTSSvc", # BizTalk Server
                "MicrosoftDynamics", "MSCRM", # Dynamics
                "Tssdis",     # Terminal Services Session Broker
                "Hyper-V", "HvHost", # Hyper-V
                "W3SVC",      # IIS
                "msmpi",      # HPC MPI Service
                "MSMQ$"       # Message Queuing
                "ClusSvc"     # Cluster Service
            )

            if ($AdditionalMicrosoftFilter) {
                # Split the string by commas, trim each item, and add to matchStrings
                $additionalMatchStrings = $AdditionalMicrosoftFilter.Split(',') | ForEach-Object { $_.Trim() }
                $matchStrings += $additionalMatchStrings
            }

            # Filter services
            $lstServices = $lstServices | Where-Object {
                $service = $_
                $found = $false
                foreach ($matchString in $matchStrings) {
                    if ($service.DisplayName -like "*$matchString*" -or 
                        $service.Name -like "*$matchString*") {
                        $found = $true
                        break
                    }
                }
                $found
            }
        } 
        
        $countAll = $lstServices.Count
        LogText "Windows Services: $countAll"
        $ResultsSummary.WindowsServices = $countAll

        $lstServices | Select-Object @{Name="ComputerName"; Expression={$ConnectionDetails.ComputerName}},
            @{Name="ComputerDomain"; Expression={$ConnectionDetails.ComputerDomain}},
            @{Name="DisplayName"; Expression={$_.DisplayName}},
            @{Name="Name"; Expression={$_.Name}},
            @{Name="State"; Expression={$_.State}},
            @{Name="StartMode"; Expression={$_.StartMode}} | Export-MyCsv -Path $OutputFile3 -IncludeIndex
            #@{Name="StartName"; Expression={$_.StartName}},
            #@{Name="Description"; Expression={$_.Description}},
            #@{Name="Status"; Expression={$_.Status}},
            #@{Name="Started"; Expression={$_.Started}}
            ##@{Name="Path"; Expression={$_.PathName -replace '"', ''}} 
    }
    catch {
        LogLastException
        RecordCriticalScanException "GetServices"
    }
}

function GetAllWindowsServicesFromRegistry {
    $servicesKeyPath = "SYSTEM\CurrentControlSet\Services"
    $serviceNames = GetRegSubKeys -Hive $HKEY_LOCAL_MACHINE -Path $servicesKeyPath

    $services = @()
    foreach ($serviceName in $serviceNames) {
        $servicePath = "$servicesKeyPath\$serviceName"
        $displayName = GetRegStringValue $HKEY_LOCAL_MACHINE $servicePath "DisplayName"
        $startMode = GetRegStringValue $HKEY_LOCAL_MACHINE $servicePath "Start"
        $startName = GetRegStringValue $HKEY_LOCAL_MACHINE $servicePath "ObjectName"
        $description = GetRegStringValue $HKEY_LOCAL_MACHINE $servicePath "Description"
        $path = GetRegStringValue $HKEY_LOCAL_MACHINE $servicePath "ImagePath"

        $services += [PSCustomObject]@{
            DisplayName = $displayName
            Name = $serviceName
            StartMode = $startMode
            StartName = $startName
            Description = $description
            Path = $path
            State = "Unknown"
        }
    }

    return $services
}

function GetSQLServerDetails {

    try {
        LogTimeAndText  "Getting SQL Server Details"

        $lstSQLWindowsServices = @(
            'MSSQLSERVER', 
            'MSSQL$*', 
            'ReportServer*',
            'SQLSERVERREPORTINGSERVICES',
            'MSOLAP*',
            'MSSQLSERVEROLAPSERVICE',
            'MsDtsServer*',
            'SQLSERVERAGENT',
            'SQLAgent*') 

        $services = $null

        if (IsCimConnected) {
            $filterQuery = ($lstSQLWindowsServices | ForEach-Object { "Name LIKE '$($_ -replace '\*', '%')'" }) -join " OR "
            $services = Get-CimInstance -ClassName Win32_Service -Filter $filterQuery -CimSession $ConnectionDetails.CimSession
        } elseif (IsRegistryConnected) {
            $allServices = GetAllWindowsServicesFromRegistry
            $services = foreach ($pattern in $lstSQLWindowsServices) {
                $allServices | Where-Object { $_.Name -like $pattern }}
        }

        if ($services -and $services.Count -gt 0) {
            LogText "SQL Server services: $($services.Count)"
        } else {
            LogText "No SQL Server services found"
            return
        }
        
        $lstSQLServices = New-Object System.Collections.ArrayList

        foreach ($service in $services) {
            
            $serviceType = ""
            $instanceName = ""

            $instanceIDReg = ""
            $versionReg   = ""
            $editionReg   = ""
            $productCodeReg = ""
            $productIDReg = ""
            $collationReg = ""

            $instanceIDWMI = ""
            $versionWMI   = ""
            $editionWMI   = ""
            $isClusteredWMI  = ""
            $spLevelWMI = ""
            $installPathWMI = ""
            $dataPathWMI = ""
            $languageWMI = ""
            $fileVersionWMI = ""
            $regRootWMI = ""
            $skuWMI = ""
            $wmiNamespace = ""

            # Standardise the service name
            $strUpdatedServiceName = $service.Name
            switch ($service.Name) {
                { $_ -like 'MSSQLSERVER'} { $strUpdatedServiceName = 'MSSQL$MSSQLSERVER' }
                { $_ -like 'SQLSERVERREPORTINGSERVICES'} { $strUpdatedServiceName = 'ReportServer$SSRS' }
                { $_ -like 'MSSQLSERVEROLAPSERVICE'} { $strUpdatedServiceName = 'MSOLAP$MSSQLSERVER' }
                { $_ -like 'SQLSERVERAGENT'} { $strUpdatedServiceName = 'SQLAgent$MSSQLSERVER' }
            }

            # Determine service type and registry location
            $regInstanceNamesSubkey = ""
            switch ($strUpdatedServiceName) {
                { $_ -like 'MSSQL$*' } { $serviceType = "Database Engine"; $regInstanceNamesSubkey = "SQL"  }
                { $_ -like 'ReportServer*' } { $serviceType = "Reporting Services"; $regInstanceNamesSubkey = "RS" }
                { $_ -like 'MSOLAP*' } { $serviceType = "Analysis Services"; $regInstanceNamesSubkey = "OLAP" }
                { $_ -like 'SQLAgent*' } { $serviceType = "Agent Service"; $regInstanceNamesSubkey = "SQL" }
                { $_ -like 'MsDtsServer*' } { $serviceType = "Integration Services"; $regInstanceNamesSubkey = "SQL" }
            }

            # Get the instance name
            $indexDollar = $strUpdatedServiceName.IndexOf('$')
            $indexBracketOpen = $service.Description.IndexOf('(')
            $indexBracketClose = $service.Description.IndexOf(')')
            if ($indexDollar -ne -1) {
                $instanceName = $strUpdatedServiceName.Substring($indexDollar + 1)
            } elseif ($indexBracketOpen -ne -1 -and $indexBracketClose -ne -1 -and $indexBracketClose -gt $indexBracketOpen) {
                $instanceName = $InputString.Substring($indexBracketOpen + 1, $indexBracketClose - $indexBracketOpen - 1)
                if ($instanceName -eq "default") {
                    $instanceName = "MSSQLSERVER"
                }
            } elseif ($strUpdatedServiceName -eq "ReportServer") {
                $instanceName = "MSSQLSERVER"
            }

            # Get the registry path for this instance
            $instanceIDReg = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\$regInstanceNamesSubkey" -ValueName $instanceName
            
            # Get version and edition from the registry
            if ($instanceIDReg) {
                $versionReg = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "SOFTWARE\Microsoft\Microsoft SQL Server\$instanceIDReg\Setup" -ValueName "Version"
                $editionReg = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "SOFTWARE\Microsoft\Microsoft SQL Server\$instanceIDReg\Setup" -ValueName "Edition"
                $productCodeReg = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "SOFTWARE\Microsoft\Microsoft SQL Server\$instanceIDReg\Setup" -ValueName "ProductCode"
                $productIDReg = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "SOFTWARE\Microsoft\Microsoft SQL Server\$instanceIDReg\Setup" -ValueName "ProductID"
                $collationReg = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "SOFTWARE\Microsoft\Microsoft SQL Server\$instanceIDReg\Setup" -ValueName "Collation"
            }
            
            $namespaces = @('ComputerManagement', 'ComputerManagement10', 'ComputerManagement11', 'ComputerManagement12', 'ComputerManagement13', 'ComputerManagement14', 'ComputerManagement15', 'ComputerManagement16')
            foreach ($namespace in $namespaces) {
                if (-not $editionWMI) {
                    try {
                        $properties = Get-CimInstance -Namespace "root\Microsoft\SqlServer\$namespace" -ClassName SqlServiceAdvancedProperty -Filter "ServiceName = '$($service.Name)'" -CimSession $ConnectionDetails.CimSession -ErrorAction Stop

                        foreach ($property in $properties) {
                            switch ($property.PropertyName) {
                                'SKUNAME' { $editionWMI = $property.PropertyStrValue; $wmiNamespace = $namespace }
                                'VERSION' { $versionWMI = $property.PropertyStrValue }
                                'CLUSTERED' { $isClusteredWMI = $property.PropertyNumValue }
                                'SPLEVEL' { $spLevelWMI = $property.PropertyNumValue }
                                'INSTALLPATH' { $installPathWMI = $property.PropertyStrValue }
                                'DATAPATH' { $dataPathWMI = $property.PropertyStrValue }
                                'LANGUAGE' { $languageWMI = $property.PropertyNumValue }
                                'FILEVERSION' { $fileVersionWMI = $property.PropertyStrValue }
                                'REGROOT' { $regRootWMI = $property.PropertyStrValue }
                                'SKU' { $skuWMI = $property.PropertyNumValue }
                                'INSTANCEID' { $instanceIDWMI = $property.PropertyStrValue }
                            }
                        }
                    } catch {
                        # Silently continue if namespace does not exist or no information is found
                    }
                }
            }

            # Return the details for this instance
            $lstSQLServices.Add( [PSCustomObject]@{
                ServiceName     = $service.Name
                DisplayName     = $service.DisplayName
                ServiceType     = $serviceType
                State           = $service.State
                InstanceName    = $instanceName
                InstanceIDReg   = $instanceIDReg
                VersionReg      = $versionReg
                EditionReg      = $editionReg
                ProductCodeReg  = $productCodeReg
                ProductIDReg    = $productIDReg
                CollationReg    = $collationReg
                WMINamespace    = $wmiNamespace
                InstanceIDWMI   = $instanceIDWMI
                VersionWMI      = $versionWMI
                EditionWMI      = $editionWMI
                IsClustered     = $isClusteredWMI
                SPLevel         = $spLevelWMI
                InstallPath     = $installPathWMI
                DataPath        = $dataPathWMI
                Language        = $languageWMI
                FileVersion     = $fileVersionWMI
                RegRoot         = $regRootWMI
                SKU             = $skuWMI
            }) | Out-Null
        }

        if ($lstSQLServices.Count -gt 0) {
            $lstSQLServices | Select-Object @{Name="ComputerName"; Expression={$ConnectionDetails.ComputerName}},
                @{Name="ComputerDomain"; Expression={$ConnectionDetails.ComputerDomain}},
                ServiceName, DisplayName, ServiceType, State, InstanceName, 
                InstanceIDReg, VersionReg, EditionReg, ProductCodeReg, ProductIDReg,
                WMINamespace, InstanceIDWMI, VersionWMI, EditionWMI, IsClustered, SPLevel, InstallPath, DataPath, FileVersion, RegRoot,
                @{Name="Version"; Expression={if ($_.VersionReg) {$_.VersionReg} else {$_.VersionWMI}}},
                @{Name="Edition"; Expression={if ($_.EditionReg) {$_.EditionReg} else {$_.EditionWMI}}} | Export-MyCsv -Path $OutputFile4 -IncludeIndex
        }
    }
    catch {
        LogLastException
        RecordCriticalScanException "GetSQLServerDetails"
    }

}

function GetClusterInfo {

    try {

        if ($ResultsSummary.ClusteringInstalled -ne 1) {
            return
        }
    
        LogTimeAndText "Getting Cluster Info"
    
        $clusters = Get-CimInstance -Namespace "root/MSCluster" -Query "Select * from MSCluster_Cluster" -CimSession $ConnectionDetails.CimSession  
        
        $strClusterAlias = "Unknown"
        $strClusterFQDN = "Unknown"
        $strSharedVolumesRoot = "Unknown"
        foreach ($cluster in $clusters) {
            $strClusterAlias = $cluster.Name
            $strClusterFQDN = $cluster.FQDN
            $strSharedVolumesRoot = $cluster.SharedVolumesRoot
        }
    
        $clusterList = @()
        $dictActive = @{}
    
        $activeResources = Get-CimInstance -Namespace "root/MSCluster" -Query "select * from MSCluster_NodeToActiveResource"  -CimSession $ConnectionDetails.CimSession
        foreach ($resource in $activeResources) {
    
            #MSCluster_Resource (Name = Cluster-IP-Adresse)
    
            $strGC = CleanCimElementName -name $resource.GroupComponent
            $strPC = CleanCimElementName -name $resource.PartComponent
    
            $clusterList += [PSCustomObject][ordered]@{
                'ComputerName'    = $ConnectionDetails.ComputerName
                'ComputerDomain'  = $ConnectionDetails.ComputerDomain
                'ClusterAlias'    = $strClusterAlias
                'ClusterFQDN'     = $strClusterFQDN
                'ClusterRoot'     = $strSharedVolumesRoot
                'ClusterMode'     = "Active"
                'GroupComponent'  = $strGC
                'PartComponent'   = $strPC
            }
    
            $dictActive["$strGC $strPC"] = $true
        }
    
        $possibleOwners = Get-CimInstance -Namespace "root/MSCluster" -Query "select * from MSCluster_ResourceToPossibleOwner" 
        foreach ($owner in $possibleOwners) {
            $strGC = CleanCimElementName -name $owner.GroupComponent
            $strPC = CleanCimElementName -name $owner.PartComponent
            
            if (-not $dictActive["$strPC $strGC"]) {
                $clusterList += [PSCustomObject][ordered]@{
                    'ComputerName'    = $ConnectionDetails.ComputerName
                    'ComputerDomain'  = $ConnectionDetails.ComputerDomain
                    'ClusterAlias'    = $strClusterAlias
                    'ClusterFQDN'     = $strClusterFQDN
                    'ClusterRoot'     = $strSharedVolumesRoot
                    'ClusterMode'     = "Passive"
                    'GroupComponent'  = $strPC
                    'PartComponent'   = $strGC
                }
            }
        }
    
        LogText "$($clusterList.Count) Cluster records found"
    
        $clusterList | Export-MyCsv -Path $OutputFile5 -IncludeIndex
    }
    catch {
        LogLastException
        RecordCriticalScanException "GetClusterInfo"
    }
}

function CleanCimElementName ($name) {

    if (-not $name) {
        return ""
    }

    $strName = $name.ToString().Replace("MSCluster_Node", "").Replace('MSCluster_Resource', '').Replace('(Name', '').Replace('Name', '')

    return $strName.Trim(' ', '(', ')', '=', '.', '"')
}

function GetSoftwareLicenseInfo {

    try {

        LogTimeAndText  "Getting Software License Info"
    
        LogText "Querying SoftwareLicensingProduct:" -NoNewLine
        $lstSoftwareLicensingProducts = Get-CimInstance -Query "Select * from SoftwareLicensingProduct WHERE PartialProductKey<>null AND LicenseStatus<>0" -CimSession $ConnectionDetails.CimSession -ErrorAction SilentlyContinue
        LogText " $(($lstSoftwareLicensingProducts | Measure-Object).Count) Records"

        LogText "Querying OfficeSoftwareProtectionProduct:" -NoNewLine
        $lstOfficeSoftwareProtectionProducts = Get-CimInstance -Query "Select * from OfficeSoftwareProtectionProduct WHERE PartialProductKey<>null AND LicenseStatus<>0" -CimSession $ConnectionDetails.CimSession -ErrorAction SilentlyContinue
        LogText " $(($lstOfficeSoftwareProtectionProducts | Measure-Object).Count) Records"

        LogText "Querying SoftwareLicensingService:" -NoNewLine
        $lstSoftwareLicensingServices = Get-CimInstance -Query "Select * from SoftwareLicensingService" -CimSession $ConnectionDetails.CimSession -ErrorAction SilentlyContinue | Where-Object {
            ($_.OA3xOriginalProductKey) -or
            ($_.OA3xOriginalProductKeyDescription) -or
            ($_.KeyManagementServiceMachine) -or
            ($_.KeyManagementServiceProductKeyID)}
        LogText " $(($lstSoftwareLicensingServices | Measure-Object).Count) Records"

        $lstSoftwareLicensingServicesUpdated = $lstSoftwareLicensingServices | Select-Object @{Name="Name"; Expression={"Windows BIOS Key"}},
            @{Name="Description"; Expression={$_.OA3xOriginalProductKeyDescription}},
            @{Name="PartialProductKey"; Expression={
                $key = $_.OA3xOriginalProductKey
                if ($key -and $key.Length -gt 10) {
                    $start = $key.Substring(0, 5)
                    $end = $key.Substring($key.Length - 5, 5)
                    $middle = $key.Substring(5, $key.Length - 10) -replace '[^-]', '*'
                    "$start$middle$end"
                } else {
                    $key
                }
            }}, 
            @{Name="ProductKeyID"; Expression={ $_.KeyManagementServiceProductKeyID}},
            DiscoveredKeyManagementServiceMachineName, DiscoveredKeyManagementServiceMachinePort, KeyManagementServiceMachine, KeyManagementServicePort

        $allRecords = @($lstSoftwareLicensingProducts) + @($lstOfficeSoftwareProtectionProducts) + @($lstSoftwareLicensingServicesUpdated)
        $ResultsSummary.SoftwareLicenseRecords = $allRecords.Count

        $allRecords | Select-Object @{Name="ComputerName"; Expression={$ConnectionDetails.ComputerName}},
            @{Name="ComputerDomain"; Expression={$ConnectionDetails.ComputerDomain}},
            Name,Description,LicenseFamily,PartialProductKey,LicenseStatus,LicenseStatusReason,EvaluationEndDate,
            ExtendedGrace,GenuineStatus,GracePeriodRemaining,DiscoveredKeyManagementServiceMachineName,
            KeyManagementServiceMachine,ApplicationID,ProductKeyID | Export-MyCsv -Path $OutputFile6 -IncludeIndex
    }
    catch {
        LogLastException
    }
}

function GetMSIInstallerEvents {
    
    try {

        LogTimeAndText "Getting MSI Installer Events"

        # Define the time range for the last 180 days
        $endDate = Get-Date
        $startDate = $endDate.AddDays(-180)

        # Convert the start and end dates to the WMI time format
        $startDateWmi = $startDate.ToUniversalTime().ToString("yyyyMMddHHmmss.ffffff+000")
        $endDateWmi = $endDate.ToUniversalTime().ToString("yyyyMMddHHmmss.ffffff+000")
    
        # MSIInstaller events 
        # ID 1033 = Installed software
        # ID 1034 = Removed software
        # ID 1035 = Reconfigured software
        # ID 1036 = Installed update
        # ID 11707 = Installed software (win2003)
        # ID 11724 = Removed software (win2003)
        $query = "Select * from Win32_NTLogEvent Where LogFile='Application' And SourceName Like 'msiinstaller' AND " +
                "((EventCode>=1033 AND EventCode<=1036) OR EventCode=11707 OR EventCode=11724) AND 
                TimeWritten >= '$startDateWmi' And TimeWritten <= '$endDateWmi'"

        LogText "Querying Win32_NTLogEvent:" -NoNewLine 
        $lstEvents = Get-CimInstance -Query $query -CimSession $ConnectionDetails.CimSession

        if ($MicrosoftOnly) {
            # Identifiers for Microsoft Applications
            $matchStrings = @(
                "Microsoft",
                "access",
                "Project",
                "Nav",
                "Visual Studio",
                "excel",
                "Visio",
                "SharePoint",
                "Team Foundation Server",
                "word",
                "System Center",
                "Skype for",
                "Team Explorer",
                "powerpoint",
                "Configuration Manager",
                "Skypefor",
                "LightSwitch",
                "lync",
                "Outlook",
                "Exchange",
                "Internet Explorer",
                "microsoft office",
                "Groove",
                "Forefront",
                ".NET Framework",
                "office",
                "InfoPath",
                "TMG",
                "BizTalk",
                "SQL Server",
                "OneNote",
                "Threat Management Gateway",
                "Works",
                "Publisher",
                "ISA",
                "FrontPage",
                "Dynamics",
                "Internet Security and Acceleration",
                "FoxPro",
                "Navision",
                "Power BI",
                "365"
            )

            if ($AdditionalMicrosoftFilter) {
                # Split the string by commas, trim each item, and add to matchStrings
                $additionalMatchStrings = $AdditionalMicrosoftFilter.Split(',') | ForEach-Object { $_.Trim() }
                $matchStrings += $additionalMatchStrings
            }

            # Filter events
            $lstEvents = $lstEvents | Where-Object {
                $installEvent = $_
                $found = $false
                foreach ($matchString in $matchStrings) {
                    if ($installEvent.Message -like "*$matchString*") {
                        $found = $true
                        break
                    }
                }
                $found
            }
        } 

        LogText " $($lstEvents.Count) MSIInstaller Events"
        $ResultsSummary.MSIInstallerEvents = $lstEvents.Count

        if ($SoftwareFilter) {
            $lstEvents = $lstEvents | Where-Object { $_.Message.Contains($SoftwareFilter) }
        }

        $lstEvents | Select-Object @{Name="ComputerName"; Expression={$ConnectionDetails.ComputerName}},
            @{Name="ComputerDomain"; Expression={$ConnectionDetails.ComputerDomain}},
            EventCode, 
            @{Name="Message"; Expression={($_.Message -replace ";", "," -replace "`r", "" -replace "`n", "")}}, 
            TimeWritten | Export-MyCsv -Path $OutputFile7 -IncludeIndex
    }
    catch {
        LogLastException
    }
}

function GetLogonEvents {
    
    try {

        LogTimeAndText "Getting Logon Events"

        # Initialize an ArrayList to hold the event data
        $eventData = New-Object System.Collections.ArrayList

        # Define the time range for the last 90 days
        $endDate = Get-Date
        $startDate = $endDate.AddDays(-90)

        # Convert the start and end dates to the WMI time format
        $startDateWmi = $startDate.ToUniversalTime().ToString("yyyyMMddHHmmss.ffffff+000")
        $endDateWmi = $endDate.ToUniversalTime().ToString("yyyyMMddHHmmss.ffffff+000")

        # Security events 
        # ID 4624 = Successful logon
        $query = "Select * from Win32_NTLogEvent Where Logfile = 'Security' and EventCode=4624 And TimeWritten >= '$startDateWmi' And TimeWritten <= '$endDateWmi'"

        LogText "Querying Win32_NTLogEvent:" -NoNewLine 
        $lstEvents = Get-CimInstance -Query $query -CimSession $ConnectionDetails.CimSession

        if ($lstEvents.Count -eq 0) {return} # no log no need to continue

        # Find the oldest event's TimeGenerated
        $oldestEvent = $lstEvents | Sort-Object TimeGenerated | Select-Object -First 1
        $daysSinceEarliestLogonRetrieved = ($endDate - $oldestEvent.TimeGenerated).Days

        # Display the results
        foreach ($event in $lstEvents) {

            # Extract the logon type, account name, and account domain from the message
            $logonType = if ($event.Message -match "Logon Type:\s+(\d+)") { $matches[1] } else { "Unknown" }

            # Initialize a flag to indicate whether to skip the current event
            $skipEvent = $false

            # Determine the logon type explanation
            $eventCodeExplained = switch ($logonType) {
                "2" { "Successful logon" } # Interactive logon
                "3" { "Successful logon" } # Network logon
                "8" { "Successful logon" } # NetworkClearText logon
                "9" { "Successful logon" } # NewCredentials logon
                "10" { "Successful logon" } # RemoteInteractive logon
                "11" { "Successful logon" } # CachedInteractive logon
                default { $skipEvent = $true; break } # Set the flag to skip the event
            }

            # Skip to the next event in the foreach loop if the flag is set
            if ($skipEvent) {
                continue
            }

            $accountName = if ($event.Message -match "New Logon:\s*\r?\n\s*Security ID:.*\r?\n\s*Account Name:\s+([^\r\n]+)") { $matches[1].Trim() } else { "Unknown" }
            $accountDomain = if ($event.Message -match "New Logon:\s*\r?\n\s*Security ID:.*\r?\n\s*Account Name:.*\r?\n\s*Account Domain:\s+([^\r\n]+)") { $matches[1].Trim() } else { "Unknown" }
            $virtualAccount = if ($event.Message -match "Virtual Account:\s+([^\r\n]+)") { $matches[1].Trim() } else { "Unknown" }
            
            # Skip events where AccountName is the computer name followed by a dollar sign or is a SYSTEM name
            # Skip adding to $eventInfo if the virtual account status is not "No"
            if ($accountName -like '*$' -or $accountName -eq "SYSTEM" -or $virtualAccount -ne "No") {
                continue
            }

            # Create a custom object with the extracted data
            $eventInfo = [PSCustomObject]@{
                EventCode = $event.EventCode
                EventCodeExplained = $eventCodeExplained
                AccountName = $accountName
                AccountDomain = $accountDomain
                TimeWritten = $event.TimeGenerated
                LogonType = $logonType
                DaysSinceEarliestLogonRetrieved = $daysSinceEarliestLogonRetrieved
            }
            
            # Add the custom object to the ArrayList
            [void]$eventData.Add($eventInfo)
        }

        LogText " $($eventData.Count) Logon Events"
        $ResultsSummary.LogonEvents = $eventData.Count

        $eventData | Select-Object @{Name="ComputerName"; Expression={$ConnectionDetails.ComputerName}},
        @{Name="ComputerDomain"; Expression={$ConnectionDetails.ComputerDomain}},
        LogonType, EventCode, EventCodeExplained, AccountName, AccountDomain, TimeWritten, DaysSinceEarliestLogonRetrieved | Export-MyCsv -Path $OutputFile18 -IncludeIndex
    }
    catch {
        LogLastException
    }
}

function GetComputerLogons {

    try {

        LogTimeAndText "Getting User Logon Information"

        # Get profiles directory from registry
        $profiles = GetRegStringValue -Hive $HKEY_LOCAL_MACHINE -Path "SOFTWARE\MICROSOFT\WINDOWS NT\CURRENTVERSION\PROFILELIST" -ValueName "PROFILESDIRECTORY"

        if (!($profiles)) {
            return
        }

        # Extract the drive
        $drive = $profiles.Substring(0, 2)

        # Strip the drive from the path and perform the replacements
        $path = $profiles.Replace($drive, "").Replace("\", "\\")
        if (-not $path.EndsWith("\\")) {
            $path += "\\"
        }

        LogText "Profiles Path: $path"

        # Skip network locations
        if (-not $profiles.StartsWith('\\')) {
            
            LogText "Querying Win32_Directory"
            $query = "Select * from Win32_Directory Where Hidden=false And Path='$path' And drive='$drive'"
            $directories = Get-CimInstance -Query $query -CimSession $ConnectionDetails.CimSession

            $directories | Where-Object { $_.FileName -ne 'ALL USERS' } | 
                Select-Object @{ Name="ComputerName"; Expression={$ConnectionDetails.ComputerName}},
                @{Name="ComputerDomain"; Expression={$ConnectionDetails.ComputerDomain}},
                @{Name="ScanTime"; Expression={$ResultsSummary.StartTime}},
                FileName, CreationDate, LastModified, LastAccessed | 
                Export-MyCsv -Path $OutputFile8 -IncludeIndex
        }
    }
    catch {
        LogLastException
    }
}

function GetUserProfiles {
    
    try {
        LogTimeAndText "Getting User Profiles"
        LogText "Querying Win32_UserProfile"

        $lstProfiles = Get-CimInstance -ClassName Win32_UserProfile -CimSession $ConnectionDetails.CimSession

        $countAll = $lstProfiles.Count
        LogText "User Profiles: $countAll"
        $ResultsSummary.UserProfiles = $countAll

        $lstProfiles | Select-Object @{Name="ComputerName"; Expression={$ConnectionDetails.ComputerName}},
            @{Name="ComputerDomain"; Expression={$ConnectionDetails.ComputerDomain}},
            @{Name="ScanTime"; Expression={$ResultsSummary.StartTime}},
            ##SID, LocalPath, Special, RoamingConfigured, LastUseTime | Export-MyCsv -Path "$($OutputFolder)UserProfiles.csv" -IncludeIndex
            SID, LocalPath, Special, LastUseTime | Export-MyCsv -Path $OutputFile9 -IncludeIndex
    }
    catch {
        LogLastException
    }

    
}

function GetDNSRecords {

    LogTimeAndText "Getting DNS Records"
    
    if ([string]::IsNullOrEmpty($ConnectionDetails.ComputerDomain)) {
        LogText "Skipping DNS Query - No Domain Found"
        return
    }

    $rootDomain = ""
    $lstDomainNameParts = $ConnectionDetails.ComputerDomain.Split('.')
    if ($lstDomainNameParts.Count -eq 1) {
        $rootDomain = $lstDomainNameParts[0]
    } elseif ($lstDomainNameParts.Count -gt 1) {
        $rootDomain = $lstDomainNameParts[-2]
    }

    if ([string]::IsNullOrEmpty($rootDomain)) {
        LogText "Skipping DNS Query - Root Domain Not Found"
        return
    }

    LogText "Domain: $rootDomain"

    try {
        $results1 = @(Get-CimInstance -Namespace "root\MicrosoftDNS" -ClassName MicrosoftDNS_CNAMEType -CimSession $ConnectionDetails.CimSession -ErrorAction Stop |
           Where-Object { $_.DomainName -match "$rootDomain" } |
           Select-Object OwnerName, PrimaryName, DomainName)
        
        $results2 = @(Get-CimInstance -Namespace "root\MicrosoftDNS" -ClassName MicrosoftDNS_AType -CimSession $ConnectionDetails.CimSession -ErrorAction Stop |
           Where-Object { $_.DomainName -match "$rootDomain" } |
           Select-Object OwnerName, PrimaryName, DomainName)

        $combinedResults = $results1 + $results2

        LogText "$($combinedResults.Count) DNS records found"

        $combinedResults | Export-MyCsv -Path $OutputFile10 -IncludeIndex
    } catch {
        $errorId = $_.Exception.HResult
        if ($errorId -eq -2146233088 -or $_.Exception.Message -like "*namespace root/MicrosoftDNS is invalid*") {
            LogText "DNS Server role not installed"
            return
        } else {
            # Log the error message for debugging
            LogText "An error occurred while querying DNS records. HResult: $errorId Details: $($_.Exception.Message)"
        }
        
        return
    }
}

function GetHyperVDetails {

    try {

        if ($ResultsSummary.HyperVInstalled -ne 1) {
            return
        }
    
        LogTimeAndText  "Getting Hyper-V Details"
    
        GetHyperVVMsAndHosts -VMFile $OutputFile11 -HostFile $OutputFile12
    }
    catch {
        LogLastException
    }
}

function GetIPAddresses {

    try {
        LogTimeAndText "Getting IP Addresses"

        $networkAdapterConfigurations = Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -CimSession $ConnectionDetails.CimSession |
            Where-Object { $_.IPEnabled -eq $true -and $null -ne $_.IPAddress -and $_.IPAddress.Count -gt 0 }

        $ipList = @()

        foreach ($networkAdapterConfiguration in $networkAdapterConfigurations) {
            for ($i = 0; $i -lt $networkAdapterConfigurations.IPAddress.Count; $i++) {
                $ipList += [PSCustomObject][ordered]@{
                    'ComputerName'  = $ConnectionDetails.ComputerName
                    'ComputerDomain'= $ConnectionDetails.ComputerDomain
                    'IPAddressCount'= $i
                    'IPAddress'     = $networkAdapterConfiguration.IPAddress[$i]
                    'MACAddress'    = $networkAdapterConfiguration.MACAddress
                }
            }
        }

        LogText "$($ipList.Count) IP Addresses found"

        $ipList | Export-MyCsv -Path $OutputFile16 -IncludeIndex
    }
    catch {
        LogLastException
    }

    
}

function GetProcesses {
    
    try {

        LogTimeAndText  "Getting Running Processes"
        LogText "Querying Win32_Process"

        $lstProcesses = Get-CimInstance -ClassName Win32_Process -CimSession $ConnectionDetails.CimSession

        if ($MicrosoftOnly) {

            $matchStrings = @(
                "explorer.exe", # Logon Session
                "winword.exe", # Office
                "excel.exe",
                "powerpnt.exe",
                "onenote.exe",
                "outlook.exe",
                "msaccess.exe",
                "lync.exe",
                "mspub.exe",
                "grove.exe",
                "graph.exe",
                "onenotem.exe",
                "winproj.exe",
                "visio.exe",
                "devenv.exe" # Visual Studio
                "sqlservr.exe", # SQL Server
                "Microsoft.Exchange.ServiceHost.exe", # Exchange Server
                "owstimer.exe", # Sharepoint
                "lsass.exe", # Lync Server
                "AIUpdateSVC.exe") # System Center

            if ($AdditionalMicrosoftFilter) {
                # Split the string by commas, trim each item, and add to matchStrings
                $additionalMatchStrings = $AdditionalMicrosoftFilter.Split(',') | ForEach-Object { $_.Trim() }
                $matchStrings += $additionalMatchStrings
            }

            # Filter processes
            $lstProcesses = $lstProcesses | Where-Object {
                $process = $_
                $found = $false
                foreach ($matchString in $matchStrings) {
                    if ($process.Name -eq "$matchString" ) {
                        $found = $true
                        break
                    }
                }
                $found
            }
        
        }

        $countAll = $lstProcesses.Count
        LogText "Running Processes: $countAll"
        $ResultsSummary.RunningProcesses = $countAll

        $lstProcesses | Select-Object @{Name="ComputerName"; Expression={$ConnectionDetails.ComputerName}},
            @{Name="ComputerDomain"; Expression={$ConnectionDetails.ComputerDomain}}, Name, 
            ExecutablePath | Export-MyCsv -Path $OutputFile17 -IncludeIndex
    }
    catch {
        LogLastException
    }
}


function GetDiskDetails {
    LogTimeAndText  "Getting Disk Details"
    LogText "Querying Win32_LogicalDisk"

    $lstDisks = Get-CimInstance -ClassName Win32_LogicalDisk -CimSession $ConnectionDetails.CimSession

    $countAll = $lstDisks.Count
    LogText "Logical Disks: $countAll"

    $lstDisks | Select-Object @{Name="ComputerName"; Expression={$ConnectionDetails.ComputerName}},
        @{Name="ComputerDomain"; Expression={$ConnectionDetails.ComputerDomain}}, 
        Description, 
        @{Name="DeviceID"; Expression={if ($_.DeviceID) {$_.DeviceID} else {"Unknown"}}},
        @{Name="Filesystem"; Expression={if ($_.Filesystem) {$_.Filesystem} else {"Unknown"}}},
        @{Name="SizeGB"; Expression={[math]::Round(($_.Size / 1GB), 2)}},
        @{Name="FreeSpaceGB"; Expression={[math]::Round(($_.FreeSpace / 1GB), 2)}},
        @{Name="StatusInfo"; Expression={if ($_.StatusInfo) {$_.StatusInfo} else {"Success"}}} | Export-MyCsv -Path $OutputFile14 -IncludeIndex
}

function GetHotFixes {
    LogTimeAndText  "Getting Hot Fixes"
    LogText "Querying Win32_QuickFixEngineering"

    $lstHotFixes = Get-CimInstance -ClassName Win32_QuickFixEngineering -CimSession $ConnectionDetails.CimSession

    $countAll = $lstHotFixes.Count
    LogText "Hot fixes: $countAll"

    $lstHotFixes | Select-Object @{Name="ComputerName"; Expression={$ConnectionDetails.ComputerName}},
        @{Name="ComputerDomain"; Expression={$ConnectionDetails.ComputerDomain}}, 
        Caption, Description, 
        @{Name="InstallDate"; Expression={if ($_.InstallDate) {$_.InstallDate.ToString("yyyy-MM-dd")} else {""}}}, 
        @{Name="InstalledOn"; Expression={if ($_.InstalledOn) {$_.InstalledOn.ToString("yyyy-MM-dd")} else {""}}},
        Name, Status, CSName, FixComments, HotFixID, InstalledBy, 
        ServicePackInEffect | Export-MyCsv -Path $OutputFile15 -IncludeIndex
}

function GetAccessGroupsMembers {

    try {

        LogTimeAndText  "Getting Access Groups Members"
    
        # Define the SIDs for the groups
        $groupSIDs = @(
            @{ Name = "Administrators"; SID = "S-1-5-32-544" },
            @{ Name = "Remote Desktop Users"; SID = "S-1-5-32-555" },
            @{ Name = "Users"; SID = "S-1-5-32-545" }
        )

        $allMembers = @()

        foreach ($group in $groupSIDs) {
            
            # Get the group using its SID
            LogText "Querying Win32_Group: $($group.Name) " -NoNewLine
            $win32Group = Get-CimInstance -ClassName Win32_Group -Filter "SID = '$($group.SID)' AND Domain = '$($ConnectionDetails.ComputerName)'" -CimSession $ConnectionDetails.CimSession 

            if ($win32Group) {
                LogText "Localised Name: $($win32Group.Name) " -NoNewLine

                # Get members of the group
                #$groupMembers = Get-CimAssociatedInstance -InputObject $currentGroup -ResultClassName Win32_UserAccount -CimSession $ConnectionDetails.CimSession
                
                # The GroupComponent property contains the group's domain and name in a specific format
                $groupUsers = Get-CimInstance -ClassName Win32_GroupUser -Filter "GroupComponent = `"Win32_Group.Domain='$($win32Group.Domain)',Name='$($win32Group.Name)'`"" -CimSession $ConnectionDetails.CimSession
                
                LogText "Members: $(($groupUsers | Measure-Object).Count) "
                # Add members to the allMembers list
                $groupUsers | ForEach-Object {
                    $member = $_.PartComponent
                    #$type = if ($member.AccountType -eq 512 -or $member.AccountType -eq 514) { "User" } else { "Group" }

                    # Compare member domain with the computer name (case insensitive)
                    $memberDomain = $member.Domain
                    if ($memberDomain -ieq $ConnectionDetails.ComputerName) {
                        $memberDomain = "LOCALDEVICE"
                    }

                    $allMembers += [PSCustomObject][Ordered]@{
                        ComputerName   = $ConnectionDetails.ComputerName
                        ComputerDomain = $ConnectionDetails.ComputerDomain
                        GroupName      = $group.Name
                        GroupLocalName = $win32Group.Name
                        Member         = $member.Name
                        MemberDomain   = $memberDomain   # Add member domain
                        Class          = $member.CimClass.CimClassName
                        ClassMember    = $member.CimClass.CimClassName + ":" + $member.Name
                    }
                }
            } else {
                LogText "Not Found"
            }
        }

        $countAll = $allMembers.Count
        $ResultsSummary.AccessGroupMembers = $countAll
        LogText "Access Group Members: $countAll"

        $allMembers | Export-MyCsv -Path $OutputFile13 -IncludeIndex
    }
    catch {
        LogLastException
    }
}


function LogSummary {
    
    $strResult = $ConnectionDetails.Error
    $strErrorDetails = $ConnectionDetails.ErrorDetails

    # In case we encounter no critical errors with the scan (such as missing System, Application, Cluster or Services info) and
    # we have at least reached the SystemInfo file generation function (in this case, $ResultsSummary.OperatingSystem won't be empty),
    # we evaluate this scan result as successful.
    if ($ResultsSummary.CriticalScanError -eq $false -and $ResultsSummary.OperatingSystem -ne "") {
        if ($ResultsSummary.SoftwareRecordsTotal -gt 0) {
            $strResult = "Success"
        }else{ # at least one application is normally expected on a device
            $strResult = "Success with Warning"
            if ($strErrorDetails -eq "") {
                $strErrorDetails = "No software installed identified"
            }else{
                $strErrorDetails = "No software installed identified`r`n-----`r`n" + $strErrorDetails
            }
        }
    } 

    # In case we encounter critical error(-s) with the scan (such as missing System, Application, Cluster or Services info) and
    # we have detailed message captured as well, we add this to the Status ErrorDetails.
    if ($ResultsSummary.CriticalScanError -eq $true -and $ResultsSummary.CriticalScanErrorMessage -ne "") {
        if ($strErrorDetails -eq "") {
            $strErrorDetails = $ResultsSummary.CriticalScanErrorMessage
        }else{
            $strErrorDetails += "`r`n$($ResultsSummary.CriticalScanErrorMessage)"
        }
    } 

    # In case we encounter specific issues with the target device, we attempt to detail it further if information is available.
    if ($strResult -eq "Name Not Found" -or $strResult -eq "No Response") {
        if ($LastADLogon) {
            try {
                $daysElapsed = ((Get-Date) - $LastADLogon).Days
                LogText "Last logon: $LastADLogon"
                LogText "Days since last logon: $daysElapsed"
                if ($daysElapsed -gt 60){
                    $strResult = "Possibly Decommissioned"
                }
            } catch {
            }
        }
    }

    # Safety measure to ensure the Result is not left empty.
    if ($strResult -eq "") {$strResult = "Unknown Error"}

    Set-Content -Path $OutputFile19 -Value $strResult

    if ($SummaryLogFile) {
        $durationInSeconds = [math]::Ceiling((New-TimeSpan -Start $ResultsSummary.StartTime -End (Get-Date)).TotalSeconds)

        $strScanUserName = $UserName
        if (!($strScanUserName)) {
            $strScanUserName = "$($env:USERNAME)@$($env:USERDNSDOMAIN)" 
        }
    
        $LogSummary = [PSCustomObject][ordered]@{
            ScanTime                = $ResultsSummary.StartTime
            ScanComputerName        = $env:COMPUTERNAME
            ScanUserName            = $strScanUserName
            Target                  = $ConnectionDetails.TargetName
            ComputerName            = $ConnectionDetails.ComputerName
            ComputerDomain          = $ConnectionDetails.ComputerDomain
            OperatingSystem         = if ($ResultsSummary.OperatingSystem) { $ResultsSummary.OperatingSystem } else { $OperatingSystem }
            Result                  = $strResult
            ErrorDetails            = $strErrorDetails
            SoftwareRecords         = $ResultsSummary.SoftwareRecords
            WindowsServices         = $ResultsSummary.WindowsServices
            SoftwareLicenseRecords  = $ResultsSummary.SoftwareLicenseRecords
            MSIInstallerEvents      = $ResultsSummary.MSIInstallerEvents
            LogonEvents             = $ResultsSummary.LogonEvents
            DurationInSeconds       = $durationInSeconds
            ConnectionType          = GetConnectionType
        }

        $mutex = New-Object 'System.Threading.Mutex' $false, "S3GetInventoryLogSummaryMutex"
        try {
            # Wait until the mutex is available
            $mutex.WaitOne() | Out-Null

            # Safely append to the CSV
            $LogSummary | Export-MyCsv -Path $SummaryLogFile -Append
        }
        finally {
            # Release the mutex
            $mutex.ReleaseMutex()
        }
    }
}

Get-ComputerInventory


