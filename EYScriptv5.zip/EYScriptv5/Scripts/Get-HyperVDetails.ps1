 ##########################################################################
 # 
 # Get-HyperVDetails
 #
 ##########################################################################
 
<#
.SYNOPSIS
Retrieves physical host, virtual machine and virtual machine start up activity from a Hyper-V server

.DESCRIPTION
The Get-HyperVVMList script queries a single HyperV server and produces 3 CSV files
    1)    HyperVExportVMs1.csv - One record per virtual machine including fields like 
          VM name, IP, OS, Enabled state, Physical host name etc. Some data is retrieved through WMI
          and some data is retrieved through PowerShell Hyper-V module (requires Windows Server 2012 R2 or later)
    2)    HyperVExportHosts.csv - One record per Hyper-V server. The data is retrieved through 
          PowerShell Hyper-V module and requires Windows Server 2012 R2 or later
    3)    HyperVExportStartEvents.csv - One record per VM start event. 

Files are written to current working directory

.PARAMETER Server 
Host name of Hyper-V server to scan

.EXAMPLE
Get all guest, host and migration info from Hyper-V server 'Defiant'. 
Get-HyperVDetails -ComputerName Defiant
Get-HyperVDetails -ComputerName Defiant -username Administrator -password ***password***

.NOTES
File 3 & 4 will only contain data when querying Hyper-V servers with Windows Server 2012 R2 onwards installed.

.COPYRIGHT
Copyright (C) 2024 Ernst & Young Global Limited. All rights reserved. The Irish firm Ernst & Young is a member practice of Ernst & Young Global Limited.

This script is proprietary to Ernst & Young Global Limited (or one of its member firms). Unauthorized copying of this file, via any medium, is strictly prohibited. Redistribution and use in source and binary forms, with or without modification, are not permitted without prior written permission from Ernst & Young Global Limited.

.LICENSE
This script is provided "AS IS" without warranty of any kind. Ernst & Young Global Limited expressly disclaims all warranties, whether express, implied, statutory, or otherwise, with respect to this script including all implied warranties of merchantability, fitness for a particular purpose, and non-infringement. In no event shall Ernst & Young Global Limited be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this script, even if advised of the possibility of such damage.

#>

Param(
    [alias("server")]
    $ComputerName = $env:COMPUTERNAME,
    [string] $UserName,
    [string] $Password,
    [string] $OutputFolder = ".\",
    [string] $OutputFilePrefix = "",
    [alias("o1")]
    $OutputFile1 = "HyperVVMs.csv",
    [alias("o2")]
    $OutputFile2 = "HyperVHosts.csv",
    [alias("o3")]
    $OutputFile3 = "HyperVVMStartEvents.csv",
    [alias("o4")]
    [string] $LogFile = "HyperVLog.txt",
    [ValidateSet("AllData","VMData")] 
    $RequiredData = "VMData",
    [ValidateSet("All","Servers","Clients")] 
    [string] $TargetType = "All",
    [switch] $MicrosoftOnly,
    [switch] $Verbose)


$ScriptDescription =       "Hyper-V Scan"
$ScriptVersion =           "5.0.10"
$ConnectivityTestPorts =   @(135, 139, 5985, 5986)


#region Logging
$script:OutFileSupportsNoNewLine = $false;
function InitialiseLogFile {

    if (!($script:OutputFolder)) {
        $script:OutputFolder = ".\"
    }

    if (!(Test-Path $script:OutputFolder)) {
        New-Item -ItemType Directory -Path $script:OutputFolder | Out-Null
    }

    $script:OutputFolder = Resolve-Path $script:OutputFolder | Select-Object -ExpandProperty Path

    if (!($script:OutputFolder.EndsWith('\'))) {
        $script:OutputFolder += '\'
    }

    if ($script:OutputFolder -and !($LogFile -like "*\*")) {
        $script:LogFile = Join-Path $script:OutputFolder "$($OutputFilePrefix)$LogFile"
    }

    if ($LogFile -and (Test-Path $LogFile)) {
        Remove-Item $LogFile
    }

    if ((Get-Command "Out-File").parameters["NoNewline"]) {
        $script:OutFileSupportsNoNewLine = $true;
    }

    PrefixOutputFilesWithFolder
    DecryptPassword
}

function PrefixOutputFilesWithFolder {
    
    # Check if $OutputFolder exists and is not empty
    if ($script:OutputFolder) {
        $counter = 1
        while ($true) {
            $outputFileVarName = "OutputFile$counter"
            # Check if the OutputFile variable exists
            if (Get-Variable -Name $outputFileVarName -Scope Script -ErrorAction SilentlyContinue) {
                # Get the value of the OutputFile variable
                $outputFileValue = Get-Variable -Name $outputFileVarName -ValueOnly -Scope Script
                # Check if it does not contain a backslash, and if so, prefix with OutputFolder
                if (-not $outputFileValue.Contains("\"))
                {
                    Set-Variable -Name $outputFileVarName -Value (Join-Path $script:OutputFolder "$($OutputFilePrefix)$outputFileValue") -Scope Script
                }
                $counter++
            } else {
                # Exit loop if the variable does not exist
                break
            }
        }
    }
} 

function LogText {
    param(
        [Parameter(Position=0, ValueFromRemainingArguments=$true, ValueFromPipeline=$true)]
        [Object] $Object,
        [System.ConsoleColor]$Color = [System.Console]::ForegroundColor,
        [switch]$NoNewLine = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"
    )

    if ($LogTo -ne "File") {
        # Display text on screen
        Write-Host -Object $Object -ForegroundColor $Color -NoNewline:$NoNewLine
    }
    
    if ($LogTo -ne "Console") {
        if ($LogFile) {
            if ($script:OutFileSupportsNoNewLine) {
                $Object | Out-File $LogFile -Encoding utf8 -Append -NoNewline:$NoNewLine 
            }
            else {
                $Object | Out-File $LogFile -Encoding utf8 -Append 
            }
        }
    }
}

function LogTimeAndText {
    param(
        [string] $Text,
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Blue,
        [switch]$IncludeDate = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    $output = "";
    if ($IncludeDate) {
        $output = Get-Date -Format "yyyy-MM-dd HH:mm:ss.ff"
    } else {
        $output = Get-Date -Format "HH:mm:ss.ff"
    }

    $output += " - "
    $output += $Text
    LogText $output -Color $Color -LogTo $LogTo
}

function LogError([string[]]$errorDescription){
    if ($Verbose){
        LogText ""
    }

    $output = $errorDescription -join "`r`n              "
    LogTimeAndText $output -Color Red

    Start-Sleep -s 3
}

function LogLastException() {
    $currentException = $Error[0].Exception;

    while ($currentException)
    {
        LogText -Color Red $currentException
        LogText -Color Red $currentException.Data
        LogText -Color Red $currentException.HelpLink
        LogText -Color Red $currentException.HResult
        LogText -Color Red $currentException.Message
        LogText -Color Red $currentException.Source
        LogText -Color Red $currentException.StackTrace
        LogText -Color Red $currentException.TargetSite

        $currentException = $currentException.InnerException
    }

    Start-Sleep -s 3
}

$script:MostRecentActivity = ""
function LogProgress([string]$Activity, [string]$Status, [Int32]$PercentComplete, [switch]$Completed ){
    
    if ($Activity) {
        $script:MostRecentActivity = $Activity
    } else {
        if ($script:MostRecentActivity) {
            $Activity = $script:MostRecentActivity
        } else {
            $Activity = "Unspecified"
        }
    }
    Write-Progress -activity $Activity -Status $Status -percentComplete $PercentComplete -Completed:$Completed
    LogTimeAndText $Status
}

function GetScriptPath
{
    if($PSCommandPath){
        return $PSCommandPath; }
        
    if($MyInvocation.ScriptName){
        return $MyInvocation.ScriptName }
        
    if($script:MyInvocation.MyCommand.Path){
        return $script:MyInvocation.MyCommand.Path }

    return $script:MyInvocation.MyCommand.Definition
}

function GetDotNetFrameworkVersion {
    #$release = Get-ItemPropertyValue -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release
    $regKey = Get-Item -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    $release = $regKey.GetValue("Release")
    switch ($release) {
        { $_ -ge 533320 } { $version = "4.8.1 or later ($release)"; break }
        { $_ -ge 528040 } { $version = "4.8 ($release)"; break }
        { $_ -ge 461808 } { $version = "4.7.2 ($release)"; break }
        { $_ -ge 461308 } { $version = "4.7.1 ($release)"; break }
        { $_ -ge 460798 } { $version = "4.7 ($release)"; break }
        { $_ -ge 394802 } { $version = "4.6.2 ($release)"; break }
        { $_ -ge 394254 } { $version = "4.6.1 ($release)"; break }
        { $_ -ge 393295 } { $version = "4.6 ($release)"; break }
        { $_ -ge 379893 } { $version = "4.5.2 ($release)"; break }
        { $_ -ge 378675 } { $version = "4.5.1 ($release)"; break }
        { $_ -ge 378389 } { $version = "4.5 ($release)"; break }
        default { $version = $null; break }
    }

    return $version
}

function LogEnvironmentDetails ([string[]] $OtherDetails){

    $script:ScriptPath = GetScriptPath
    $script:ScriptName = split-path $ScriptPath -leaf

    LogText " "
    LogHeaderText -FrameLine 
    LogHeaderText -LeftText " _______     __" -LeftColor Yellow
    LogHeaderText -LeftText "|  ___\ \   / /" -LeftColor Yellow
    LogHeaderText -LeftText "| |__  \ \_/ / " -LeftColor Yellow
    LogHeaderText -LeftText "|  __|  \   /  " -LeftColor Yellow
    LogHeaderText -LeftText "| |____  | |   " -LeftColor Yellow -RightText "$ScriptDescription  "
    LogHeaderText -LeftText "|______| |_|   " -LeftColor Yellow -RightText "Version $ScriptVersion  "
    LogHeaderText
    LogHeaderText -FrameLine 

    LogText " "
    LogText " $ScriptName" -Color Green 
    LogText " "

    if ($PSVersionTable.PSVersion.Major -ge 3) {
        $oSDetails = Get-CimInstance -ClassName Win32_OperatingSystem
    } else {
        $oSDetails = Get-WmiObject -Class Win32_OperatingSystem
    }
    $elevated = [bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")
    $currentThread = [System.Threading.Thread]::CurrentThread
    $dotNetFrameworkVersion = GetDotNetFrameworkVersion
    LogText -Color Gray "Computer Name:          $($env:COMPUTERNAME)"
    LogText -Color Gray "User Name:              $($env:USERNAME)@$($env:USERDNSDOMAIN)"
    LogText -Color Gray "Windows Version:        $($oSDetails.Caption)($($oSDetails.Version))"
    LogText -Color Gray "Memory kB:              $($oSDetails.TotalVisibleMemorySize.ToString("N0")) ($($oSDetails.FreePhysicalMemory.ToString("N0")) Free)"
    LogText -Color Gray "Locale:                 $($oSDetails.Locale) (Language $($oSDetails.OSLanguage))"
    LogText -Color Gray "PowerShell Host:        $($host.Version.Major)"
    LogText -Color Gray "PowerShell Version:     $($PSVersionTable.PSVersion)"
    LogText -Color Gray "PowerShell Word Size:   $($([IntPtr]::size) * 8) bit"
    LogText -Color Gray "Script Path:            $ScriptPath"
    LogText -Color Gray "Working Directory:      $PWD"
    LogText -Color Gray "CLR Version:            $($PSVersionTable.CLRVersion)"
    LogText -Color Gray ".Net Framework Version: $dotNetFrameworkVersion"
    LogText -Color Gray "Elevated:               $elevated"
    LogText -Color Gray "Current Date Time:      $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
    LogText -Color Gray "Default Date Format:    $($CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern)"
    LogText -Color Gray "Current Culture:        $((Get-Culture).EnglishName) (UI: $((Get-UICulture).EnglishName))"
    
    if (Test-Path "Variable:OutputFolder") {
        LogText -Color Gray "Output Folder:          $OutputFolder" 
    }
    if (Test-Path "Variable:OutputFile1") {
        LogText -Color Gray "Output File 1:          $OutputFile1" 
    }
    if (Test-Path "Variable:LogFile") {
        LogText -Color Gray "Log File:               $LogFile" 
    }
    if (Test-Path "Variable:ComputerName") {
        LogText -Color Gray "Target Computer Name:   $ComputerName" 
    }
    if (Test-Path "Variable:UserName") {
        LogText -Color Gray "Script User Name:       $UserName"
    }
    if (Test-Path "Variable:MicrosoftOnly") {
        LogText -Color Gray "Microsoft Only:         $MicrosoftOnly"
    }
    if (Test-Path "Variable:TargetType") {
        LogText -Color Gray "Target Type:            $TargetType"
    }
    if (Test-Path "Variable:ScriptRegime") {
        LogText -Color Gray "Script Regime:          $ScriptRegime"
    }
    if (Test-Path "Variable:RequiredData") {
        LogText -Color Gray "Required Data:          $RequiredData"
    }

    foreach ($detail in $OtherDetails){
        LogText -Color Gray $detail
    }

    LogText -Color Gray ""

}

function LogHeaderText {
    param(
        [string] $LeftText = " ",
        [System.ConsoleColor]$LeftColor = [System.ConsoleColor]::Blue,
        [string] $RightText,
        [System.ConsoleColor]$RightColor = [System.ConsoleColor]::DarkGray,
        [char] $FrameChar = "#",
        [switch] $FrameLine,
        [switch] $LeftAlignRightText,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    if ($FrameLine) {
        $strFullText = "  " + ($FrameChar.ToString() * 69)
        LogText $strFullText -Color DarkGray -LogTo $LogTo
        return
    }

    $strLeftFrame = "  $FrameChar  "
    $strLeftText = $LeftText
    $strRightText = $RightText
    $strRightFrame = "  $FrameChar"
    if ($LeftAlignRightText) {
        $strRightText = $RightText.PadRight(63 - $LeftText.Length)
    } else {
        $strLeftText = $LeftText.PadRight(63 - $RightText.Length)
    }
    

    if ($LogTo -eq "Console" -or $LogTo -eq "Both") {
        LogText $strLeftFrame -LogTo "Console" -NoNewLine -Color DarkGray
        LogText $strLeftText -LogTo "Console" -NoNewLine -Color $LeftColor
        LogText $strRightText -LogTo "Console" -NoNewLine -Color $RightColor
        LogText $strRightFrame -LogTo "Console" -Color DarkGray
    }

    if ($LogTo -eq "File" -or $LogTo -eq "Both") {
        $strFullText = $strLeftFrame + $strLeftText + $strRightText + $strRightFrame
        LogText $strFullText -LogTo "File" 
    }
}

function DecryptPassword {
    $strOneTimePassword = "%OneTimePassword%" # Replace this with the one-time password
    if ($SecurePassword) {
        $baOneTimePassword = [System.Convert]::FromBase64String($strOneTimePassword)
        $baSecurePassword = [System.Convert]::FromBase64String($SecurePassword)
        for($i=0; $i -lt $baSecurePassword.count ; $i++)
        {
            $baSecurePassword[$i] = $baSecurePassword[$i] -bxor $baOneTimePassword[$i%$baOneTimePassword.Length]
        }
        $script:Password = [System.Text.Encoding]::Unicode.GetString($baSecurePassword);
    }
}
#endregion 

#region Setup Output Formats
function SetupOutputFormats {
    # Standardise date/time output to ISO 8601'ish format
    $bOutputFormatsUpdated = $false
    $currentThread = [System.Threading.Thread]::CurrentThread
    $desiredShortPattern = 'yyyy-MM-dd'
    $desiredLongPattern = 'yyyy-MM-dd HH:mm:ss'

    try {
        $cultureInvariant = [CultureInfo]::InvariantCulture.Clone()
        $cultureInvariant.DateTimeFormat.ShortDatePattern = $desiredShortPattern
        $cultureInvariant.DateTimeFormat.LongDatePattern = $desiredLongPattern
        $cultureInvariant.NumberFormat.NumberGroupSeparator = ""  
        $cultureInvariant.NumberFormat.NumberDecimalSeparator = "."
        $currentThread.CurrentCulture = $cultureInvariant
        $bOutputFormatsUpdated = $true
    }
    catch {
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $currentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $currentThread.CurrentCulture.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $currentThread.CurrentCulture.NumberFormat.NumberGroupSeparator = ""  
            $currentThread.CurrentCulture.NumberDecimalSeparator = "."
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $cultureCopy = $currentThread.CurrentCulture.Clone()
            $cultureCopy.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $cultureCopy.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $cultureCopy.NumberFormat.NumberGroupSeparator = ""  
            $cultureCopy.NumberDecimalSeparator = "."
            $currentThread.CurrentCulture = $cultureCopy
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread using clone of current culture"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        LogText "Failed to update output formats"
    }
}
#endregion

#region Query User
function QueryUser([string]$Message, [string]$Prompt, [switch]$AsSecureString = $false, [string]$DefaultValue){
    $strResult = ""
    
    if ($Message) {
        LogText $Message -color Yellow
    }

    if ($DefaultValue) {
        $Prompt += " (Default [$DefaultValue])"
    }

    $Prompt += ": "
    LogText $Prompt -color Yellow -NoNewLine
    
    if ($Headless) {
        LogText " (Headless - Using Default Value)" -color Yellow
    }
    else {
        $strResult = Read-Host -AsSecureString:$AsSecureString
    }

    if(!$strResult -or ($strResult.Length -eq 0)) {
        $strResult = $DefaultValue
        if ($AsSecureString) {
            $strResult = ConvertTo-SecureString $strResult -AsPlainText -Force
        }
    }

    return $strResult
}

function Get-ConsoleCredential([String] $Message, [String] $DefaultUsername, [switch] $AsPSCredential)
{
    $strUsername = QueryUser -Message $Message -Prompt "Username" -DefaultValue $DefaultUsername
    if (!$strUsername){
        return $null
    }

    $strSecurePassword = QueryUser -Prompt "Password" -AsSecureString
    if (!$strSecurePassword){
        return $null
    }

    if ($AsPSCredential) {
        $Creds = New-Object System.Management.Automation.PSCredential ($strUsername, $strSecurePassword)
    } else {
        $Creds = New-Object PSObject

        $bstrSecurePassword = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($strSecurePassword)
        $strUnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstrSecurePassword)

        $Creds | Add-Member -MemberType NoteProperty -Name "UserName" -Value $strUsername
        $Creds | Add-Member -MemberType NoteProperty -Name "Password" -Value $strUnsecurePassword
    }

    return $Creds
}
#endregion

#region Test Connection
$script:ConnectionDetails = [PSCustomObject][ordered]@{
    TargetName = ""
    ComputerName = ""
    ComputerDomain = ""
    IPAddress0 = ""
    NameResolution = [Nullable[bool]]$null
    Ping = [Nullable[bool]]$null
    PortSSH = [Nullable[bool]]$null
    PortHTTP = [Nullable[bool]]$null
    PortWMI = [Nullable[bool]]$null
    PortSMB1 = [Nullable[bool]]$null
    PortHTTPS = [Nullable[bool]]$null
    PortSMB2 = [Nullable[bool]]$null
    PortSQL = [Nullable[bool]]$null
    PortRDP = [Nullable[bool]]$null
    PortWinRM = [Nullable[bool]]$null
    PortWinRMS = [Nullable[bool]]$null 
    OtherPorts = @{}
    Error = ""
    ErrorDetails = ""
    CimConnectionType = $null
    CimSession = $null
    PSSession = $null
    HKLM = $null
    HKU = $null
}

function TestConnectivity {
    param(
        [string] $Target,
        [int[]] $Ports = @(22, 80, 135, 139, 443, 445, 1433, 3389, 5985, 5986)
    )

    $ConnectionDetails.TargetName = $Target
    $ConnectionDetails.ComputerName = $Target

    # Test name resolution
    LogText "Name Resolution: " -NoNewLine -Color Gray
    $ConnectionDetails.NameResolution = $false;
    try {
        $nameResolutionResult = [System.Net.Dns]::GetHostAddresses($Target)
        if ($nameResolutionResult.Count -gt 0) {
            $ConnectionDetails.IPAddress0 = $nameResolutionResult[0].IPAddressToString
            $ConnectionDetails.NameResolution = $true;
        }
    } catch {}
    
    if ($ConnectionDetails.NameResolution) {
        LogText "Succeeded" -Color Green
    } else {
        LogText "Failed" -Color Red
        return;
    }
    
    # Test Ping
    LogText "Ping: " -NoNewLine -Color Gray
    $ConnectionDetails.Ping = $false;
    try {
        $pingResult = Test-Connection -ComputerName $Target -Count 1 -ErrorAction SilentlyContinue
        if ($pingResult.StatusCode -eq 0) {
            $ConnectionDetails.Ping = $true
        } else {
            $ConnectionDetails.Ping = $false
        }
    } catch {}
    
    if ($ConnectionDetails.Ping) {
        LogText "Succeeded" -Color Green
    } else {
        LogText "Failed" -Color Red
    }
    
    # Test Ports
    LogText "Port Scan: " -NoNewLine -Color Gray

    $sockets = @()
    $asyncResults = @()

    # Start connections
    foreach ($port in $Ports) {
        $socket = New-Object System.Net.Sockets.TcpClient
        $sockets += $socket

        $asyncResult = $socket.BeginConnect($Target, $port, $null, $null)
        $asyncResults += $asyncResult
    }

    # Wait for 2 seconds or until all sockets have connected
    $timeout = 2000
    $endTime = (Get-Date).AddMilliseconds($timeout)

    foreach ($asyncResult in $asyncResults) {
        $remainingTime = ($endTime - (Get-Date)).TotalMilliseconds
        if ($remainingTime -le 0) {
            break
        }
        $asyncResult.AsyncWaitHandle.WaitOne($remainingTime) | Out-Null
    }

    # Check the status of each socket
    for ($i = 0; $i -lt $sockets.Count; $i++) {
        $socket = $sockets[$i]
        $port = $ports[$i]

        switch ($port) {
            22 {
                $ConnectionDetails.PortSSH = $socket.Connected
            }
            80 {
                $ConnectionDetails.PortHTTP = $socket.Connected
            }
            135 {
                $ConnectionDetails.PortWMI = $socket.Connected
            }
            139 {
                $ConnectionDetails.PortSMB1 = $socket.Connected
            }
            443 {
                $ConnectionDetails.PortHTTPS = $socket.Connected
            }
            445 {
                $ConnectionDetails.PortSMB2 = $socket.Connected
            }
            1433 {
                $ConnectionDetails.PortSQL = $socket.Connected
            }
            3389 {
                $ConnectionDetails.PortRDP = $socket.Connected
            }
            5985 {
                $ConnectionDetails.PortWinRM = $socket.Connected
            }
            5986 {
                $ConnectionDetails.PortWinRMS = $socket.Connected
            }
            default {
                $ConnectionDetails.OtherPorts.Add($port, $socket.Connected)
            }
        }

        # Close the socket
        $socket.Close()
    }

    LogConnectionResult -PortName "SSH" -Result $ConnectionDetails.PortSSH;
    LogConnectionResult -PortName "HTTP" -Result $ConnectionDetails.PortHTTP;
    LogConnectionResult -PortName "WMI" -Result $ConnectionDetails.PortWMI;
    LogConnectionResult -PortName "SMB" -Result $ConnectionDetails.PortSMB1;
    LogConnectionResult -PortName "HTTPS" -Result $ConnectionDetails.PortHTTPS;
    LogConnectionResult -PortName "SQL" -Result $ConnectionDetails.PortSQL;
    LogConnectionResult -PortName "RDP" -Result $ConnectionDetails.PortRDP;
    LogConnectionResult -PortName "WinRM" -Result $ConnectionDetails.PortWinRM;
    LogConnectionResult -PortName "WinRMS" -Result $ConnectionDetails.PortWinRMS;
    LogText ""

    # OtherPorts
}

function LogConnectionResult {
    param(
        [string] $PortName,
        $Result
    )

    if ($null -eq $Result) {
        return;
    }

    $resultText = "Failed"
    $colour = [System.ConsoleColor]::Yellow;
    if ($Result) {
        $resultText = "Succeeded"
        $colour = [System.ConsoleColor]::Green;
    }

    LogText "$PortName " -NoNewLine -Color $colour -LogTo Console
    LogText "$($PortName): $resultText"  -LogTo File
}
#endregion

#region Connect To Computer
function ConnectToComputer ($ComputerName) {

    try {
        LogTimeAndText "Connecting to $ComputerName"

        if ($UserName -and -not $Password) {
            $creds = Get-ConsoleCredential -DefaultUsername $UserName
            if (!($creds) -or !($creds.Password)) {
                LogError "Password Required"
                return $false
            }

            $script:Password = $creds.Password
        } 

        TestConnectivity -Target $ComputerName -Ports $ConnectivityTestPorts

        if ($ConnectionDetails.NameResolution -eq $false) {
            $ConnectionDetails.ErrorDetails = "Device name could not be resolved"
            $ConnectionDetails.Error = "Name Not Found"
            return $false
        }

        if ($ConnectionDetails.PortWinRMS) {
            # Try to connect using WinRM over https
            LogText "Connecting using WinRM over HTTPS"
            if (CreateCimAndPSSession -UseSSL) {
                $ConnectionDetails.CimConnectionType = "WinRMS"
            }
        }

        if ((!($ConnectionDetails.CimConnectionType)) -and $ConnectionDetails.PortWinRM) {
            # Try to connect using WinRM over http
            LogText "Connecting using WinRM over HTTP"
            if (CreateCimAndPSSession) {
                $ConnectionDetails.CimConnectionType = "WinRM"
            }
        }

        if ((!($ConnectionDetails.CimConnectionType)) -and $ConnectionDetails.PortWMI) {
            # Try to connect using DCOM
            LogText "Connecting using DCOM"
            if (CreateCimAndPSSession -UseDCOM) {
                $ConnectionDetails.CimConnectionType = "DCOM"
            }
        }

        if ($ConnectionDetails.PortSMB1) {
            # Try to connect to Remote Registry service
            LogText "Connecting to Remote Registry"
            ConnectToRegistry | Out-Null
        }

        if ((IsRegistryConnected) -or (IsCimConnected)) {
            # Successfully connected using 1 or more connection methods
            return $true
        }

        if (!$ConnectionDetails.Error) {

            if ($ConnectionDetails.Ping -or $ConnectionDetails.PortSSH -or $ConnectionDetails.PortHTTP -or
                $ConnectionDetails.PortWMI -or $ConnectionDetails.PortSMB1 -or $ConnectionDetails.PortHTTPS -or
                $ConnectionDetails.PortSMB2 -or $ConnectionDetails.PortSQL -or $ConnectionDetails.PortRDP -or
                $ConnectionDetails.PortWinRM -or $ConnectionDetails.PortWinRMS) {
                
                # We were able to connect on one or more ports, but not using WinRM or DCOM
                $ConnectionDetails.ErrorDetails = "Device responded, but WinRM and DCOM WMI) services were not available"
                $ConnectionDetails.Error = "Blocked By Firewall"
            } elseif ($ConnectionDetails.ErrorDetails -like "*0x800706ba*" -or 
                $ConnectionDetails.ErrorDetails -like "*The RPC server is unavailable*") {
                $ConnectionDetails.Error = "RPC Unavailable"
            } else {
                # No response from target device
                $ConnectionDetails.ErrorDetails = "The device did not respond"
                $ConnectionDetails.Error = "No Response"
            }
        }
    } catch {
        $ConnectionDetails.Error = "Unexpected Error"
        $ConnectionDetails.ErrorDetails = $Error[0].Exception.ToString()
    }
    
    LogText -Color Red "Unable to connect to $ComputerName ($($ConnectionDetails.Error))"
    LogText  "Error Details:`r`n($($ConnectionDetails.ErrorDetails))"

    return $false
}

function CreateCimAndPSSession {
    param(
        [switch] $UseSSL,
        [switch] $UseDCOM
    )

    try {
        $paramsCimOptions = @{}
        $paramsCimSession = @{}
        $paramsPSOptions = @{}
        $paramsPSSession = @{}

        if ($UseDCOM) {
            $paramsCimOptions["Protocol"] = "DCOM"
        } else {
            if ($UseSSL) {
                # $paramsCimOptions["Protocol"] = "Wsman" This is assumed for this parameter set.
                $paramsCimOptions["UseSsl"] = $true
                $paramsCimSession["Port"] = 5986

                $paramsPSSession["UseSsl"] = $true

                if ($IgnoreCertificateErrors) {
                    $paramsCimOptions["SkipCACheck"] = $true
                    $paramsCimOptions["SkipCNCheck"] = $true
                    $paramsCimOptions["SkipRevocationCheck"] = $true

                    $paramsPSOptions["SkipCACheck"] = $true
                    $paramsPSOptions["SkipCNCheck"] = $true
                    $paramsPSOptions["SkipRevocationCheck"] = $true
                } 
            } else {
                $paramsCimOptions["Protocol"] = "Wsman"
                $paramsCimSession["Port"] = 5985
            }
        }

        if ($UserName -and $Password) {
            $credential = New-Object System.Management.Automation.PSCredential -ArgumentList $Username, (ConvertTo-SecureString -String $Password -AsPlainText -Force)
            $paramsCimSession["Credential"] = $credential
            $paramsPSSession["Credential"] = $credential
        }

        $paramsCimSession["SessionOption"] = New-CimSessionOption @paramsCimOptions
        $paramsCimSession["ComputerName"] = $ComputerName
        $paramsCimSession["ErrorVariable"] = "NewSessionError"
        $paramsCimSession["ErrorAction"] = "SilentlyContinue"

        $paramsPSSession["SessionOption"] = New-PSSessionOption @paramsPSOptions
        $paramsPSSession["ComputerName"] = $ComputerName
        $paramsPSSession["ErrorVariable"] = "NewSessionError"
        $paramsPSSession["ErrorAction"] = "SilentlyContinue"

        # Splat the parameters onto New-CimSession
        $ConnectionDetails.CimSession = New-CimSession @paramsCimSession
        if (!($UseDCOM)) {
            $ConnectionDetails.PSSession = New-PSSession @paramsPSSession
        }
        
        if (!($ConnectionDetails.CimSession)) {
            $ConnectionDetails.ErrorDetails = $NewSessionError[0] | Out-String
            $ConnectionDetails.Error = "Error"

            if ($ConnectionDetails.ErrorDetails -like "*0x80070005*" -or 
                $ConnectionDetails.ErrorDetails -like "*PermissionDenied*"  -or 
                $ConnectionDetails.ErrorDetails -like "*Access is denied*") {
                $ConnectionDetails.Error = "Access Denied"
            } elseif ($ConnectionDetails.ErrorDetails -like "*0x803380e4*" -or 
                $ConnectionDetails.ErrorDetails -like "*HTTPS transport must be used*") {
                $ConnectionDetails.Error = "Untrusted Device"
            }

            return $false
        }

        # Test the connection - This could throw an exception
        $win32CS = Get-CimInstance -ClassName Win32_ComputerSystem -CimSession $ConnectionDetails.CimSession
        $ConnectionDetails.ComputerName = $win32CS.Name
        if (!([string]::IsNullOrEmpty($win32CS.Domain))) {
            $ConnectionDetails.ComputerDomain = $win32CS.Domain
        }

        return $true

    } catch {
        $ConnectionDetails.ErrorDetails = $Error[0].Exception.ToString();
        $ConnectionDetails.Error = "Exception"
    }

    return $false
}

Add-Type @"
    using System;
    using System.Runtime.InteropServices;
    public class NetworkConnection {
        [DllImport("mpr.dll")]
        public static extern int WNetAddConnection2(ref NETRESOURCE netResource,
            string password, string username, uint flags);

        [DllImport("mpr.dll")]
        public static extern int WNetCancelConnection2(string name, uint flags,
            bool force);

        [StructLayout(LayoutKind.Sequential)]
        public struct NETRESOURCE {
            public int dwScope;
            public int dwType;
            public int dwDisplayType;
            public int dwUsage;
            public string lpLocalName;
            public string lpRemoteName;
            public string lpComment;
            public string lpProvider;
        }
    }
"@

function ConnectToRegistry {
    try {

        if ($UserName -and $Password) {
            $netResource = New-Object NetworkConnection+NETRESOURCE
            $netResource.dwType = 1 # RESOURCETYPE_DISK
            $netResource.lpRemoteName = "\\$ComputerName\IPC$"
            $flags = 4 # CONNECT_TEMPORARY

            $result = [NetworkConnection]::WNetAddConnection2([ref]$netResource, $Password, $UserName, $flags)
            if ($result -ne 0) {
                LogText "Warning authenticating to Remote Registry: $result"
            }
        }

        $ConnectionDetails.HKLM = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $ComputerName)
        $ConnectionDetails.HKU = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('Users', $ComputerName)
        if ($ConnectionDetails.HKLM) {
            
            $regComputerName = ""
            $subKey = $ConnectionDetails.HKLM.OpenSubKey("SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName")
            if ($subKey) {
                $regComputerName = $subKey.GetValue("ComputerName")
                if (!($ConnectionDetails.ComputerName)) {
                    $ConnectionDetails.ComputerName = $regComputerName
                }
            }

            try {
                $regDomainName = ""
                $subKey = $ConnectionDetails.HKLM.OpenSubKey("SYSTEM\CurrentControlSet\Services\Tcpip\Parameters")
                if ($subKey) {
                    $regDomainName = $subKey.GetValue("Domain")
                    if (!([string]::IsNullOrEmpty($regDomainName))) {
                        if ([string]::IsNullOrEmpty($ConnectionDetails.ComputerDomain)) {
                            $ConnectionDetails.ComputerDomain = $regDomainName
                        }
                    }
                }
            } catch {}
            
            return $true
        }
    } catch {
        LogText "Error authenticating to Remote Registry: $($_.Exception.Message)"
        $ConnectionDetails.HKLM = $null
        $ConnectionDetails.HKU = $null
    }

    return $false
}

function IsRegistryConnected {
    return (($null -ne $ConnectionDetails.HKLM) -and ($null -ne $ConnectionDetails.HKU))
}

function IsCimConnected {
    return ($null -ne $ConnectionDetails.CimConnectionType)
}

function GetConnectionType {
    $strConnectionType = "None"

    if (IsCimConnected) {
        $strConnectionType = $ConnectionDetails.CimConnectionType
    } elseif (IsRegistryConnected) {
        $strConnectionType = "Registry"
    }

    if ($ConnectionDetails.PSSession) {
        $strConnectionType += "+"
    }

    return $strConnectionType
}
#endregion

#region Custom Export
$ScriptExcludeFields = $null
function Export-MyCsv {
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [PSCustomObject[]] $InputObject,
        [Parameter(Mandatory = $true)]
        [string] $Path,
        [switch] $Append,
        [switch] $IncludeIndex
    )

    begin {
        if ($null -eq $ScriptExcludeFields) {
            LoadExcludeFields
        }

        $fileExcludeFields = $null
        $fileID = GetFileNameFinalPart -FilePath $Path
        if ($ScriptExcludeFields.ContainsKey($fileID)) {
            $fileExcludeFields = $ScriptExcludeFields[$fileID].Split(',') | ForEach-Object { $_.Trim() }
        }

        $index = 1
        $outputData = New-Object 'System.Collections.Generic.List[object]'
    }

    process {
        foreach ($item in $InputObject) {
            
            # Create a duplicate of the item with only the required fields
            $processedItem = New-Object PSObject 
            foreach ($prop in $item.PSObject.Properties) {
                if ($null -eq $fileExcludeFields -or !$fileExcludeFields.Contains($prop.Name)) {
                    $processedItem | Add-Member -MemberType NoteProperty -Name $prop.Name -Value $prop.Value -Force
                }
            }

            # Add index if requested
            if ($IncludeIndex) {
                $processedItem | Add-Member -MemberType NoteProperty -Name 'Index' -Value $index -Force
                $index++
            }

            # Add the processed item to the list
            $outputData.Add($processedItem)
        }
    }

    end {
        # Convert the list to an array and export to CSV
        $outputData.ToArray() | Export-Csv -Path $Path -Encoding UTF8 -NoTypeInformation -Append:$Append -Delimiter ","

        # This function logs the field names and sample values of exported data to the log file and a CSV file
        # Uncomment the following line to enable this functionality
        #LogFieldInfo -InputObject $outputData -OutputFileName $fileID
        $outputData = $null
    }
}

function LoadExcludeFields {
    $script:ScriptExcludeFields = @{}

    if (!($ScriptDescription)) {
        return
    }

    # Import the CSV
    try {
        $csvData = Import-Csv -Path ".\ExcludeFields.csv" -ErrorAction SilentlyContinue
    } catch {
    }

    foreach ($row in $csvData | Where-Object { $_.Script -eq $ScriptDescription }) {
        $ScriptExcludeFields[$row.OutputFile] = $row.ExcludeFields
    }
}

function GetFileNameFinalPart {
    param (
        [string]$FilePath
    )

    # Return the last part of the filename i.e. Apps for the following values
    # c:\temp\20240102_101212_Apps.csv
    # c:\temp\Apps.csv

    # Get the filename without the extension
    $fileNameWithoutExtension = [System.IO.Path]::GetFileNameWithoutExtension($FilePath)

    # Split the filename by underscore or backslash, and take the last part
    $lastPart = ($fileNameWithoutExtension -split '[\\_]')[-1]

    return $lastPart
}

# Support function. Not currently called. The function is used for custom testing to aid the local development team where necessary
function LogFieldInfo {
    param(
        [PSCustomObject[]] $InputObject,
        [string] $OutputFileName
    )
    
    # This function logs the field names and sample values of exported data to the log file and a CSV file
    # It is not enabled by default
    if (!($InputObject) -or $InputObject.Count -eq 0) {
        return
    }

    # Creating a new array of fields and sample values
    $lstFields = @()

    $recordIndex = 1
    foreach ($record in $InputObject) {
        $fieldNames = $record.PSObject.Properties.Name
        $fieldIndex = 1

        # Iterate through each property
        foreach ($fieldName in $fieldNames) {
            # Creating a new object for each property
            $field = [PSCustomObject][ordered]@{
                ScriptFileName = $ScriptName
                ScriptDescription = $ScriptDescription
                OutputFileName = $OutputFileName
                FieldName = $fieldName
                SampleValue = $record.$fieldName
                FieldIndex = $fieldIndex++
                RecordIndex = $recordIndex
            }

            # Add new object to the array
            $lstFields += $field
        }
    
        $recordIndex++
        if ($recordIndex -gt 3) {
            break
        }
    }

    # Save the field info to log file and csv file
    $csvLines = $lstFields | ConvertTo-Csv -NoTypeInformation
    $csvString = $csvLines -join "`n"
    LogText $csvString -LogTo File
    $lstFields | export-csv -Path ".\FieldInfo.csv" -NoTypeInformation -Append -Delimiter ","
}
#endregion

#region HyperV
function GetHyperVVMs {
    function New-VMRecord {
        return [PSCustomObject][ordered]@{
            FQDN = ""
            Name = ""
            GUID = ""
            Host = ""
            OSName = ""
            OSEditionId = ""
            OSVersion = ""
            CSDVersion = ""
            Description = ""
            State = ""
            StateID = ""
            State2 = ""
            CreationTime = ""
            InstallDate = ""
            OnTimeInMilliseconds = ""
            TimeOfLastStateChange = ""
            ReplicationState = ""
            IsClustered = ""
            ProductType = ""
            ProcessorArchitecture = ""
            ProcessorCount = ""
            ProcessorCount2 = ""
            HwThreadCountPerCore = ""
            MACAddresses = ""
            NetworkAddressesIPv4 = ""
            NetworkAddressesIPv6 = ""
            MemoryAssigned = ""
            SuiteMask = ""
            IntegrationServicesVersion = ""
            Note = ""
        }
    }

    # Status
    # StatusDescriptions
    
    $dictVMs = @{}

    # Initialize hashtable with mandatory parameters
    $params = @{
        Namespace   = 'root\virtualization'
        ClassName   = 'Msvm_ComputerSystem'
        ErrorAction = 'SilentlyContinue'
    }

    # Conditionally add the CimSession if it exists in $ConnectionDetails
    if ($ConnectionDetails.CimSession) {
        $params['CimSession'] = $ConnectionDetails.CimSession
    }

    $hyperVClass = Get-CimClass @params
    if ($null -eq $hyperVClass) {
        $params['Namespace'] = "root\virtualization\v2"
        $hyperVClass = Get-CimClass @params
    }

    if ($null -eq $hyperVClass) {
        Write-Host "Unable to locate Hyper-V WMI namespace" -ForegroundColor Red
    } else {
        $VMs = Get-CimInstance @params | Where-Object {($_.Caption -split " ").Length -eq 2} 
        # Example Captions - "Virtual Machine, "Máquina virtual", "Виртуальная машина"

        $params.Remove('ClassName')
        $params['ResultClassName'] = 'Msvm_KvpExchangeComponent'
        
        foreach ($vm in $VMs) {
            $vmRecord = New-VMRecord
            $vmRecord.Name = $vm.ElementName
            $vmRecord.GUID = $vm.Name
            $vmRecord.Host = $env:COMPUTERNAME
            $vmRecord.Description = $vm.Description
            $vmRecord.StateID = $vm.EnabledState
            $vmRecord.InstallDate = $vm.InstallDate
            $vmRecord.OnTimeInMilliseconds = $vm.OnTimeInMilliseconds
            $vmRecord.TimeOfLastStateChange = $vm.TimeOfLastStateChange

            switch ($vm.EnabledState) 
            {
                0        {$vmRecord.State = "Unknown"} # -> State
                2        {$vmRecord.State = "Enabled"}
                3        {$vmRecord.State = "Disabled"}
                4        {$vmRecord.State = "Shut Down"}
                6        {$vmRecord.State = "Offline"}
                32768    {$vmRecord.State = "Paused"}
                32769    {$vmRecord.State = "Suspended"}
                32770    {$vmRecord.State = "Starting"}
                32771    {$vmRecord.State = "Snapshotting"}
                32773    {$vmRecord.State = "Saving"}
                32774    {$vmRecord.State = "Stopping"}
                32776    {$vmRecord.State = "Pausing"}
                32777    {$vmRecord.State = "Resuming"}
                default  {$vmRecord.State = "Unknown"}
            }

            # Get the KVP Object
            try {
                $params['InputObject'] = $vm
                $Kvp = Get-CimAssociatedInstance @params
            }
            catch {
                Write-Host "Error retrieving info for VM $($vm.Name)" -ForegroundColor Red
                $Kvp = $null
            }

            # Convert XML to Object
            foreach($StrDataItem in $Kvp.GuestIntrinsicExchangeItems)
            {
                $XmlDataItem = [xml]($StrDataItem)
                $AttributeName = $XmlDataItem.Instance.Property | Where-Object {$_.Name -eq "Name"}
                $AttributeValue = $XmlDataItem.Instance.Property | Where-Object{$_.Name -eq "Data"}
            
                switch -exact ($AttributeName.Value)
                {
                    "FullyQualifiedDomainName"    {$vmRecord.FQDN = $AttributeValue.Value; break;} 
                    "OSName"                      {$vmRecord.OSName = $AttributeValue.Value; break;}
                    "OSVersion"                   {$vmRecord.OSVersion = $AttributeValue.Value; break;}
                    "CSDVersion"                  {$vmRecord.CSDVersion = $AttributeValue.Value; break;}
                    "ProductType"                 {$vmRecord.ProductType = $AttributeValue.Value; break;}
                    "NetworkAddressIPv4"          {$vmRecord.NetworkAddressesIPv4 = $AttributeValue.Value; break;}
                    "NetworkAddressIPv6"          {$vmRecord.NetworkAddressesIPv6 = $AttributeValue.Value; break;}
                    "OSEditionId"                 {$vmRecord.OSEditionId = $AttributeValue.Value; break;}
                    "ProcessorArchitecture"       {$vmRecord.ProcessorArchitecture = $AttributeValue.Value; break;}
                    "SuiteMask"                   {$vmRecord.SuiteMask = $AttributeValue.Value; break;}        
                }
            }

            $dictVMs[$vmRecord.GUID] = $vmRecord
        }
    }
    
    if (Get-Module -Name "Hyper-V" -ListAvailable) {
        if (!(Get-Module -Name "Hyper-V")) {
            Import-Module -Name "Hyper-V"
        }

        foreach ($vm in Get-VM) {

            if ($dictVMs.ContainsKey(($vm.VMId).Guid)) {
                $vmRecord = $dictVMs[($vm.VMId).Guid]
            } else {
                $vmRecord = New-VMRecord
                $vmRecord.GUID = ($vm.VMId).Guid
                $dictVMs[$vmRecord.GUID] = $vmRecord
            }

            $networkAddressesIPv4 = ($vm.NetworkAdapters | ForEach-Object {
                $_.IPAddresses | Where-Object { $_ -match '^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$'}}) -join ', '

            $networkAddressesIPv6 = ($vm.NetworkAdapters | ForEach-Object {
                $_.IPAddresses | Where-Object { $_ -match '^([0-9a-fA-F]{0,4}:){1,7}[0-9a-fA-F]{0,4}$'}}) -join ', '

            # Note
            $vmRecord.Name = $vm.Name
            $vmRecord.State2 = $vm.State
            $vmRecord.ReplicationState = $vm.ReplicationState
            $vmRecord.MemoryAssigned = $vm.MemoryAssigned
            $vmRecord.IntegrationServicesVersion = $vm.IntegrationServicesVersion
            $vmRecord.Host = $vm.ComputerName
            $vmRecord.CreationTime = $vm.CreationTime
            $vmRecord.IsClustered = $vm.IsClustered
            $vmRecord.ProcessorCount = $vm.ProcessorCount
            if ($networkAddressesIPv4) {
                $vmRecord.NetworkAddressesIPv4 = $networkAddressesIPv4
            }
            if ($networkAddressesIPv6) {
                $vmRecord.NetworkAddressesIPv6 = $networkAddressesIPv6
            }
            $vmRecord.MACAddresses = ($vm.NetworkAdapters | Select-Object -expand MacAddress) -join ', '
            $vmRecord.Note = $vm.Note

    
            $proc = $vm | Get-VMProcessor
            if ($proc) {
                $vmRecord.ProcessorCount2 = $proc.Count
                $vmRecord.HwThreadCountPerCore = $proc.HwThreadCountPerCore
            }
        }
    }

    return $dictVMs.Values | Sort-Object Name
}

function GetHyperVHosts {
    if (Get-Module -Name "Hyper-V" -ListAvailable) {
        if (!(Get-Module -Name "Hyper-V")) {
            Import-Module -Name "Hyper-V"
        }

        Get-VMHost -ComputerName $using:ComputerName | 
            Select-Object -Property Name, LogicalProcessorCount, MemoryCapacity, MacAddressMinimum, MacAddressMaximum, VirtualMachineMigrationEnabled, FullyQualifiedDomainName | Sort-Object Name
    }
}

function GetModule {
    return Get-Module -ListAvailable | Where-Object { $_.Name -eq 'Hyper-V' }
}

function GetHyperVVMsAndHosts () {
    param(
        [string] $VMFile,
        [string] $HostFile
    )
    
    if ($ConnectionDetails.PSSession) {
        $moduleAvailable = Invoke-Command -Session $ConnectionDetails.PSSession ${Function:GetModule}
        if (!($moduleAvailable)) {
            LogError "Hyper-V PowerShell module not available"
            return
        }

        LogText "Getting Hyper-V VM info (Using PSSession)"
        $vms = Invoke-Command -Session $ConnectionDetails.PSSession ${Function:GetHyperVVMs}

        LogText "Getting Hyper-V Host info (Using PSSession)"
        $hosts = Invoke-Command -Session $ConnectionDetails.PSSession ${Function:GetHyperVHosts}
        
    } else {
        LogText "Getting Hyper-V VM info"
        $vms = GetHyperVVMs
        
        LogText "Getting Hyper-V Host info"
        $hosts = GetHyperVHosts
    }

    if ($MicrosoftOnly) {
        $vms = $vms | Where-Object {
            [string]::IsNullOrWhiteSpace($_.OSName) -or $_.OSName -like "*Windows*"
        }
    }

    if ($TargetType -eq "Servers") {
        $vms = $vms | Where-Object { [string]::IsNullOrWhiteSpace($_.OSName) -or $_.OSName -like "*Server*" }
    } elseif ($TargetType -eq "Clients") {
        $vms = $vms | Where-Object { [string]::IsNullOrWhiteSpace($_.OSName) -or -not ($_.OSName -like "*Server*") }
    }

    $vms | Export-MyCsv -Path $VMFile -IncludeIndex
    $hosts | Export-MyCsv -Path $HostFile -IncludeIndex
}
#endregion

function Get-HyperVVMMigrationInfo {
    
    LogTimeAndText "Retrieving HyperV VM Events"

    $events = @()
    $logEvents = Get-WinEvent -ComputerName $ComputerName -LogName "microsoft-windows-hyper-v-worker-admin" |  Where-Object {$_.Id -eq 18500}
        
    foreach ($logEvent in $logEvents) { 
        $eventParameters = $logEvent.Properties
        if ($null -eq $eventParameters){
            LogText "Event Missing Parameters. ID: $($logEvent.Id) Time: $($logEvent.TimeCreated)"
            continue
        }

        $winEvent = new-object PSObject
        $winEvent | Add-Member -MemberType NoteProperty -Name "ID" -Value $logEvent.Id
        $winEvent | Add-Member -MemberType NoteProperty -Name "Time" -Value $logEvent.TimeCreated
        $winEvent | Add-Member -MemberType NoteProperty -Name "Description" -Value "VM started"
        $winEvent | Add-Member -MemberType NoteProperty -Name "UserID" -Value $logEvent.UserId
        $winEvent | Add-Member -MemberType NoteProperty -Name "MachineName" -Value $eventParameters[0].Value
        $winEvent | Add-Member -MemberType NoteProperty -Name "MachineGUID" -Value $eventParameters[1].Value

        $events += $winEvent
    }

    $events | Export-MyCsv -Path $OutputFile3 -IncludeIndex
}

function Get-HyperVDetails {
    try {
        InitialiseLogFile
        SetupOutputFormats
        LogEnvironmentDetails

        LogTimeAndText "Starting Hyper-V Scan ($ComputerName)"
        
        if (!(ConnectToComputer -ComputerName $ComputerName)) {
            return
        }

        GetHyperVVMsAndHosts -VMFile $OutputFile1 -HostFile $OutputFile2
        
        if ($RequiredData -eq "AllData") {
            LogTimeAndText "Getting HyperV Guest Migration Info (PowerShell)"
            Get-HyperVVMMigrationInfo
        }
    }
    catch {
        LogLastException
    }
}

Get-HyperVDetails
