 ##########################################################################
 #
 # Get-SCCMInventoryData
 #
 ##########################################################################

<#

.COPYRIGHT
Copyright (C) 2024 Ernst & Young Global Limited. All rights reserved. The Irish firm Ernst & Young is a member practice of Ernst & Young Global Limited.

This script is proprietary to Ernst & Young Global Limited (or one of its member firms). Unauthorized copying of this file, via any medium, is strictly prohibited. Redistribution and use in source and binary forms, with or without modification, are not permitted without prior written permission from Ernst & Young Global Limited.

.LICENSE
This script is provided "AS IS" without warranty of any kind. Ernst & Young Global Limited expressly disclaims all warranties, whether express, implied, statutory, or otherwise, with respect to this script including all implied warranties of merchantability, fitness for a particular purpose, and non-infringement. In no event shall Ernst & Young Global Limited be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this script, even if advised of the possibility of such damage.

#>

 Param(
    [alias("server")]
    [string] $DatabaseServer = $env:computerName,
    [alias("database")]
    $DatabaseName = "CM_P01",
    [string] $OutputFolder = ".\",
    [string] $OutputFilePrefix = "",
    [alias("o1")]
    $OutputFile1 = "SCCMDevices.csv",
    [alias("o2")]
    $OutputFile2 = "SCCMSoftware.csv",    
    [alias("o3")]
    $OutputFile3 = "SCCMServices.csv",
    [alias("o4")]
    $OutputFile4 = "SCCMIEFiles.csv",
    [alias("o5")]
    [string] $LogFile = "SCCMLogFile.txt",
    $UserName,
    $Password,
    $PortNumber = "0",
    $SQLCommandTimeout = 300,
    [ValidateSet("2007","2012")]
    $SCCMVersion = "2012",
    [ValidateSet("All","Servers","Clients")] 
    [string] $TargetType = "All",
    [switch] $MicrosoftOnly,
    [switch] $Verbose,
    [switch] $Headless)
    

$ScriptDescription =       "SCCM Export"
$ScriptVersion =           "5.0.10"

#region Logging
$script:OutFileSupportsNoNewLine = $false;
function InitialiseLogFile {

    if (!($script:OutputFolder)) {
        $script:OutputFolder = ".\"
    }

    if (!(Test-Path $script:OutputFolder)) {
        New-Item -ItemType Directory -Path $script:OutputFolder | Out-Null
    }

    $script:OutputFolder = Resolve-Path $script:OutputFolder | Select-Object -ExpandProperty Path

    if (!($script:OutputFolder.EndsWith('\'))) {
        $script:OutputFolder += '\'
    }

    if ($script:OutputFolder -and !($LogFile -like "*\*")) {
        $script:LogFile = Join-Path $script:OutputFolder "$($OutputFilePrefix)$LogFile"
    }

    if ($LogFile -and (Test-Path $LogFile)) {
        Remove-Item $LogFile
    }

    if ((Get-Command "Out-File").parameters["NoNewline"]) {
        $script:OutFileSupportsNoNewLine = $true;
    }

    PrefixOutputFilesWithFolder
    DecryptPassword
}

function PrefixOutputFilesWithFolder {
    
    # Check if $OutputFolder exists and is not empty
    if ($script:OutputFolder) {
        $counter = 1
        while ($true) {
            $outputFileVarName = "OutputFile$counter"
            # Check if the OutputFile variable exists
            if (Get-Variable -Name $outputFileVarName -Scope Script -ErrorAction SilentlyContinue) {
                # Get the value of the OutputFile variable
                $outputFileValue = Get-Variable -Name $outputFileVarName -ValueOnly -Scope Script
                # Check if it does not contain a backslash, and if so, prefix with OutputFolder
                if (-not $outputFileValue.Contains("\"))
                {
                    Set-Variable -Name $outputFileVarName -Value (Join-Path $script:OutputFolder "$($OutputFilePrefix)$outputFileValue") -Scope Script
                }
                $counter++
            } else {
                # Exit loop if the variable does not exist
                break
            }
        }
    }
} 

function LogText {
    param(
        [Parameter(Position=0, ValueFromRemainingArguments=$true, ValueFromPipeline=$true)]
        [Object] $Object,
        [System.ConsoleColor]$Color = [System.Console]::ForegroundColor,
        [switch]$NoNewLine = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"
    )

    if ($LogTo -ne "File") {
        # Display text on screen
        Write-Host -Object $Object -ForegroundColor $Color -NoNewline:$NoNewLine
    }
    
    if ($LogTo -ne "Console") {
        if ($LogFile) {
            if ($script:OutFileSupportsNoNewLine) {
                $Object | Out-File $LogFile -Encoding utf8 -Append -NoNewline:$NoNewLine 
            }
            else {
                $Object | Out-File $LogFile -Encoding utf8 -Append 
            }
        }
    }
}

function LogTimeAndText {
    param(
        [string] $Text,
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Blue,
        [switch]$IncludeDate = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    $output = "";
    if ($IncludeDate) {
        $output = Get-Date -Format "yyyy-MM-dd HH:mm:ss.ff"
    } else {
        $output = Get-Date -Format "HH:mm:ss.ff"
    }

    $output += " - "
    $output += $Text
    LogText $output -Color $Color -LogTo $LogTo
}

function LogError([string[]]$errorDescription){
    if ($Verbose){
        LogText ""
    }

    $output = $errorDescription -join "`r`n              "
    LogTimeAndText $output -Color Red

    Start-Sleep -s 3
}

function LogLastException() {
    $currentException = $Error[0].Exception;

    while ($currentException)
    {
        LogText -Color Red $currentException
        LogText -Color Red $currentException.Data
        LogText -Color Red $currentException.HelpLink
        LogText -Color Red $currentException.HResult
        LogText -Color Red $currentException.Message
        LogText -Color Red $currentException.Source
        LogText -Color Red $currentException.StackTrace
        LogText -Color Red $currentException.TargetSite

        $currentException = $currentException.InnerException
    }

    Start-Sleep -s 3
}

$script:MostRecentActivity = ""
function LogProgress([string]$Activity, [string]$Status, [Int32]$PercentComplete, [switch]$Completed ){
    
    if ($Activity) {
        $script:MostRecentActivity = $Activity
    } else {
        if ($script:MostRecentActivity) {
            $Activity = $script:MostRecentActivity
        } else {
            $Activity = "Unspecified"
        }
    }
    Write-Progress -activity $Activity -Status $Status -percentComplete $PercentComplete -Completed:$Completed
    LogTimeAndText $Status
}

function GetScriptPath
{
    if($PSCommandPath){
        return $PSCommandPath; }
        
    if($MyInvocation.ScriptName){
        return $MyInvocation.ScriptName }
        
    if($script:MyInvocation.MyCommand.Path){
        return $script:MyInvocation.MyCommand.Path }

    return $script:MyInvocation.MyCommand.Definition
}

function GetDotNetFrameworkVersion {
    #$release = Get-ItemPropertyValue -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release
    $regKey = Get-Item -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    $release = $regKey.GetValue("Release")
    switch ($release) {
        { $_ -ge 533320 } { $version = "4.8.1 or later ($release)"; break }
        { $_ -ge 528040 } { $version = "4.8 ($release)"; break }
        { $_ -ge 461808 } { $version = "4.7.2 ($release)"; break }
        { $_ -ge 461308 } { $version = "4.7.1 ($release)"; break }
        { $_ -ge 460798 } { $version = "4.7 ($release)"; break }
        { $_ -ge 394802 } { $version = "4.6.2 ($release)"; break }
        { $_ -ge 394254 } { $version = "4.6.1 ($release)"; break }
        { $_ -ge 393295 } { $version = "4.6 ($release)"; break }
        { $_ -ge 379893 } { $version = "4.5.2 ($release)"; break }
        { $_ -ge 378675 } { $version = "4.5.1 ($release)"; break }
        { $_ -ge 378389 } { $version = "4.5 ($release)"; break }
        default { $version = $null; break }
    }

    return $version
}

function LogEnvironmentDetails ([string[]] $OtherDetails){

    $script:ScriptPath = GetScriptPath
    $script:ScriptName = split-path $ScriptPath -leaf

    LogText " "
    LogHeaderText -FrameLine 
    LogHeaderText -LeftText " _______     __" -LeftColor Yellow
    LogHeaderText -LeftText "|  ___\ \   / /" -LeftColor Yellow
    LogHeaderText -LeftText "| |__  \ \_/ / " -LeftColor Yellow
    LogHeaderText -LeftText "|  __|  \   /  " -LeftColor Yellow
    LogHeaderText -LeftText "| |____  | |   " -LeftColor Yellow -RightText "$ScriptDescription  "
    LogHeaderText -LeftText "|______| |_|   " -LeftColor Yellow -RightText "Version $ScriptVersion  "
    LogHeaderText
    LogHeaderText -FrameLine 

    LogText " "
    LogText " $ScriptName" -Color Green 
    LogText " "

    if ($PSVersionTable.PSVersion.Major -ge 3) {
        $oSDetails = Get-CimInstance -ClassName Win32_OperatingSystem
    } else {
        $oSDetails = Get-WmiObject -Class Win32_OperatingSystem
    }
    $elevated = [bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")
    $currentThread = [System.Threading.Thread]::CurrentThread
    $dotNetFrameworkVersion = GetDotNetFrameworkVersion
    LogText -Color Gray "Computer Name:          $($env:COMPUTERNAME)"
    LogText -Color Gray "User Name:              $($env:USERNAME)@$($env:USERDNSDOMAIN)"
    LogText -Color Gray "Windows Version:        $($oSDetails.Caption)($($oSDetails.Version))"
    LogText -Color Gray "Memory kB:              $($oSDetails.TotalVisibleMemorySize.ToString("N0")) ($($oSDetails.FreePhysicalMemory.ToString("N0")) Free)"
    LogText -Color Gray "Locale:                 $($oSDetails.Locale) (Language $($oSDetails.OSLanguage))"
    LogText -Color Gray "PowerShell Host:        $($host.Version.Major)"
    LogText -Color Gray "PowerShell Version:     $($PSVersionTable.PSVersion)"
    LogText -Color Gray "PowerShell Word Size:   $($([IntPtr]::size) * 8) bit"
    LogText -Color Gray "Script Path:            $ScriptPath"
    LogText -Color Gray "Working Directory:      $PWD"
    LogText -Color Gray "CLR Version:            $($PSVersionTable.CLRVersion)"
    LogText -Color Gray ".Net Framework Version: $dotNetFrameworkVersion"
    LogText -Color Gray "Elevated:               $elevated"
    LogText -Color Gray "Current Date Time:      $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
    LogText -Color Gray "Default Date Format:    $($CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern)"
    LogText -Color Gray "Current Culture:        $((Get-Culture).EnglishName) (UI: $((Get-UICulture).EnglishName))"
    
    if (Test-Path "Variable:OutputFolder") {
        LogText -Color Gray "Output Folder:          $OutputFolder" 
    }
    if (Test-Path "Variable:OutputFile1") {
        LogText -Color Gray "Output File 1:          $OutputFile1" 
    }
    if (Test-Path "Variable:LogFile") {
        LogText -Color Gray "Log File:               $LogFile" 
    }
    if (Test-Path "Variable:ComputerName") {
        LogText -Color Gray "Target Computer Name:   $ComputerName" 
    }
    if (Test-Path "Variable:UserName") {
        LogText -Color Gray "Script User Name:       $UserName"
    }
    if (Test-Path "Variable:MicrosoftOnly") {
        LogText -Color Gray "Microsoft Only:         $MicrosoftOnly"
    }
    if (Test-Path "Variable:TargetType") {
        LogText -Color Gray "Target Type:            $TargetType"
    }
    if (Test-Path "Variable:ScriptRegime") {
        LogText -Color Gray "Script Regime:          $ScriptRegime"
    }
    if (Test-Path "Variable:RequiredData") {
        LogText -Color Gray "Required Data:          $RequiredData"
    }

    foreach ($detail in $OtherDetails){
        LogText -Color Gray $detail
    }

    LogText -Color Gray ""

}

function LogHeaderText {
    param(
        [string] $LeftText = " ",
        [System.ConsoleColor]$LeftColor = [System.ConsoleColor]::Blue,
        [string] $RightText,
        [System.ConsoleColor]$RightColor = [System.ConsoleColor]::DarkGray,
        [char] $FrameChar = "#",
        [switch] $FrameLine,
        [switch] $LeftAlignRightText,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    if ($FrameLine) {
        $strFullText = "  " + ($FrameChar.ToString() * 69)
        LogText $strFullText -Color DarkGray -LogTo $LogTo
        return
    }

    $strLeftFrame = "  $FrameChar  "
    $strLeftText = $LeftText
    $strRightText = $RightText
    $strRightFrame = "  $FrameChar"
    if ($LeftAlignRightText) {
        $strRightText = $RightText.PadRight(63 - $LeftText.Length)
    } else {
        $strLeftText = $LeftText.PadRight(63 - $RightText.Length)
    }
    

    if ($LogTo -eq "Console" -or $LogTo -eq "Both") {
        LogText $strLeftFrame -LogTo "Console" -NoNewLine -Color DarkGray
        LogText $strLeftText -LogTo "Console" -NoNewLine -Color $LeftColor
        LogText $strRightText -LogTo "Console" -NoNewLine -Color $RightColor
        LogText $strRightFrame -LogTo "Console" -Color DarkGray
    }

    if ($LogTo -eq "File" -or $LogTo -eq "Both") {
        $strFullText = $strLeftFrame + $strLeftText + $strRightText + $strRightFrame
        LogText $strFullText -LogTo "File" 
    }
}

function DecryptPassword {
    $strOneTimePassword = "%OneTimePassword%" # Replace this with the one-time password
    if ($SecurePassword) {
        $baOneTimePassword = [System.Convert]::FromBase64String($strOneTimePassword)
        $baSecurePassword = [System.Convert]::FromBase64String($SecurePassword)
        for($i=0; $i -lt $baSecurePassword.count ; $i++)
        {
            $baSecurePassword[$i] = $baSecurePassword[$i] -bxor $baOneTimePassword[$i%$baOneTimePassword.Length]
        }
        $script:Password = [System.Text.Encoding]::Unicode.GetString($baSecurePassword);
    }
}
#endregion

#region Setup Output Formats
function SetupOutputFormats {
    # Standardise date/time output to ISO 8601'ish format
    $bOutputFormatsUpdated = $false
    $currentThread = [System.Threading.Thread]::CurrentThread
    $desiredShortPattern = 'yyyy-MM-dd'
    $desiredLongPattern = 'yyyy-MM-dd HH:mm:ss'

    try {
        $cultureInvariant = [CultureInfo]::InvariantCulture.Clone()
        $cultureInvariant.DateTimeFormat.ShortDatePattern = $desiredShortPattern
        $cultureInvariant.DateTimeFormat.LongDatePattern = $desiredLongPattern
        $cultureInvariant.NumberFormat.NumberGroupSeparator = ""  
        $cultureInvariant.NumberFormat.NumberDecimalSeparator = "."
        $currentThread.CurrentCulture = $cultureInvariant
        $bOutputFormatsUpdated = $true
    }
    catch {
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $currentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $currentThread.CurrentCulture.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $currentThread.CurrentCulture.NumberFormat.NumberGroupSeparator = ""  
            $currentThread.CurrentCulture.NumberDecimalSeparator = "."
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $cultureCopy = $currentThread.CurrentCulture.Clone()
            $cultureCopy.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $cultureCopy.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $cultureCopy.NumberFormat.NumberGroupSeparator = ""  
            $cultureCopy.NumberDecimalSeparator = "."
            $currentThread.CurrentCulture = $cultureCopy
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread using clone of current culture"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        LogText "Failed to update output formats"
    }
}
#endregion

#region Query User
function QueryUser([string]$Message, [string]$Prompt, [switch]$AsSecureString = $false, [string]$DefaultValue){
    $strResult = ""
    
    if ($Message) {
        LogText $Message -color Yellow
    }

    if ($DefaultValue) {
        $Prompt += " (Default [$DefaultValue])"
    }

    $Prompt += ": "
    LogText $Prompt -color Yellow -NoNewLine
    
    if ($Headless) {
        LogText " (Headless - Using Default Value)" -color Yellow
    }
    else {
        $strResult = Read-Host -AsSecureString:$AsSecureString
    }

    if(!$strResult -or ($strResult.Length -eq 0)) {
        $strResult = $DefaultValue
        if ($AsSecureString) {
            $strResult = ConvertTo-SecureString $strResult -AsPlainText -Force
        }
    }

    return $strResult
}

function Get-ConsoleCredential([String] $Message, [String] $DefaultUsername, [switch] $AsPSCredential)
{
    $strUsername = QueryUser -Message $Message -Prompt "Username" -DefaultValue $DefaultUsername
    if (!$strUsername){
        return $null
    }

    $strSecurePassword = QueryUser -Prompt "Password" -AsSecureString
    if (!$strSecurePassword){
        return $null
    }

    if ($AsPSCredential) {
        $Creds = New-Object System.Management.Automation.PSCredential ($strUsername, $strSecurePassword)
    } else {
        $Creds = New-Object PSObject

        $bstrSecurePassword = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($strSecurePassword)
        $strUnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstrSecurePassword)

        $Creds | Add-Member -MemberType NoteProperty -Name "UserName" -Value $strUsername
        $Creds | Add-Member -MemberType NoteProperty -Name "Password" -Value $strUnsecurePassword
    }

    return $Creds
}
#endregion

function GetConnectionString {
    param(
        [switch] $HidePassword
    )

    $connectionString = ""
    if ($PortNumber -ne "0") {
        $connectionString = "Data Source=$DatabaseServer,$PortNumber;Network Library=DBMSSOCN;Initial Catalog=$DatabaseName; "
    }
    else {
        $connectionString = "Server=$DatabaseServer; Database=$DatabaseName; "
    }
    
    if ($UserName){
        if ($HidePassword) {
            $connectionString += "User Id=$UserName; Password=********;"
        }
        else {
            $connectionString += "User Id=$UserName; Password=$Password;"
        }
    }
    else {
        $connectionString += "Trusted_Connection=True;"
    }
    
    return $connectionString
}

function Invoke-SQL {
    param(
        [string] $sqlCommand = $(throw "Please specify a query."),
        [string] $resultsFilePath = $(throw "Please specify a file to save results in.")
      )
    
    try {
        if (Test-Path -path $resultsFilePath) {
            Remove-Item $resultsFilePath 
        }
    
        $fileWriter = New-Object System.IO.StreamWriter $resultsFilePath
    
        $connection = new-object system.data.SqlClient.SQLConnection(GetConnectionString)
        $command = new-object system.data.sqlclient.sqlcommand($sqlCommand,$connection)
        $command.CommandTimeout = $SQLCommandTimeout
        $connection.Open()
        
        $reader = $command.ExecuteReader()
        
        # Write the header to file
        for ($columnCounter = 0; $columnCounter -lt $reader.FieldCount; $columnCounter++) {
            $fileWriter.Write($reader.GetName($columnCounter))
            
            if ($columnCounter -lt $reader.FieldCount - 1) {
                $fileWriter.Write(",")
            }
        }
        $fileWriter.Write("`r`n")
        
        # Write the data to file
        while ($reader.Read())
        {
            for ($columnCounter = 0; $columnCounter -lt $reader.FieldCount; $columnCounter++) {
                $cellValue = $reader.GetValue($columnCounter)
                if ($cellValue -is [string]) {
                    $fileWriter.Write("`"" + $reader.GetValue($columnCounter).Replace("`"", "`"`"") + "`"")
                }
                else {
                    $fileWriter.Write($reader.GetValue($columnCounter).ToString())
                }
                
                if ($columnCounter -lt $reader.FieldCount - 1) {
                    $fileWriter.Write(",")
                }
            }
            $fileWriter.Write("`r`n")
        }
        
        $reader.Close()
        $connection.Close()
        $fileWriter.Close()
    
        $nFileSize = (Get-Item $resultsFilePath).length/1MB
        LogText "SQL Results File: $resultsFilePath Size (MB): $nFileSize"
    } catch {
        LogLastException
    }
}

function Get-SCCMInventoryData {
    try {
        InitialiseLogFile
        SetupOutputFormats
        LogEnvironmentDetails -OtherDetails @(
            "Server Parameter:       $DatabaseServer",
            "Database Parameter:     $DatabaseName");

        LogText "SCCM database connection details required." -Color Green
        LogText " "
        
        LogText "Sample SCCM Server\SQL Server Instance Names: localhost, localhost\SCCM, SrvSCCM01\SCCM, SrvSCCM01\SQL2014" -Color Gray
        $script:DatabaseServer = QueryUser -Prompt "SCCM Server and SQL Server Instance Name" -DefaultValue $DatabaseServer
        LogText "Sample Database Names: CM_P01, CM_CON, UK_SCCM" -Color Gray
        $script:DatabaseName = QueryUser -Prompt "Database Name" -DefaultValue $DatabaseName
        if (!($DatabaseServer) -or !($DatabaseName)) {
            LogError "Database connection details not provided"
            return
        }

        if (!($UserName) -and !($Password)) {
            LogText "Leave username blank to use integrated authentication" -Color Gray
            $creds = Get-ConsoleCredential -DefaultUsername $UserName
            if ($creds) {
                $script:UserName = $creds.UserName
                $script:Password = $creds.Password
            }
        }

        # Log the connection string
        $connectionStringForLogging = GetConnectionString -HidePassword
        LogText "Connection String: $connectionStringForLogging"

        if (!($MicrosoftOnly)) {
            $sqlCommandServices = $sqlCommandServices.replace('--//All Vendors//--','')
            $sqlCommandSoftware = $sqlCommandSoftware.replace('--//All Vendors//--','')
        }

        if ($TargetType -eq "Servers") {
            $sqlCommandDevices2012 = $sqlCommandDevices2012.replace('--//Servers Only//--','')
            $sqlCommandDevices2007 = $sqlCommandDevices2007.replace('--//Servers Only//--','')
            $sqlCommandServices = $sqlCommandServices.replace('--//Servers Only//--','')
            $sqlCommandSoftware = $sqlCommandSoftware.replace('--//Servers Only//--','')
        } elseif ($TargetType -eq "Clients") {
            $sqlCommandDevices2012 = $sqlCommandDevices2012.replace('--//Clients Only//--','')
            $sqlCommandDevices2007 = $sqlCommandDevices2007.replace('--//Clients Only//--','')
            $sqlCommandServices = $sqlCommandServices.replace('--//Clients Only//--','')
            $sqlCommandSoftware = $sqlCommandSoftware.replace('--//Clients Only//--','')
        }

        LogTimeAndText "Querying SCCM Device Data"
        if ($SCCMVersion -eq "2007") {
            Invoke-SQL -SQLCommand $sqlCommandDevices2007 -ResultsFilePath $OutputFile1 
        }
        else {
            Invoke-SQL -SQLCommand $sqlCommandDevices2012 -ResultsFilePath $OutputFile1
        }

        LogTimeAndText "Querying SCCM Software Data"
        Invoke-SQL -SQLCommand $sqlCommandSoftware -ResultsFilePath $OutputFile2

        LogTimeAndText "Querying SCCM Services Data"
        Invoke-SQL -SQLCommand $sqlCommandServices -ResultsFilePath $OutputFile3

        if (-not ($TargetType -eq "Servers")) {
            LogText "Querying IE Data"
            Invoke-SQL -SQLCommand $sqlIEFileData -ResultsFilePath $OutputFile4
        }
        
    }
    catch{
        LogLastException
    }
}

$sqlCommandDevices2007 = @"
SELECT
    [System].[ResourceID] AS [SourceKey]
    ,[System].[Client_Version0] AS [SystemClientVersion]
    ,[ComputerSystem].[Name0] AS [ComputerSystemName]
    ,[System].[Name0] AS [SystemName]
    ,[System].[NetBios_Name0] AS [SystemNetBiosName]
    ,[ComputerSystem].[Domain0] AS [Domain]
    ,[System].[Resource_Domain_OR_Workgr0] AS [Resource_Domain_OR_Workgr0]
    --/--,[System].[Distinguished_Name0] AS [Distinguished_Name0]
    --##,[Bios].[SerialNumber0] AS [BiosSerialNumber]  
    ,[Bios].[ReleaseDate0] AS [BiosReleaseDate]
    ,[NetworkAdapter].[MacAddress] AS [MacAddress]
    ,[NetworkAdapter1].[IPAddress] AS [IPAddress]
    --/--,CONVERT(varchar(19), [System].[Last_Logon_Timestamp0], 126) AS [LastLogon]
    ,CONVERT(varchar(19), [WorkstationStatus].[LastHWScan], 126) AS [LastHWScan]
    ,CONVERT(varchar(19), [SoftwareInventoryStatus].[LastScanDate], 126) AS [LastSWScan]
    ,[OperatingSystem].[Caption0] AS [OperatingSystem]
    --/--,[OperatingSystem].[SerialNumber0] AS [OperatingSystemSerialNumber]
    ,[OperatingSystem].[LastBootUpTime0] AS [LastBootUpTime]
    --##,[OperatingSystem].[CSDVersion0] AS [OperatingSystemServicePack]
    ,[OperatingSystem].[InstallDate0] AS [OperatingSystemInstallDate]
    ,[OperatingSystem].[Version0] AS [OperatingSystemVersion]
    --##,[OperatingSystem].[TotalVisibleMemorySize0] AS [PhysicalMemory]
    --##,[OperatingSystem].[TotalVirtualMemorySize0] AS [VirtualMemory] 
    ,[Processor].[ProcessorCount] AS [ProcessorCount]
    --/--,[Processor].[NumberOfCores] AS [CoreCount]
    --/--,[Processor].[CpuIsMulticore]
    --/--,[Processor].[CpuNormSpeed]
    ,[Processor].[CpuProcessorType]
    --/--,[Processor].[CpuDeviceID]
    ,[ComputerSystem].[NumberOfProcessors0] AS [LogicalProcessorCount]
    ,[Processor].[CpuType] AS [CpuType]
    ,[ComputerSystem].[Model0] AS [Model]
    ,[ComputerSystem].[Manufacturer0] AS [Manufacturer]
    --,[ComputerSystem].[SystemSkuNumber0] AS [SystemSkuNumber]    
    ,[ComputerSystem].[UserName0] AS [UserName]
    --/--,NULLIF([System].[Virtual_Machine_Host_Name0], '') AS [VirtualHostName]
    --/--,[VirtualMachine].[PhysicalHostName0] AS [VirtualPhysicalHostName]
    --/--,[VirtualMachine].[ResourceID] AS [VirtualResourceID]
    --,'vRSystem' AS [Source]
    --,[FullCollectionMembership].[CollectionID] --
FROM 
    [dbo].[v_R_System] AS [System] 
LEFT OUTER JOIN
    (
        SELECT
            [ResourceID]
            ,[Caption0]
            --/--,[SerialNumber0]
            ,[LastBootUpTime0]
            ,[CSDVersion0]
            ,[InstallDate0]
            ,[Version0]
            ,[TotalVisibleMemorySize0]
            ,[TotalVirtualMemorySize0]
            ,ROW_NUMBER() OVER (PARTITION BY [ResourceID] ORDER BY [GroupID] DESC) AS [OperatingSystemRow]
        FROM
            [dbo].[v_GS_Operating_System]
    ) AS [OperatingSystem]
ON
    [System].[ResourceID] = [OperatingSystem].[ResourceID]
AND
    [OperatingSystem].[OperatingSystemRow] = 1
--INNER JOIN 
LEFT OUTER JOIN
    (
        SELECT
            [ResourceID]
            ,[SerialNumber0]
            ,[ReleaseDate0]
            ,ROW_NUMBER() OVER (PARTITION BY [ResourceID] ORDER BY [GroupID] DESC) AS [BiosRow]
        FROM
            [dbo].[v_GS_PC_Bios]
    ) AS [Bios]
ON
    [System].[ResourceID] = [Bios].[ResourceID]
AND
    [Bios].[BiosRow] = 1
--INNER JOIN 
LEFT OUTER JOIN
    (
        SELECT
            [ResourceID]
            ,[Name0]
            ,[Domain0]
            ,[NumberOfProcessors0]
            ,[Model0]
            ,[Manufacturer0]
            --,[SystemSkuNumber0]
            ,[UserName0]
            ,ROW_NUMBER() OVER (PARTITION BY [ResourceID] ORDER BY [GroupID] DESC) AS [ComputerSystemRow]
        FROM
            [dbo].[v_GS_Computer_System]
    ) AS [ComputerSystem]
ON
    [System].[ResourceID] = [ComputerSystem].[ResourceID]
AND
    [ComputerSystem].[ComputerSystemRow] = 1
LEFT OUTER JOIN 
    (
        SELECT  
            [ResourceID]
            ,COUNT([ResourceID]) AS [ProcessorCount]
            --/--,SUM([NumberOfCores0]) AS [NumberOfCores]
            ,MAX([Name0]) AS [CpuType]
            ,MAX([IsMulticore0]) AS [CpuIsMulticore]
            ,MAX([NormSpeed0]) AS [CpuNormSpeed]
            ,MAX([ProcessorType0]) AS [CpuProcessorType]
            ,MAX([DeviceID0]) AS [CpuDeviceID]
        FROM
            [dbo].[v_GS_Processor]
        GROUP BY 
            [ResourceID]
    ) AS [Processor]
ON
    [System].[ResourceID] = [Processor].[ResourceID]
LEFT OUTER JOIN
    [dbo].[V_GS_Workstation_Status] AS [WorkstationStatus]
ON
    [WorkstationStatus].[ResourceID] = [System].[ResourceID]
LEFT OUTER JOIN
    [dbo].[V_GS_LastSoftwareScan] AS [SoftwareInventoryStatus]
ON
    [SoftwareInventoryStatus].[ResourceID] = [System].[ResourceID]
OUTER APPLY
    (
        SELECT DISTINCT
            [Network].[MACAddress0] + ';'
        FROM 
            [dbo].[v_GS_NETWORK_ADAPTER] AS [Network]
        WHERE 
            [Network].[ResourceID] = [System].[ResourceID]
        AND
            [Network].[MACAddress0] IS NOT NULL 
        AND
            [Network].[MACAddress0] NOT IN ('00:00:00:00:00:00','33:50:6F:45:30:30','50:50:54:50:30:30')
        ORDER BY 
            [Network].[MACAddress0] + ';'
        FOR XML PATH ('')
    ) AS [NetworkAdapter] (MacAddress)
OUTER APPLY
    (
        SELECT DISTINCT
            [NetworkConfig].[IPAddress0] + ';'
        FROM
            [dbo].v_GS_NETWORK_ADAPTER_CONFIGUR AS [NetworkConfig]
            --/--[dbo].[v_GS_NETWORK_ADAPTER_CONFIGURATION] AS [NetworkConfig]
        WHERE 
            [NetworkConfig].[ResourceID] = [System].[ResourceID]
        AND
            [NetworkConfig].[IPAddress0] IS NOT NULL 
        AND
            [NetworkConfig].[IPAddress0] NOT IN ('0.0.0.0')
        FOR XML PATH ('')
    ) AS [NetworkAdapter1] (IPAddress)
WHERE [OperatingSystem].[Caption0] LIKE '%windows%'
--//Servers Only//-- AND [OperatingSystem].[Caption0] LIKE '%server%'
--//Clients Only//-- AND [OperatingSystem].[Caption0] NOT LIKE '%server%'
"@

$sqlCommandDevices2012 = @"
SELECT
    [System].[ResourceID] AS [SourceKey],
    [System].[Client_Version0] AS [SystemClientVersion],
    [ComputerSystem].[Name0] AS [ComputerSystemName],
    [System].[Name0] AS [SystemName],
    [System].[NetBios_Name0] AS [SystemNetBiosName],
    [ComputerSystem].[Domain0] AS [Domain],
    [System].[Resource_Domain_OR_Workgr0] AS [Resource_Domain_OR_Workgr0],
    [System].[Distinguished_Name0] AS [Distinguished_Name0],
    [System].[AD_Site_Name0] AS [AD_Site_Name0],
    [System].[Is_Virtual_Machine0] AS [Is_Virtual_Machine0],
    [System].[User_Domain0] AS [User_Domain0],
    [System].[User_Name0] AS [User_Name0],
    --##[Bios].[SerialNumber0] AS [BiosSerialNumber],
    [Bios].[ReleaseDate0] AS [BiosReleaseDate],
    [NetworkAdapter].[MacAddress] AS [MacAddress],
    [NetworkAdapter1].[IPAddress] AS [IPAddress],
    CONVERT(varchar(19), [System].[Last_Logon_Timestamp0], 126) AS [LastLogon],
    CONVERT(varchar(19), [WorkstationStatus].[LastHWScan], 126) AS [LastHWScan],
    CONVERT(varchar(19), [SoftwareInventoryStatus].[LastScanDate], 126) AS [LastSWScan],
    [OperatingSystem].[Caption0] AS [OperatingSystem],
    [OperatingSystem].[SerialNumber0] AS [OperatingSystemSerialNumber],
    --##[OperatingSystem].[CSDVersion0] AS [OperatingSystemServicePack],
    [OperatingSystem].[InstallDate0] AS [OperatingSystemInstallDate],
    [OperatingSystem].[Version0] AS [OperatingSystemVersion],
    --##[OperatingSystem].[TotalVisibleMemorySize0] AS [PhysicalMemory],
    --##[OperatingSystem].[TotalVirtualMemorySize0] AS [VirtualMemory],
    [Processor].[ProcessorCount] AS [ProcessorCount],
    [Processor].[NumberOfCores] AS [CoreCount],
    [ComputerSystem].[NumberOfProcessors0] AS [LogicalProcessorCount],
    [Processor].[CpuType] AS [CpuType],
    [ComputerSystem].[Model0] AS [Model],
    [ComputerSystem].[Manufacturer0] AS [Manufacturer],
    --[ComputerSystem].[SystemSkuNumber0] AS [SystemSkuNumber],
    [ComputerSystem].[UserName0] AS [UserName],
    NULLIF([System].[Virtual_Machine_Host_Name0], '') AS [VirtualHostName],
    [VirtualMachine].[PhysicalHostName0] AS [VirtualPhysicalHostName],
    [VirtualMachine].[ResourceID] AS [VirtualResourceID]
    --'vRSystem' AS [Source],
    --[FullCollectionMembership].[CollectionID]
FROM 
    [dbo].[v_R_System] AS [System] 
LEFT OUTER JOIN
    (
        SELECT
            [ResourceID]
            ,[Caption0]
            ,[SerialNumber0]
            ,[CSDVersion0]
            ,[InstallDate0]
            ,[Version0]
            ,[TotalVisibleMemorySize0]
            ,[TotalVirtualMemorySize0]
            ,ROW_NUMBER() OVER (PARTITION BY [ResourceID] ORDER BY [GroupID] DESC) AS [OperatingSystemRow]
        FROM
            [dbo].[v_GS_Operating_System]
    ) AS [OperatingSystem]
    ON [System].[ResourceID] = [OperatingSystem].[ResourceID] AND [OperatingSystem].[OperatingSystemRow] = 1
LEFT OUTER JOIN
    (
        SELECT
            [ResourceID]
            ,[SerialNumber0]
            ,[ReleaseDate0]
            ,ROW_NUMBER() OVER (PARTITION BY [ResourceID] ORDER BY [GroupID] DESC) AS [BiosRow]
        FROM
            [dbo].[v_GS_PC_Bios]
    ) AS [Bios]
    ON [System].[ResourceID] = [Bios].[ResourceID] AND [Bios].[BiosRow] = 1
LEFT OUTER JOIN
    (
        SELECT
            [ResourceID]
            ,[Name0]
            ,[Domain0]
            ,[NumberOfProcessors0]
            ,[Model0]
            ,[Manufacturer0]
            --,[SystemSkuNumber0]
            ,[UserName0]
            ,ROW_NUMBER() OVER (PARTITION BY [ResourceID] ORDER BY [GroupID] DESC) AS [ComputerSystemRow]
        FROM
            [dbo].[v_GS_Computer_System]
    ) AS [ComputerSystem]
    ON [System].[ResourceID] = [ComputerSystem].[ResourceID] AND [ComputerSystem].[ComputerSystemRow] = 1
LEFT OUTER JOIN 
    (
        SELECT  
            [ResourceID]
            ,COUNT([ResourceID]) AS [ProcessorCount]
            ,SUM([NumberOfCores0]) AS [NumberOfCores]
            ,MAX([Name0]) AS [CpuType]
        FROM
            [dbo].[v_GS_Processor]
        GROUP BY 
            [ResourceID]
    ) AS [Processor]
    ON [System].[ResourceID] = [Processor].[ResourceID]
LEFT OUTER JOIN
    [dbo].[V_GS_Workstation_Status] AS [WorkstationStatus]
    ON [WorkstationStatus].[ResourceID] = [System].[ResourceID]
LEFT OUTER JOIN
    [dbo].[V_GS_LastSoftwareScan] AS [SoftwareInventoryStatus]
    ON [SoftwareInventoryStatus].[ResourceID] = [System].[ResourceID]
LEFT OUTER JOIN
    [dbo].[v_GS_Virtual_Machine] AS [VirtualMachine]
    ON [VirtualMachine].[ResourceID] = [System].[ResourceID]
OUTER APPLY
    (
        SELECT DISTINCT
            [Network].[MACAddress0] + ';'
        FROM 
            [dbo].[v_GS_NETWORK_ADAPTER] AS [Network]
        WHERE 
            [Network].[ResourceID] = [System].[ResourceID]
        AND
            [Network].[MACAddress0] IS NOT NULL 
        AND
            [Network].[MACAddress0] NOT IN ('00:00:00:00:00:00','33:50:6F:45:30:30','50:50:54:50:30:30')
        ORDER BY 
            [Network].[MACAddress0] + ';'
        FOR XML PATH ('')
    ) AS [NetworkAdapter] (MacAddress)
OUTER APPLY
    (
        SELECT DISTINCT
            [NetworkConfig].[IPAddress0] + ';'
        FROM 
            [dbo].[v_GS_NETWORK_ADAPTER_CONFIGURATION] AS [NetworkConfig]
        WHERE 
            [NetworkConfig].[ResourceID] = [System].[ResourceID]
        AND
            [NetworkConfig].[IPAddress0] IS NOT NULL 
        AND
            [NetworkConfig].[IPAddress0] NOT IN ('0.0.0.0')
        FOR XML PATH ('')
    ) AS [NetworkAdapter1] (IPAddress)
WHERE [OperatingSystem].[Caption0] LIKE '%windows%'
--//Servers Only//-- AND [OperatingSystem].[Caption0] LIKE '%server%'
--//Clients Only//-- AND [OperatingSystem].[Caption0] NOT LIKE '%server%'
"@

# This script used to use v_GS_INSTALLED_SOFTWARE
# v_GS_INSTALLED_SOFTWARE requires Asset Intelligence and software scanning to be enabled
# This table included install location

# Now using v_ADD_REMOVE_PROGRAMS which is populated during HW scan
# It is the combination of ARP 32 bit and ARP 64 bit
# i.e. Union of v_GS_ADD_REMOVE_PROGRAMS and v_GS_ADD_REMOVE_PROGRAMS_64 

# Other notes: 
# v_HS_ADD_REMOVE_PROGRAMS & v_HS_ADD_REMOVE_PROGRAMS_64 contain historical data
# v_GS_SoftwareProduct is populated by software inventory and is based on information obtained from the file headers

$sqlCommandSoftware = @"
SELECT [SoftwareCollection].[devicesourcekey] AS [DeviceSourceKey],
       CONVERT(VARCHAR(19), Getdate(), 126)   AS [DiscoveryDate],
       --##[SoftwareCollection].[InstalledLocation] AS [InstalledLocation],
       [SoftwareCollection].[productname]     AS [SwName],
       [SoftwareCollection].[productversion]  AS [SwVersion],
       [SoftwareCollection].[publisher]       AS [SwPublisher],
       [SoftwareCollection].[InstallDate]     AS [SwInstallDate],
       [SoftwareCollection].[softwarecode]    AS [SwSoftwareCode],
       [SoftwareCollection].[packagecode]     AS [SwSoftwareId],
       [SoftwareCollection].[isoperatingsystem],
       [SoftwareCollection].[source]
FROM   (
       -- Select entries from the v_GS_Installed_Software View
       SELECT [Software].[resourceid]                                     AS [DeviceSourceKey],
              --##NULL AS [InstalledLocation],
              COALESCE(NULLIF([Software].[displayname0], ''), N'Unknown') AS [ProductName],
              COALESCE(NULLIF([Software].[version0], ''), N'Unknown')     AS [ProductVersion],
              COALESCE(NULLIF([Software].[publisher0], ''), N'Unknown')   AS [Publisher],
              [Software].[prodid0]                                        AS [SoftwareCode],
              [Software].[prodid0]                                        AS [PackageCode],
              TRY_CONVERT(VARCHAR, [Software].[installdate0], 112)         AS [InstallDate],
              0                                                           AS [IsOperatingSystem],
              'v_ARP'                                                     AS [Source]
       FROM   [dbo].[v_add_remove_programs] AS [Software]
       LEFT OUTER JOIN
        (
            SELECT
                [ResourceID],
                [Caption0],
                [SerialNumber0],
                [CSDVersion0],
                --[InstallDate0],
                [Version0],
                ROW_NUMBER() OVER (PARTITION BY [ResourceID] ORDER BY [GroupID] DESC) AS [OperatingSystemRow]
            FROM
                [dbo].[v_GS_Operating_System]
        ) AS [OperatingSystem]
        ON [Software].[ResourceID] = [OperatingSystem].[ResourceID] AND [OperatingSystem].[OperatingSystemRow] = 1
       -- Apply this filter to remove software we don't care about at the present time to reduce the volume
       WHERE  ( Charindex('microsoft', [Software].[publisher0]) > 0
                AND (Charindex('KB', [Software].[displayname0])
                    + Charindex('.NET Framework', [Software].[displayname0])
                    + Charindex('Update', [Software].[displayname0])
                    + Charindex('Service Pack', [Software].[displayname0])
                    + Charindex('Proof', [Software].[displayname0])
                    + Charindex('Components', [Software].[displayname0])
                    + Charindex('Tools', [Software].[displayname0])
                    + Charindex('MUI', [Software].[displayname0])
                    + Charindex('Redistributable', [Software].[displayname0]) =
                    0 )
                    --//All Vendors//-- OR CHARINDEX('microsoft', [Software].[Publisher0]) <= 0
                )
                --//Servers Only//-- AND [OperatingSystem].[Caption0] LIKE '%server%'
                --//Clients Only//-- AND [OperatingSystem].[Caption0] NOT LIKE '%server%'
        UNION ALL
        -- Select entries from the v_GS_Operating_System View
        SELECT [OperatingSystem].[resourceid] AS [DeviceSourceKey],
               --##NULL AS [InstalledLocation],
               COALESCE(NULLIF([OperatingSystem].[caption0], ''), N'Unknown OS') AS [ProductName],
               COALESCE(NULLIF([OperatingSystem].[version0], ''), N'Unknown') AS [ProductVersion],
               CASE
                 WHEN [OperatingSystem].[caption0] LIKE N'%windows%' THEN
                 N'Microsoft'
                 ELSE N'Unknown'
               END
               AS [Publisher],
               NULL AS [SoftwareCode],
               NULL AS [PackageCode],
               TRY_CONVERT(VARCHAR, [OperatingSystem].[installdate0], 112) AS [InstallDate],
               1 AS [IsOperatingSystem],
               'v_GS_OS' AS [Source]
        FROM   [dbo].[v_gs_operating_system] AS [OperatingSystem]
        --//Servers Only//-- WHERE [OperatingSystem].[Caption0] LIKE '%server%'
        --//Clients Only//-- WHERE [OperatingSystem].[Caption0] NOT LIKE '%server%'
        ) AS [SoftwareCollection]
INNER JOIN [dbo].[v_fullcollectionmembership] AS [FullCollectionMembership]
        ON [SoftwareCollection].[devicesourcekey] = [FullCollectionMembership].[resourceid] AND [FullCollectionMembership].[collectionid] IN ( 'SMS00001' )     
GROUP  BY [SoftwareCollection].[devicesourcekey],
          --##[SoftwareCollection].[InstalledLocation],
          [SoftwareCollection].[productname],
          [SoftwareCollection].[productversion],
          [SoftwareCollection].[publisher],
          [SoftwareCollection].[InstallDate],
          [SoftwareCollection].[softwarecode],
          [SoftwareCollection].[packagecode],
          [SoftwareCollection].[isoperatingsystem],
          [SoftwareCollection].[source] 
"@

$sqlCommandServices = @"
SELECT DISTINCT
    [Services].[ResourceID] AS [SourceKey],
    --[Services].[AcceptPause0] AS [AcceptPause],
    --[Services].[AcceptStop0] AS [AcceptStop],
    --[Services].[Caption0] AS [Caption],
    --[Services].[Description0] AS [Description],
    --[Services].[DesktopInteract0] AS [DesktopInteract],
    [Services].[DisplayName0] AS [DisplayName],
    --[Services].[ErrorControl0] AS [ErrorControl],
    --[Services].[ExitCode0] AS [ExitCode],
    [Services].[Name0] AS [Name],
    --[Services].[PathName0] AS [PathName],
    --[Services].[ProcessId0] AS [ProcessId],
    --[Services].[ServiceSpecificExitCode0] AS [ServiceSpecificExitCode],
    [Services].[ServiceType0] AS [ServiceType],
    --[Services].[Started0] AS [Started],
    [Services].[StartMode0] AS [StartMode],
    [Services].[StartName0] AS [StartName],
    [Services].[State0] AS [State],
    [Services].[Status0] AS [Status]
    --[Services].[TagId0] AS [TagId],
    --[Services].[WaitHint0] AS [WaitHint]
FROM
    [dbo].[v_GS_SERVICE] AS [Services]
LEFT OUTER JOIN
    (
        SELECT
            [ResourceID],
            [Caption0],
            [SerialNumber0],
            [CSDVersion0],
            [InstallDate0],
            [Version0],
            ROW_NUMBER() OVER (PARTITION BY [ResourceID] ORDER BY [GroupID] DESC) AS [OperatingSystemRow]
        FROM
            [dbo].[v_GS_Operating_System]
    ) AS [OperatingSystem]
    ON [Services].[ResourceID] = [OperatingSystem].[ResourceID] AND [OperatingSystem].[OperatingSystemRow] = 1
WHERE [OperatingSystem].[Caption0] LIKE '%windows%'
    --//Servers Only//-- AND [OperatingSystem].[Caption0] LIKE '%server%'
    --//Clients Only//-- AND [OperatingSystem].[Caption0] NOT LIKE '%server%'
    --//All Vendors//-- AND (([Services].[Description0] LIKE '%Microsoft%' OR [Services].[Description0] LIKE '%Microsoft%' OR [Services].[Description0] LIKE '%365%' OR [Services].[Description0] LIKE '%SQL Server%' ) OR 
    --//All Vendors//-- ([Services].[Name0] LIKE '%MSSQL%' OR [Services].[Name0] LIKE '%ReportServer%' OR [Services].[Name0] LIKE '%SQLSERVER%' OR [Services].[Name0] LIKE '%MSOLAP%' OR [Services].[Name0] LIKE '%MsDtsServer%' OR [Services].[Name0] LIKE '%SQLAgent%' OR [Services].[Name0] LIKE '%SPADMIN%' OR [Services].[Name0] LIKE '%MSExchange%' OR [Services].[Name0] LIKE '%smstsmgr%' OR [Services].[Name0] LIKE '%CcmExec%' OR [Services].[Name0] LIKE '%BizTalk%' OR [Services].[Name0] LIKE '%BTSSvc%' OR [Services].[Name0] LIKE '%MicrosoftDynamics%' OR [Services].[Name0] LIKE '%MSCRM%' OR [Services].[Name0] LIKE '%Tssdis%' OR [Services].[Name0] LIKE '%Hyper-V%' OR [Services].[Name0] LIKE '%HvHost%' OR[Services].[Name0] LIKE '%W3SVC%' OR [Services].[Name0] LIKE '%msmpi%' OR [Services].[Name0] LIKE '%MSMQ$%' OR [Services].[Name0] LIKE '%ClusSvc%'))
"@

$sqlIEFileData = @"
SELECT
    [SoftwareFiles].[ResourceID],
    [SoftwareFiles].[FileName],
    [SoftwareFiles].[FileDescription],
    [SoftwareFiles].[FileVersion]
    --/--[SoftwareFiles].[FileSize],
    --/--[SoftwareFiles].[FilePath]
From
    [dbo].[v_GS_SoftwareFile] As [SoftwareFiles]
LEFT OUTER JOIN
    (
        SELECT
            [ResourceID],
            [Caption0],
            [SerialNumber0],
            [CSDVersion0],
            [InstallDate0],
            [Version0],
            ROW_NUMBER() OVER (PARTITION BY [ResourceID] ORDER BY [GroupID] DESC) AS [OperatingSystemRow]
        FROM
            [dbo].[v_GS_Operating_System]
    ) AS [OperatingSystem]
    ON [SoftwareFiles].[ResourceID] = [OperatingSystem].[ResourceID] AND [OperatingSystem].[OperatingSystemRow] = 1
Where
    [SoftwareFiles].FileName = 'iexplore.exe'
    --and [SoftwareFiles].FilePath like '%Internet Explorer%'
    --//Servers Only//-- AND [OperatingSystem].[Caption0] LIKE '%server%'
    --//Clients Only//-- AND [OperatingSystem].[Caption0] NOT LIKE '%server%'
"@

Get-SCCMInventoryData