 ##########################################################################
 # 
 #     Get-ADDetails
 #
 ##########################################################################
 
 <#
.SYNOPSIS
Retrieves domain, user, device, server & mobile device data from Active Directory

.DESCRIPTION
The Get-ADDetails script queries the local domain for domain, user, device, group, 
server & mobile device data and produces 10 CSV files
    1)    Domains.csv - One record per domain
    2)    DomainTrusts.csv - One record per external trusted domain
    3)    DomainNetBIOS.csv - One record per domain (Includes domain NetBIOS name)
    4)    DomainControllers.csv - One record per domain controller for current domain
    5)    Users.csv - One record per domain user
    6)    Devices.csv - One record per domain computer
    7)    Groups.csv - One record per Group
    8)    ExchangeServers.csv - One record per Exchange Server
    9)    ActiveSyncDevices.csv - One record per Exchange Active Sync Device
    10)   DomainPolicies.csv - Domain Policies (Usually 1 per domain)

    Files are written to current working directory

.PARAMETER Verbose 
Flag - Display extra info to screen

.EXAMPLE
Get all domain, user, device, server & mobile device data from current domain
Get-ADDetails -Verbose

.COPYRIGHT
Copyright (C) 2024 Ernst & Young Global Limited. All rights reserved. The Irish firm Ernst & Young is a member practice of Ernst & Young Global Limited.

This script is proprietary to Ernst & Young Global Limited (or one of its member firms). Unauthorized copying of this file, via any medium, is strictly prohibited. Redistribution and use in source and binary forms, with or without modification, are not permitted without prior written permission from Ernst & Young Global Limited.

.LICENSE
This script is provided "AS IS" without warranty of any kind. Ernst & Young Global Limited expressly disclaims all warranties, whether express, implied, statutory, or otherwise, with respect to this script including all implied warranties of merchantability, fitness for a particular purpose, and non-infringement. In no event shall Ernst & Young Global Limited be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this script, even if advised of the possibility of such damage.

#>

 Param(
    [alias("r")]
    [string] $SearchRoot = "",
    [string] $OutputFolder = ".\",
    [string] $OutputFilePrefix = "",
    [alias("o1")]
    [string] $OutputFile1 = "ADDomains.csv",
    [alias("o2")]
    [string] $OutputFile2 = "ADDomainTrusts.csv",
    [alias("o3")]
    [string] $OutputFile3 = "ADDomainNetBIOSNames.csv",
    [alias("o4")]
    [string] $OutputFile4 = "ADDomainControllers.csv",
    [alias("o5")]
    [string] $OutputFile5 = "ADUsers.csv",
    [alias("o6")]
    [string] $OutputFile6 = "ADDevices.csv",
    [alias("o7")]
    [string] $OutputFile7 = "ADGroups.csv",
    [alias("o8")]
    [string] $OutputFile8 = "ADExchangeServers.csv",
    [alias("o9")]
    [string] $OutputFile9 = "ADDevicesActiveSync.csv",
    [alias("o10")]
    [string] $OutputFile10 = "ADDomainPolicies.csv",
    [alias("log")]
    [string] $LogFile = "ADLog.txt",
    [ValidateSet("All","Servers","Clients")] 
    [string] $TargetType = "All",
    [switch] $MicrosoftOnly,
    [string] $RequiredData = "Domains,DomainTrusts,DomainNetBIOSNames,DomainControllers,Users,Devices,Groups,ExchangeServers,ActiveSyncDevices,DomainPolicies",
    [switch] $GetAllAttributes,
    [string] $DomainTrustAttributes = "name,trustpartner,flatname,distinguishedname,adspath,trustdirection,trustattributes,trusttype,whencreated,whenchanged",
    ##[string] $DomainTrustAttributes = "name,trustpartner,flatname,distinguishedname,adspath,trustdirection,trustattributes,trusttype,trustposixoffset,instancetype,whencreated,whenchanged",
    [string] $DomainNetBIOSDetailsAttributes = "name,netbiosname,ncname,adspath,dnsroot,objectguid,whencreated,whenchanged",
    [string] $ExchangeServerAttributes = "name,objectGUID,msexchproductid,msexchcurrentserverroles,type,msexchserversite,usncreated,ADsPath,msexchversion,serialnumber",
    ##[string] $ExchangeServerAttributes = "name,objectGUID,msexchproductid,msexchcurrentserverroles,type,msexchserversite,usncreated,ADsPath,msexchversion,serialnumber,msexchserverrole",
    [string] $GroupAttributes = "name,objectSid,objectGUID,description,distinguishedName,whenChanged,whenCreated,memberOf,groupType",
    [string] $UserAttributes = "sAMAccountName,sAMAccountType,objectSid,objectGUID,accountExpires,title,l,mobile,postalCode,postOfficeBox,streetAddress,displayName,departmentNumber,company,department,distinguishedName,lastLogon,lastLogonTimestamp,logonCount,mail,telephoneNumber,physicalDeliveryOfficeName,description,whenChanged,whenCreated,pwdLastSet,userPrincipalName,userAccountControl,msExchHomeServerName,msExchMailboxGuid,msExchWhenMailboxCreated,primaryGroupID,memberOf,employeeNumber,employeeType,employeeID,objectClass,objectCategory",
    [string] $DeviceAttributes = "sAMAccountName,name,dNSHostName,sAMAccountType,objectSid,objectGUID,location,operatingSystem,operatingSystemVersion,lastLogon,lastLogonTimeStamp,ADsPath,description,whenChanged,whenCreated,pwdLastSet,userAccountControl,company,logonCount,countryCode,memberOf,objectClass,objectCategory",
    ##[string] $DeviceAttributes = "sAMAccountName,name,dNSHostName,sAMAccountType,objectSid,objectGUID,location,operatingSystem,operatingSystemServicePack,operatingSystemVersion,lastLogon,lastLogonTimeStamp,ADsPath,description,whenChanged,whenCreated,servicePrincipalName,pwdLastSet,userAccountControl,company,logonCount,countryCode,memberOf,objectClass,objectCategory",
    [string] $ActiveSyncDeviceAttributes = "name,objectGUID,ADsPath,description,whenChanged,whenCreated,msExchDeviceEASVersion,msExchDeviceID,msExchDeviceModel,msExchDeviceOS,msExchDeviceType,msExchLastUpdateTime",
    ##[string] $ActiveSyncDeviceAttributes = "name,objectGUID,ADsPath,description,whenChanged,whenCreated,msExchDeviceEASVersion,msExchDeviceFriendlyName,msExchDeviceID,msExchDeviceIMEI,msExchDeviceMobileOperator,msExchDeviceModel,msExchDeviceOS,msExchDeviceOSLanguage,msExchDeviceTelephoneNumber,msExchDeviceType,msExchLastExchangeChangedTime,msExchLastUpdateTime",
    [string] $DomainPolicyAttributes = "distinguishedName,name,whenCreated,whenChanged,minPwdLength,minPwdAge,maxPwdAge,pwdProperties,lockoutThreshold,lockoutDuration,pwdHistoryLength,msDS-Behavior-Version,msDS-NcType",
    [switch] $ShortenPhoneNumbers,
    [switch] $Verbose)

$ScriptDescription =       "Active Directory Export"
$ScriptVersion =           "5.0.10"

#region Logging
$script:OutFileSupportsNoNewLine = $false;
function InitialiseLogFile {

    if (!($script:OutputFolder)) {
        $script:OutputFolder = ".\"
    }

    if (!(Test-Path $script:OutputFolder)) {
        New-Item -ItemType Directory -Path $script:OutputFolder | Out-Null
    }

    $script:OutputFolder = Resolve-Path $script:OutputFolder | Select-Object -ExpandProperty Path

    if (!($script:OutputFolder.EndsWith('\'))) {
        $script:OutputFolder += '\'
    }

    if ($script:OutputFolder -and !($LogFile -like "*\*")) {
        $script:LogFile = Join-Path $script:OutputFolder "$($OutputFilePrefix)$LogFile"
    }

    if ($LogFile -and (Test-Path $LogFile)) {
        Remove-Item $LogFile
    }

    if ((Get-Command "Out-File").parameters["NoNewline"]) {
        $script:OutFileSupportsNoNewLine = $true;
    }

    PrefixOutputFilesWithFolder
    DecryptPassword
}

function PrefixOutputFilesWithFolder {
    
    # Check if $OutputFolder exists and is not empty
    if ($script:OutputFolder) {
        $counter = 1
        while ($true) {
            $outputFileVarName = "OutputFile$counter"
            # Check if the OutputFile variable exists
            if (Get-Variable -Name $outputFileVarName -Scope Script -ErrorAction SilentlyContinue) {
                # Get the value of the OutputFile variable
                $outputFileValue = Get-Variable -Name $outputFileVarName -ValueOnly -Scope Script
                # Check if it does not contain a backslash, and if so, prefix with OutputFolder
                if (-not $outputFileValue.Contains("\"))
                {
                    Set-Variable -Name $outputFileVarName -Value (Join-Path $script:OutputFolder "$($OutputFilePrefix)$outputFileValue") -Scope Script
                }
                $counter++
            } else {
                # Exit loop if the variable does not exist
                break
            }
        }
    }
} 

function LogText {
    param(
        [Parameter(Position=0, ValueFromRemainingArguments=$true, ValueFromPipeline=$true)]
        [Object] $Object,
        [System.ConsoleColor]$Color = [System.Console]::ForegroundColor,
        [switch]$NoNewLine = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"
    )

    if ($LogTo -ne "File") {
        # Display text on screen
        Write-Host -Object $Object -ForegroundColor $Color -NoNewline:$NoNewLine
    }
    
    if ($LogTo -ne "Console") {
        if ($LogFile) {
            if ($script:OutFileSupportsNoNewLine) {
                $Object | Out-File $LogFile -Encoding utf8 -Append -NoNewline:$NoNewLine 
            }
            else {
                $Object | Out-File $LogFile -Encoding utf8 -Append 
            }
        }
    }
}

function LogTimeAndText {
    param(
        [string] $Text,
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Blue,
        [switch]$IncludeDate = $false,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    $output = "";
    if ($IncludeDate) {
        $output = Get-Date -Format "yyyy-MM-dd HH:mm:ss.ff"
    } else {
        $output = Get-Date -Format "HH:mm:ss.ff"
    }

    $output += " - "
    $output += $Text
    LogText $output -Color $Color -LogTo $LogTo
}

function LogError([string[]]$errorDescription){
    if ($Verbose){
        LogText ""
    }

    $output = $errorDescription -join "`r`n              "
    LogTimeAndText $output -Color Red

    Start-Sleep -s 3
}

function LogLastException() {
    $currentException = $Error[0].Exception;

    while ($currentException)
    {
        LogText -Color Red $currentException
        LogText -Color Red $currentException.Data
        LogText -Color Red $currentException.HelpLink
        LogText -Color Red $currentException.HResult
        LogText -Color Red $currentException.Message
        LogText -Color Red $currentException.Source
        LogText -Color Red $currentException.StackTrace
        LogText -Color Red $currentException.TargetSite

        $currentException = $currentException.InnerException
    }

    Start-Sleep -s 3
}

$script:MostRecentActivity = ""
function LogProgress([string]$Activity, [string]$Status, [Int32]$PercentComplete, [switch]$Completed ){
    
    if ($Activity) {
        $script:MostRecentActivity = $Activity
    } else {
        if ($script:MostRecentActivity) {
            $Activity = $script:MostRecentActivity
        } else {
            $Activity = "Unspecified"
        }
    }
    Write-Progress -activity $Activity -Status $Status -percentComplete $PercentComplete -Completed:$Completed
    LogTimeAndText $Status
}

function GetScriptPath
{
    if($PSCommandPath){
        return $PSCommandPath; }
        
    if($MyInvocation.ScriptName){
        return $MyInvocation.ScriptName }
        
    if($script:MyInvocation.MyCommand.Path){
        return $script:MyInvocation.MyCommand.Path }

    return $script:MyInvocation.MyCommand.Definition
}

function GetDotNetFrameworkVersion {
    #$release = Get-ItemPropertyValue -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release
    $regKey = Get-Item -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    $release = $regKey.GetValue("Release")
    switch ($release) {
        { $_ -ge 533320 } { $version = "4.8.1 or later ($release)"; break }
        { $_ -ge 528040 } { $version = "4.8 ($release)"; break }
        { $_ -ge 461808 } { $version = "4.7.2 ($release)"; break }
        { $_ -ge 461308 } { $version = "4.7.1 ($release)"; break }
        { $_ -ge 460798 } { $version = "4.7 ($release)"; break }
        { $_ -ge 394802 } { $version = "4.6.2 ($release)"; break }
        { $_ -ge 394254 } { $version = "4.6.1 ($release)"; break }
        { $_ -ge 393295 } { $version = "4.6 ($release)"; break }
        { $_ -ge 379893 } { $version = "4.5.2 ($release)"; break }
        { $_ -ge 378675 } { $version = "4.5.1 ($release)"; break }
        { $_ -ge 378389 } { $version = "4.5 ($release)"; break }
        default { $version = $null; break }
    }

    return $version
}

function LogEnvironmentDetails ([string[]] $OtherDetails){

    $script:ScriptPath = GetScriptPath
    $script:ScriptName = split-path $ScriptPath -leaf

    LogText " "
    LogHeaderText -FrameLine 
    LogHeaderText -LeftText " _______     __" -LeftColor Yellow
    LogHeaderText -LeftText "|  ___\ \   / /" -LeftColor Yellow
    LogHeaderText -LeftText "| |__  \ \_/ / " -LeftColor Yellow
    LogHeaderText -LeftText "|  __|  \   /  " -LeftColor Yellow
    LogHeaderText -LeftText "| |____  | |   " -LeftColor Yellow -RightText "$ScriptDescription  "
    LogHeaderText -LeftText "|______| |_|   " -LeftColor Yellow -RightText "Version $ScriptVersion  "
    LogHeaderText
    LogHeaderText -FrameLine 

    LogText " "
    LogText " $ScriptName" -Color Green 
    LogText " "

    if ($PSVersionTable.PSVersion.Major -ge 3) {
        $oSDetails = Get-CimInstance -ClassName Win32_OperatingSystem
    } else {
        $oSDetails = Get-WmiObject -Class Win32_OperatingSystem
    }
    $elevated = [bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")
    $currentThread = [System.Threading.Thread]::CurrentThread
    $dotNetFrameworkVersion = GetDotNetFrameworkVersion
    LogText -Color Gray "Computer Name:          $($env:COMPUTERNAME)"
    LogText -Color Gray "User Name:              $($env:USERNAME)@$($env:USERDNSDOMAIN)"
    LogText -Color Gray "Windows Version:        $($oSDetails.Caption)($($oSDetails.Version))"
    LogText -Color Gray "Memory kB:              $($oSDetails.TotalVisibleMemorySize.ToString("N0")) ($($oSDetails.FreePhysicalMemory.ToString("N0")) Free)"
    LogText -Color Gray "Locale:                 $($oSDetails.Locale) (Language $($oSDetails.OSLanguage))"
    LogText -Color Gray "PowerShell Host:        $($host.Version.Major)"
    LogText -Color Gray "PowerShell Version:     $($PSVersionTable.PSVersion)"
    LogText -Color Gray "PowerShell Word Size:   $($([IntPtr]::size) * 8) bit"
    LogText -Color Gray "Script Path:            $ScriptPath"
    LogText -Color Gray "Working Directory:      $PWD"
    LogText -Color Gray "CLR Version:            $($PSVersionTable.CLRVersion)"
    LogText -Color Gray ".Net Framework Version: $dotNetFrameworkVersion"
    LogText -Color Gray "Elevated:               $elevated"
    LogText -Color Gray "Current Date Time:      $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
    LogText -Color Gray "Default Date Format:    $($CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern)"
    LogText -Color Gray "Current Culture:        $((Get-Culture).EnglishName) (UI: $((Get-UICulture).EnglishName))"
    
    if (Test-Path "Variable:OutputFolder") {
        LogText -Color Gray "Output Folder:          $OutputFolder" 
    }
    if (Test-Path "Variable:OutputFile1") {
        LogText -Color Gray "Output File 1:          $OutputFile1" 
    }
    if (Test-Path "Variable:LogFile") {
        LogText -Color Gray "Log File:               $LogFile" 
    }
    if (Test-Path "Variable:ComputerName") {
        LogText -Color Gray "Target Computer Name:   $ComputerName" 
    }
    if (Test-Path "Variable:UserName") {
        LogText -Color Gray "Script User Name:       $UserName"
    }
    if (Test-Path "Variable:MicrosoftOnly") {
        LogText -Color Gray "Microsoft Only:         $MicrosoftOnly"
    }
    if (Test-Path "Variable:TargetType") {
        LogText -Color Gray "Target Type:            $TargetType"
    }
    if (Test-Path "Variable:ScriptRegime") {
        LogText -Color Gray "Script Regime:          $ScriptRegime"
    }
    if (Test-Path "Variable:RequiredData") {
        LogText -Color Gray "Required Data:          $RequiredData"
    }

    foreach ($detail in $OtherDetails){
        LogText -Color Gray $detail
    }

    LogText -Color Gray ""

}

function LogHeaderText {
    param(
        [string] $LeftText = " ",
        [System.ConsoleColor]$LeftColor = [System.ConsoleColor]::Blue,
        [string] $RightText,
        [System.ConsoleColor]$RightColor = [System.ConsoleColor]::DarkGray,
        [char] $FrameChar = "#",
        [switch] $FrameLine,
        [switch] $LeftAlignRightText,
        [ValidateSet("Console","File","Both")] 
        $LogTo = "Both"  
    )

    if ($FrameLine) {
        $strFullText = "  " + ($FrameChar.ToString() * 69)
        LogText $strFullText -Color DarkGray -LogTo $LogTo
        return
    }

    $strLeftFrame = "  $FrameChar  "
    $strLeftText = $LeftText
    $strRightText = $RightText
    $strRightFrame = "  $FrameChar"
    if ($LeftAlignRightText) {
        $strRightText = $RightText.PadRight(63 - $LeftText.Length)
    } else {
        $strLeftText = $LeftText.PadRight(63 - $RightText.Length)
    }
    

    if ($LogTo -eq "Console" -or $LogTo -eq "Both") {
        LogText $strLeftFrame -LogTo "Console" -NoNewLine -Color DarkGray
        LogText $strLeftText -LogTo "Console" -NoNewLine -Color $LeftColor
        LogText $strRightText -LogTo "Console" -NoNewLine -Color $RightColor
        LogText $strRightFrame -LogTo "Console" -Color DarkGray
    }

    if ($LogTo -eq "File" -or $LogTo -eq "Both") {
        $strFullText = $strLeftFrame + $strLeftText + $strRightText + $strRightFrame
        LogText $strFullText -LogTo "File" 
    }
}

function DecryptPassword {
    $strOneTimePassword = "%OneTimePassword%" # Replace this with the one-time password
    if ($SecurePassword) {
        $baOneTimePassword = [System.Convert]::FromBase64String($strOneTimePassword)
        $baSecurePassword = [System.Convert]::FromBase64String($SecurePassword)
        for($i=0; $i -lt $baSecurePassword.count ; $i++)
        {
            $baSecurePassword[$i] = $baSecurePassword[$i] -bxor $baOneTimePassword[$i%$baOneTimePassword.Length]
        }
        $script:Password = [System.Text.Encoding]::Unicode.GetString($baSecurePassword);
    }
}
#endregion

#region Setup Output Formats
function SetupOutputFormats {
    # Standardise date/time output to ISO 8601'ish format
    $bOutputFormatsUpdated = $false
    $currentThread = [System.Threading.Thread]::CurrentThread
    $desiredShortPattern = 'yyyy-MM-dd'
    $desiredLongPattern = 'yyyy-MM-dd HH:mm:ss'

    try {
        $cultureInvariant = [CultureInfo]::InvariantCulture.Clone()
        $cultureInvariant.DateTimeFormat.ShortDatePattern = $desiredShortPattern
        $cultureInvariant.DateTimeFormat.LongDatePattern = $desiredLongPattern
        $cultureInvariant.NumberFormat.NumberGroupSeparator = ""  
        $cultureInvariant.NumberFormat.NumberDecimalSeparator = "."
        $currentThread.CurrentCulture = $cultureInvariant
        $bOutputFormatsUpdated = $true
    }
    catch {
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $currentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $currentThread.CurrentCulture.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $currentThread.CurrentCulture.NumberFormat.NumberGroupSeparator = ""  
            $currentThread.CurrentCulture.NumberDecimalSeparator = "."
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        try {
            $cultureCopy = $currentThread.CurrentCulture.Clone()
            $cultureCopy.DateTimeFormat.ShortDatePattern = $desiredShortPattern
            $cultureCopy.DateTimeFormat.LongDatePattern = $desiredLongPattern
            $cultureCopy.NumberFormat.NumberGroupSeparator = ""  
            $cultureCopy.NumberDecimalSeparator = "."
            $currentThread.CurrentCulture = $cultureCopy
            $bOutputFormatsUpdated = $true
            LogText "Updated output formats for current thread using clone of current culture"
        }
        catch {
        }
    }

    if (!($bOutputFormatsUpdated)) {
        LogText "Failed to update output formats"
    }
}
#endregion

#region Custom Export
$ScriptExcludeFields = $null
function Export-MyCsv {
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [PSCustomObject[]] $InputObject,
        [Parameter(Mandatory = $true)]
        [string] $Path,
        [switch] $Append,
        [switch] $IncludeIndex
    )

    begin {
        if ($null -eq $ScriptExcludeFields) {
            LoadExcludeFields
        }

        $fileExcludeFields = $null
        $fileID = GetFileNameFinalPart -FilePath $Path
        if ($ScriptExcludeFields.ContainsKey($fileID)) {
            $fileExcludeFields = $ScriptExcludeFields[$fileID].Split(',') | ForEach-Object { $_.Trim() }
        }

        $index = 1
        $outputData = New-Object 'System.Collections.Generic.List[object]'
    }

    process {
        foreach ($item in $InputObject) {
            
            # Create a duplicate of the item with only the required fields
            $processedItem = New-Object PSObject 
            foreach ($prop in $item.PSObject.Properties) {
                if ($null -eq $fileExcludeFields -or !$fileExcludeFields.Contains($prop.Name)) {
                    $processedItem | Add-Member -MemberType NoteProperty -Name $prop.Name -Value $prop.Value -Force
                }
            }

            # Add index if requested
            if ($IncludeIndex) {
                $processedItem | Add-Member -MemberType NoteProperty -Name 'Index' -Value $index -Force
                $index++
            }

            # Add the processed item to the list
            $outputData.Add($processedItem)
        }
    }

    end {
        # Convert the list to an array and export to CSV
        $outputData.ToArray() | Export-Csv -Path $Path -Encoding UTF8 -NoTypeInformation -Append:$Append -Delimiter ","

        # This function logs the field names and sample values of exported data to the log file and a CSV file
        # Uncomment the following line to enable this functionality
        #LogFieldInfo -InputObject $outputData -OutputFileName $fileID
        $outputData = $null
    }
}

function LoadExcludeFields {
    $script:ScriptExcludeFields = @{}

    if (!($ScriptDescription)) {
        return
    }

    # Import the CSV
    try {
        $csvData = Import-Csv -Path ".\ExcludeFields.csv" -ErrorAction SilentlyContinue
    } catch {
    }

    foreach ($row in $csvData | Where-Object { $_.Script -eq $ScriptDescription }) {
        $ScriptExcludeFields[$row.OutputFile] = $row.ExcludeFields
    }
}

function GetFileNameFinalPart {
    param (
        [string]$FilePath
    )

    # Return the last part of the filename i.e. Apps for the following values
    # c:\temp\20240102_101212_Apps.csv
    # c:\temp\Apps.csv

    # Get the filename without the extension
    $fileNameWithoutExtension = [System.IO.Path]::GetFileNameWithoutExtension($FilePath)

    # Split the filename by underscore or backslash, and take the last part
    $lastPart = ($fileNameWithoutExtension -split '[\\_]')[-1]

    return $lastPart
}

# Support function. Not currently called. The function is used for custom testing to aid the local development team where necessary
function LogFieldInfo {
    param(
        [PSCustomObject[]] $InputObject,
        [string] $OutputFileName
    )
    
    # This function logs the field names and sample values of exported data to the log file and a CSV file
    # It is not enabled by default
    if (!($InputObject) -or $InputObject.Count -eq 0) {
        return
    }

    # Creating a new array of fields and sample values
    $lstFields = @()

    $recordIndex = 1
    foreach ($record in $InputObject) {
        $fieldNames = $record.PSObject.Properties.Name
        $fieldIndex = 1

        # Iterate through each property
        foreach ($fieldName in $fieldNames) {
            # Creating a new object for each property
            $field = [PSCustomObject][ordered]@{
                ScriptFileName = $ScriptName
                ScriptDescription = $ScriptDescription
                OutputFileName = $OutputFileName
                FieldName = $fieldName
                SampleValue = $record.$fieldName
                FieldIndex = $fieldIndex++
                RecordIndex = $recordIndex
            }

            # Add new object to the array
            $lstFields += $field
        }
    
        $recordIndex++
        if ($recordIndex -gt 3) {
            break
        }
    }

    # Save the field info to log file and csv file
    $csvLines = $lstFields | ConvertTo-Csv -NoTypeInformation
    $csvString = $csvLines -join "`n"
    LogText $csvString -LogTo File
    $lstFields | export-csv -Path ".\FieldInfo.csv" -NoTypeInformation -Append -Delimiter ","
}
#endregion

#region Search AD
function SearchAD ($searchFilter, [string[]]$searchAttributesList, [string] $searchAttributes, [switch]$useNamingContext){
    
    $lstSearchResults = New-Object System.Collections.Generic.List[System.Management.Automation.PSObject]
    $objSearcher = New-Object System.DirectoryServices.DirectorySearcher

    if (!$searchAttributesList -and $searchAttributes) {
        $searchAttributesList = $searchAttributes -split ","
    }
    
    if ($useNamingContext){
        # Connect to the Configuration Naming Context
        $rootDSE = [ADSI]"LDAP://RootDSE"
        $configSearchRoot = [ADSI]("LDAP://" + $rootDSE.Get("configurationNamingContext"))
        $objSearcher.SearchRoot = $configSearchRoot
    }
    elseif ($SearchRoot){
        $objDomain = New-Object System.DirectoryServices.DirectoryEntry($SearchRoot)
        $objSearcher.SearchRoot = $objDomain
    }
    else {
        $objDomain = New-Object System.DirectoryServices.DirectoryEntry
        $objSearcher.SearchRoot = $objDomain
    }

    $objSearcher.PageSize = 1000
    $objSearcher.Filter = $searchFilter
    $objSearcher.SearchScope = "Subtree"

    if (!$GetAllAttributes -and $searchAttributesList) {
        ($searchAttributesList | %{$objSearcher.PropertiesToLoad.Add($_)}) | out-null
    }
    
    $objSearcher.FindAll() | % {
        $pso = New-Object PSObject
        $value = ""
        $_.Properties.GetEnumerator() | % {
            try {
                if ($_.Name -eq "objectsid") {
                    $Counter = 0
                    $Ba = New-Object Byte[] $_.Value[0].Length
                    $_.Value[0] | %{$Ba[$Counter++] = $_}
                    $value = (New-Object System.Security.Principal.SecurityIdentifier($Ba, 0)).Value
                }
                elseif ($_.Name -like "*guid") { # objectguid, msExchMailboxGuid
                    $Counter = 0
                    $Ba = New-Object Byte[] $_.Value[0].Length
                    $_.Value[0] | %{$Ba[$Counter++] = $_}
                    $value = (New-Object System.Guid -ArgumentList @(,$Ba)).ToString()
                }
                elseif (($_.Name -eq "lastLogon") -or ($_.Name -eq "lastLogonTimestamp") -or ($_.Name -eq "pwdlastset") -or ($_.Name -eq "accountexpires")) { 
                    if ($_.Value[0] -and $_.Value[0] -ne 0 -and $_.Value[0] -ne [Int64]::MaxValue) {
                        $value = [DateTime]::FromFileTime($_.Value[0]).ToString('yyyy-MM-dd hh:mm:ss')
                    } else {
                        $value = "";
                    }
                }
                elseif ($_.Value.Count -gt 1) {
                    $value = $_.Value -join ";"
                }
                else {
                    $value = ($_.Value | % {$_})
                }
                Add-Member -InputObject $pso -MemberType NoteProperty -Name $_.Name -Value $value
            }
            catch {
                LogLastException
            }
        } 
        $lstSearchResults.Add($pso) | out-null
    }

    if ($GetAllAttributes) {
        return $lstSearchResults
    } else {
        return $lstSearchResults | select-object $searchAttributesList
    }
}

function GetMoreRecentDate {
    Param(
    [string]$Date1 = "",
    [string]$Date2 = "")

    if ($Date1 -gt $Date2){
        return $Date1
    }
    else {
        return $Date2
    }
}
#endregion

#region Utilities
function MaskPhoneNumber {
    param (
        [string]$PhoneNumber
    )

    if (!($PhoneNumber)) {
        return ""
    }

    $digitCount = 0
    $maskedNumber = -join ($PhoneNumber.ToCharArray() | ForEach-Object {
        if ($_ -match '\d') {
            $digitCount++
            if ($digitCount -le 3) { $_ } else { '*' }
        } else {
            $_
        }
    })

    return $maskedNumber
}
#endregion

function GetDirectoryContext {

    if ($DirectoryContext) {
        return $DirectoryContext
    }

    if (-not $DomainDNS) {
        $DirectoryContext = new-object 'System.DirectoryServices.ActiveDirectory.DirectoryContext'("domain")
        return $DirectoryContext
    }

    if (-not $UserName) {
        $DirectoryContext = new-object 'System.DirectoryServices.ActiveDirectory.DirectoryContext'("forest", $DomainDNS)
        return $DirectoryContext
    }

    $DirectoryContext = new-object 'System.DirectoryServices.ActiveDirectory.DirectoryContext'("domain", $DomainDNS, $UserName, $Password)
    return $DirectoryContext
}

function GetDomainInfo {
    # Get a list of domains in the forest
    #$DC = GetDirectoryContext

    LogProgress -Activity "AD Data Export" -Status "Getting Domain Info" -PercentComplete 5

    $domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $directoryEntry = $domain.GetDirectoryEntry()
    $forest = $domain.Forest
    
    if ($Verbose){
        LogText "Current Forest:                  $forest"
        LogText "Forest Root Domain:              $($forest.RootDomain)"
        $forestDomainNames = ($forest.Domains | Select-Object -expand Name) -join ", "
        LogText "Forest Domains:                  $(CountItems($forest.Domains)) ($forestDomainNames)"

        LogText "Current Domain:                  $domain"
        $domainControllerNames = ($domain.DomainControllers | Select-Object -expand Name) -join ", "
        LogText "Domain Controllers:              $(CountItems($domain.DomainControllers)) ($domainControllerNames)"
    }

    if ($RequiredDataList -contains "domains" -and $forest.Domains) {
        $forest.Domains | ForEach-Object {
            $directoryEntry = $_.GetDirectoryEntry()
            [PSCustomObject]@{
                Name                    = $_.Name
                Forest                  = $_.Forest
                DomainMode              = $_.DomainMode
                ##DomainModeLevel         = $_.DomainModeLevel # Not Needed
                ##Parent                  = $_.Parent # Not Needed
                PdcRoleOwner            = $_.PdcRoleOwner
                RidRoleOwner            = $_.RidRoleOwner
                InfrastructureRoleOwner = $_.InfrastructureRoleOwner
                ##DomainControllers       = ($_.DomainControllers -join ';')
                ##Children                = ($_.Children -join ';')
                ShortName               = ($directoryEntry.Name -join ';')
                Path                    = $directoryEntry.Path
                DistinguishedName       = ($directoryEntry.distinguishedName -join ';')
                whenCreated             = $directoryEntry.Properties["whenCreated"].Value
                whenChanged             = $directoryEntry.Properties["whenChanged"].Value
            }
        } | Export-MyCsv -Path $OutputFile1 -IncludeIndex
    }

    if ($RequiredDataList -contains "domaintrusts" -and $forest.Domains) {
        $domainTrusts = SearchAD -searchFilter "(objectClass=trustedDomain)" -searchAttributes $DomainTrustAttributes
        $domainTrusts | Export-MyCsv -Path $OutputFile2 -IncludeIndex
        if ($Verbose){
            $trustDomainNames = ($domainTrusts | Select-Object -expand Name) -join ", "
            LogText "Trusted Domains:                 $(CountItems($domainTrusts)) ($trustDomainNames)"
        }
    }

    if ($RequiredDataList -contains "domainnetbiosnames") {
        $domainNetBIOSDetails = SearchAD -searchFilter "(NetBIOSName=*)" -searchAttributes $DomainNetBIOSDetailsAttributes -useNamingContext
        $domainNetBIOSDetails | Export-MyCsv -Path $OutputFile3 -IncludeIndex
    }

    if ($RequiredDataList -contains "domaincontrollers" -and $domain.DomainControllers){
        # Not included
        # CurrentTime, HighestCommittedUsn,  
        # SyncFromAllServersCallback, InboundConnections, OutboundConnections
        ## , @{N="Roles";E={$_.Roles -join ';'}}, @{N="Partitions";E={$_.Partitions -join ';'}}
        $domain.DomainControllers | Select-Object Name, Forest, OSVersion, Domain, 
            IPAddress, SiteName | Export-MyCsv -Path $OutputFile4 -IncludeIndex
    }
}

function GetGroupInfo {

    LogProgress -Activity "AD Data Export" -Status "Getting Group Info" -PercentComplete 10

    $groupList = SearchAD -searchFilter "(objectClass=group)" -searchAttributes $GroupAttributes
    $groupList | Export-MyCsv -Path $OutputFile7 -IncludeIndex
}

function GetUserInfo {

    LogProgress -Activity "AD Data Export" -Status "Getting User Info" -PercentComplete 40
    $userList = SearchAD -searchAttributes $UserAttributes -searchFilter "(&(|(objectCategory=person)(objectCategory=msDS-GroupManagedServiceAccount))(objectClass=user))" 
    
    if ($ShortenPhoneNumbers) {
        # Update the phone number
        foreach ($user in $userList) {
            if ($user.telephoneNumber) {$user.telephoneNumber = MaskPhoneNumber -PhoneNumber $user.telephoneNumber}
            if ($user.mobile) {$user.mobile = MaskPhoneNumber -PhoneNumber $user.mobile}
        }
    }

    $userList | Export-MyCsv -Path $OutputFile5 -IncludeIndex

    if ($Verbose){
        LogText "User Count:                      $($userList.Count)"

        $cutOfftime = (Get-Date).AddDays(-30).ToString('yyyy-MM-dd hh:mm:ss')
        $activeUsers = $userList | Where-Object {(GetMoreRecentDate -date1 $_.lastLogon -date2 $_.lastLogonTimestamp) -gt $cutOfftime}
        LogText "User Count (Active):             $(CountItems($activeUsers))"

        $exchangeMailBoxes = $userList | Where-Object {$_.msExchMailboxGuid}
        LogText "Exchange Mailbox Count:          $((($exchangeMailBoxes) | measure-object).count)"
        $activeExchangeMailBoxes = $exchangeMailBoxes | Where-Object {(GetMoreRecentDate -date1 $_.lastLogon -date2 $_.lastLogonTimestamp) -gt $cutOfftime}
        LogText "Exchange Mailbox Count (Active): $(CountItems($activeExchangeMailBoxes))"
    }
}

function GetDeviceInfo {
    
    LogProgress -Activity "AD Data Export" -Status "Getting Device Info" -PercentComplete 60
    
    $deviceList = SearchAD -searchFilter "(&(objectClass=computer)(!(objectCategory=msDS-GroupManagedServiceAccount)))" -searchAttributes $DeviceAttributes 

    if ($MicrosoftOnly) {
        $deviceList = $deviceList | Where-Object { $_.operatingSystem -like "*Windows*" }
    }

    if ($TargetType -eq "Servers") {
        $deviceList = $deviceList | Where-Object { $_.operatingSystem -like "*Server*" }
    } elseif ($TargetType -eq "Clients") {
        $deviceList = $deviceList | Where-Object { -not ($_.operatingSystem -like "*Server*") }
    }
    
    $deviceList | Export-MyCsv -Path $OutputFile6 -IncludeIndex

    if ($Verbose){
        LogText "Device Count:                    $($deviceList.Count)"

        $cutOfftime = (Get-Date).AddDays(-30).ToString('yyyy-MM-dd hh:mm:ss')
        $activeDevices = $deviceList | Where-Object {(GetMoreRecentDate -date1 $_.lastLogon -date2 $_.lastLogonTimestamp) -gt $cutOfftime}
        LogText "Device Count (Active):           $(CountItems($activeDevices))"

        $clusters = $deviceList | Where-Object {$null -ne $_.servicePrincipalName -and
                                            $_.servicePrincipalName.Contains("MSServerCluster/") }
        $clusterNames = ($clusters | Select-Object -expand Name) -join ", "
        LogText "Clusters:                        $(CountItems($clusters)) ($clusterNames)"

        $hyperVHosts = $deviceList | Where-Object { $null -ne $_.servicePrincipalName -and (
                            $_.servicePrincipalName.Contains("Microsoft Virtual Console Service/") -or 
                            $_.servicePrincipalName.Contains("Microsoft Virtual System Migration Service/")) }
        $hyperVHostNames = ($hyperVHosts | Select-Object -expand Name) -join ", "
        LogText "HyperV Hosts:                    $(CountItems($hyperVHosts)) ($hyperVHostNames)"

        $exchangeServers = $deviceList | Where-Object { $null -ne $_.servicePrincipalName -and (
                            $_.servicePrincipalName.Contains("exchangeMDB/") -or 
                            $_.servicePrincipalName.Contains("exchangeRFR/")) } 
        $exchangeServerNames = ($exchangeServers | Select-Object -expand Name) -join ", "
        LogText "Exchange Servers:                $(CountItems($exchangeServers)) ($exchangeServerNames)"

        LogText ""
        LogText "Operating System Counts:"
        $deviceList | Group-Object operatingSystem | Select-Object Name,Count | Sort-Object Count -desc | Format-Table -autosize | out-string | LogText
    }
}

function DecodeExchangeEdition([string] $encStr) {

    Set-Variable Seed -value 0x49 -option ReadOnly
    Set-Variable Magic -value 0x43 -option ReadOnly

    Add-Type -TypeDefinition @"
        public enum ExchangeEditions
        {
            None = -1,
            Standard = 0x0,
            Enterprise = 0x1,
            Evaluation = 0x2,
            Sample = 0x3,
            BackOffice = 0x4,
            Select = 0x5,
            UpgradedStandard = 0x8,
            UpgradedEnterprise = 0x9,
            Coexistence = 0xA,
            UpgradedCoexistence = 0xB
        }
"@


    if ([string]::IsNullOrEmpty($encStr)) {
        LogError("Edition string is null. Exiting DecodeExchangeEdition")
        return -1
    }

    [byte[]]$decodeBuf = [System.Text.Encoding]::Unicode.GetBytes($encStr)

    for ($i=$decodeBuf.Length; $i -gt 1 ; $i--) {
        $decodeBuf[$i - 1] = $decodeBuf[$i - 1] -bxor [byte]($decodeBuf[$i - 2] -bxor $Seed)
    }

    $decodeBuf[0] = $decodeBuf[0] -bxor ($Seed -bor $Magic)

    $strDecodedType = [System.Text.Encoding]::Unicode.GetString($decodeBuf)

    # The first part of the decoded type contains the Exchange server edition
    $strParts = $strDecodedType -split ";"

    if($strParts.Count -ne 3) {
        LogError "Array length mismatch. Exiting DecodeExchangeEdition"
        return -1
    }

    # Make sure this is a valid edition - we then add the edition string back into the AD query datastore - we're going to save
    # the datastore with the edition in it
    [int]$nEdition = [convert]::ToInt32($strParts[0], 16)


    if ([enum]::GetValues([ExchangeEditions]) -contains $nEdition) {
        return ($nEdition -as [ExchangeEditions])
    }
    else {
        return ( "Unknown(" + $nEdition + ")")
    }
}

function GetExchangeInfo {
    LogProgress -Activity "AD Data Export" -Status "Getting Exchange Info" -PercentComplete 80
    
    $exchangeServers = SearchAD -searchFilter "(objectCategory=msExchExchangeServer)" -searchAttributes $ExchangeServerAttributes -useNamingContext

    if ($exchangeServers) {
        # Parse Exchange Edition
        foreach ($srv in $exchangeServers) {
            $ExEditionDetails = DecodeExchangeEdition($srv.type)
            Add-Member -InputObject $srv -MemberType NoteProperty -Name "ExchangeEdition" -Value $ExEditionDetails

            $intValRoles = $srv.msexchcurrentserverroles
            $ExchangeRoles = @{2 = "Mailbox" ; 4 = "ClientAccess" ; 16 = "UnifiedMessaging" ; 32 = "HubTransport" ; 64 = "EdgeTransport" }
            $ExchServerRoles = $ExchangeRoles.Keys | Where-Object { $_ -band $intValRoles } | foreach { $ExchangeRoles.Get_Item($_) }
            $InstalledRoles = $ExchServerRoles -join ' | '
            Add-Member -InputObject $srv -MemberType NoteProperty -Name "ExchangeCurrentRoles" -Value $InstalledRoles
        }

        $exchangeServers | Export-MyCsv -Path $OutputFile8 -IncludeIndex
    }
    
    if ($RequiredDataList -contains "activesyncdevices") {
        
        $activeSyncDevices = SearchAD -searchFilter "(objectClass=msExchActiveSyncDevice)" -searchAttributes $ActiveSyncDeviceAttributes
        if ($activeSyncDevices) {
            if ($ShortenPhoneNumbers) {
                # Update the identifying numbers
                foreach ($device in $activeSyncDevices) {
                    if ($device.msExchDeviceTelephoneNumber) {$device.msExchDeviceTelephoneNumber = MaskPhoneNumber -PhoneNumber $device.msExchDeviceTelephoneNumber}
                    if ($device.msExchDeviceIMEI) {$device.msExchDeviceIMEI = MaskPhoneNumber -PhoneNumber $device.msExchDeviceIMEI}
                }
            }

            $activeSyncDevices | Export-MyCsv -Path $OutputFile9 -IncludeIndex
        }
        
        if ($Verbose){
            LogText "Active Sync Devices:"
            $activeSyncDevices | Group-Object msExchDeviceType | Select-Object Name,Count | Sort-Object Count -desc | Format-Table -autosize | out-string | LogText
        }
    }
}

function GetDomainPolicyInfo {
    
    LogProgress -Activity "AD Data Export" -Status "Getting Domain Policy Info" -PercentComplete 95

    $SettingsList = SearchAD -searchFilter "(|(objectCategory=domainDNS)(objectClass=domainPolicy))" -searchAttributes $DomainPolicyAttributes

    $SettingsList | Export-MyCsv -Path $OutputFile10 -IncludeIndex

    if ($Verbose){
        LogText "Domain Policy Count:    $($SettingsList.Count)"
    }
}

function CountItems {
    Param(
    $InputObject)

    if (-not $InputObject){
        return 0
    }
    elseif (Get-Member -inputobject $InputObject -name "Count" -Membertype Properties) {
        return $InputObject.Count
    }
    else {
        return 1
    }
}

function Get-ADDetails {
    try {
        
        InitialiseLogFile
        SetupOutputFormats
        LogEnvironmentDetails
        
        # Which records are required
        $script:RequiredDataList = $RequiredData -split ',' | ForEach-Object { $_.Trim().ToLower() }

        if ($RequiredDataList -contains "domains") {
            GetDomainInfo
        }

        if ($RequiredDataList -contains "groups") {
            GetGroupInfo
        }

        if ($RequiredDataList -contains "users") {
            GetUserInfo
        }
        
        if ($RequiredDataList -contains "devices") {
            GetDeviceInfo
        }

        if ($RequiredDataList -contains "exchangeservers") {
            GetExchangeInfo
        }

        if ($RequiredDataList -contains "domainpolicies") {
            GetDomainPolicyInfo
        }
        
        LogProgress -Activity "AD Data Export" -Status "Complete" -PercentComplete 100 -Completed $true
    }
    catch {
        LogLastException
    }
}

Get-ADDetails
